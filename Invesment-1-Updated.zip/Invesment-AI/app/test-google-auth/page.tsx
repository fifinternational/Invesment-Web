"use client"

import { useState } from 'react'
import { createBrowserClient } from '@supabase/ssr'

export default function TestGoogleAuth() {
  const [logs, setLogs] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString()
    setLogs(prev => [...prev, `[${timestamp}] ${message}`])
    console.log(message)
  }

  const testGoogleAuth = async () => {
    setIsLoading(true)
    setLogs([])
    
    try {
      addLog('🔍 Starting Google OAuth test...')
      
      // Initialize Supabase client
      const supabase = createBrowserClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
      )
      
      addLog(`✅ Supabase client initialized`)
      addLog(`📍 Supabase URL: ${process.env.NEXT_PUBLIC_SUPABASE_URL}`)
      addLog(`🔑 Anon Key length: ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.length}`)
      
      // Test redirect URL
      const redirectUrl = `${window.location.origin}/auth/callback`
      addLog(`🔗 Redirect URL: ${redirectUrl}`)
      
      // Attempt Google OAuth
      addLog('🚀 Initiating Google OAuth...')
      
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: redirectUrl,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          }
        }
      })
      
      if (error) {
        addLog(`❌ OAuth Error: ${error.message}`)
        addLog(`❌ Error Code: ${error.status}`)
        addLog(`❌ Full Error: ${JSON.stringify(error, null, 2)}`)
      } else {
        addLog(`✅ OAuth initiated successfully`)
        addLog(`📊 OAuth Data: ${JSON.stringify(data, null, 2)}`)
      }
      
    } catch (err) {
      addLog(`💥 Unexpected error: ${err}`)
      console.error('Test error:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const testSupabaseConnection = async () => {
    try {
      addLog('🔍 Testing Supabase connection...')
      
      const supabase = createBrowserClient(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
      )
      
      // Test basic connection
      const { data, error } = await supabase.auth.getSession()
      
      if (error) {
        addLog(`❌ Connection Error: ${error.message}`)
      } else {
        addLog(`✅ Supabase connection successful`)
        addLog(`📊 Current session: ${data.session ? 'Active' : 'None'}`)
      }
      
    } catch (err) {
      addLog(`💥 Connection test failed: ${err}`)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Google OAuth Debug Tool</h1>
        
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Environment Check</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <strong>Supabase URL:</strong>
              <div className="bg-gray-100 p-2 rounded mt-1 font-mono text-xs">
                {process.env.NEXT_PUBLIC_SUPABASE_URL || 'Not set'}
              </div>
            </div>
            <div>
              <strong>Anon Key:</strong>
              <div className="bg-gray-100 p-2 rounded mt-1 font-mono text-xs">
                {process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? 
                  `${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY.substring(0, 20)}...` : 
                  'Not set'
                }
              </div>
            </div>
            <div>
              <strong>Current URL:</strong>
              <div className="bg-gray-100 p-2 rounded mt-1 font-mono text-xs">
                {typeof window !== 'undefined' ? window.location.origin : 'Loading...'}
              </div>
            </div>
            <div>
              <strong>Callback URL:</strong>
              <div className="bg-gray-100 p-2 rounded mt-1 font-mono text-xs">
                {typeof window !== 'undefined' ? `${window.location.origin}/auth/callback` : 'Loading...'}
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Test Actions</h2>
          <div className="space-x-4">
            <button
              onClick={testSupabaseConnection}
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Test Supabase Connection
            </button>
            <button
              onClick={testGoogleAuth}
              disabled={isLoading}
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors disabled:opacity-50"
            >
              {isLoading ? 'Testing...' : 'Test Google OAuth'}
            </button>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Debug Logs</h2>
          <div className="bg-black text-green-400 p-4 rounded-lg h-96 overflow-y-auto font-mono text-sm">
            {logs.length === 0 ? (
              <div className="text-gray-500">No logs yet. Click a test button to start debugging.</div>
            ) : (
              logs.map((log, index) => (
                <div key={index} className="mb-1">
                  {log}
                </div>
              ))
            )}
          </div>
          {logs.length > 0 && (
            <button
              onClick={() => setLogs([])}
              className="mt-4 bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors"
            >
              Clear Logs
            </button>
          )}
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 mt-6">
          <h3 className="text-lg font-semibold text-yellow-800 mb-2">Common Issues & Solutions</h3>
          <ul className="text-yellow-700 space-y-2 text-sm">
            <li><strong>validation_failed:</strong> Check Google OAuth credentials in Supabase dashboard</li>
            <li><strong>redirect_uri_mismatch:</strong> Verify redirect URLs in Google Cloud Console</li>
            <li><strong>unauthorized_client:</strong> Ensure Google OAuth is enabled in Supabase</li>
            <li><strong>access_denied:</strong> Check OAuth consent screen configuration</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
