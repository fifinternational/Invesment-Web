"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Eye, EyeOff, Check, X, ArrowLeft, UserPlus } from "lucide-react"
// Logo import removed
import { motion } from "framer-motion"
import { registerUser, loginWithGoogle } from "@/utils/supabase/index.js"
import BubbleBackground from "@/components/auth/bubble-background"
import FinanceElements from "@/components/auth/finance-elements"
import TermsPrivacyPopup from "@/components/auth/terms-privacy-popup"
import GoogleAuthButton from "@/components/auth/google-auth-button"

export default function RegisterPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [showTermsPopup, setShowTermsPopup] = useState(false)
  const [showPrivacyPopup, setShowPrivacyPopup] = useState(false)

  // Password strength requirements
  const passwordRequirements = [
    { id: "length", label: "At least 8 characters", test: (pass: string) => pass.length >= 8 },
    { id: "uppercase", label: "At least 1 uppercase letter", test: (pass: string) => /[A-Z]/.test(pass) },
    { id: "lowercase", label: "At least 1 lowercase letter", test: (pass: string) => /[a-z]/.test(pass) },
    { id: "number", label: "At least 1 number", test: (pass: string) => /[0-9]/.test(pass) },
    { id: "special", label: "At least 1 special character", test: (pass: string) => /[^A-Za-z0-9]/.test(pass) },
  ]

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }))
    }
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    // Validate full name
    if (!formData.fullName.trim()) {
      newErrors.fullName = "Full name is required"
    }

    // Validate email
    if (!formData.email) {
      newErrors.email = "Email is required"
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid"
    }

    // Validate password
    if (!formData.password) {
      newErrors.password = "Password is required"
    } else {
      const failedRequirements = passwordRequirements.filter((req) => !req.test(formData.password))
      if (failedRequirements.length > 0) {
        newErrors.password = "Password doesn't meet requirements"
      }
    }

    // Validate confirm password
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsLoading(true)

    try {
      // Register with Supabase
      const result = await registerUser(formData.email, formData.password, formData.fullName)
      
      if (result.success) {
        // Always show email confirmation message for new signups
        setErrors({ 
          form: `✅ Pendaftaran berhasil! Silakan cek email Anda di ${formData.email} untuk konfirmasi akun. Jika tidak ada email, cek folder spam.` 
        })
      } else {
        // Display error message from Supabase
        setErrors({ form: result.error || "Registration failed. Please try again." })
      }
    } catch (error) {
      console.error("Registration error:", error)
      setErrors({ form: "An unexpected error occurred. Please try again." })
    } finally {
      setIsLoading(false)
    }
  };
  
  const handleGoogleSignup = async () => {
    setIsLoading(true);
    setErrors({});
    
    try {
      console.log('Starting Google signup process');
      const result = await loginWithGoogle();
      
      if (!result.success) {
        console.error('Google signup failed:', result.error);
        setErrors({ form: result.error || "Google signup failed. Please try again." });
        setIsLoading(false);
      }
      // If successful, user will be redirected to callback page
      // No need to set isLoading to false because the page will change
    } catch (error) {
      console.error("Google signup error:", error);
      setErrors({ form: "An unexpected error occurred with Google signup." });
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center overflow-hidden">
      {/* 3D Bubble Background with financial elements */}
      <BubbleBackground />
      <FinanceElements />
      
      <div className="relative z-10 w-full max-w-md px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="relative w-full p-8 rounded-3xl shadow-2xl overflow-hidden"
          style={{
            background: 'rgba(255, 255, 255, 0.85)',
            backdropFilter: 'blur(12px)',
            border: '2px solid rgba(255, 255, 255, 0.7)',
            boxShadow: '0 25px 50px -12px rgba(45, 212, 191, 0.35), 0 0 20px rgba(45, 212, 191, 0.2) inset',
          }}
        >
        {/* Card background accents - reduced opacity */}
        <div className="absolute -top-10 -right-10 w-32 h-32 rounded-full bg-[#2dd4bf]/3 blur-xl"></div>
        <div className="absolute -bottom-10 -left-10 w-24 h-24 rounded-full bg-[#2dd4bf]/3 blur-lg"></div>
        
        {/* 3D floating effect for the card */}
        <motion.div
          animate={{
            rotateX: [0, 2, 0],
            rotateY: [0, 2, 0],
            boxShadow: [
              '0 25px 50px -12px rgba(45, 212, 191, 0.3)',
              '0 30px 60px -12px rgba(45, 212, 191, 0.4)',
              '0 25px 50px -12px rgba(45, 212, 191, 0.3)'
            ]
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            repeatType: 'reverse',
          }}
          className="absolute inset-0 z-0 rounded-3xl"
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.6) 0%, rgba(45,212,191,0.2) 100%)',
            transform: 'perspective(1000px)',
          }}
        />
        <div className="relative z-10">
          <div className="text-center">
            <motion.div 
              className="flex justify-center relative"
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              {/* Single Logo */}
              {/* Logo removed */}
            </motion.div>
            <p className="mt-3 text-sm text-gray-600 font-medium">
              Create your account for AI Sharia Investment Research platform
            </p>
          </div>
          
          <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="rounded-md shadow-sm space-y-4">
            {/* Full Name Field */}
            <div>
              <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-1">
                Full Name
              </label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                autoComplete="name"
                required
                value={formData.fullName}
                onChange={handleChange}
                className={`appearance-none relative block w-full px-3 py-2 border ${
                  errors.fullName ? "border-red-300" : "border-gray-300"
                } placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-[#2dd4bf] focus:border-[#2dd4bf] focus:z-10 sm:text-sm`}
                placeholder="John Doe"
              />
              {errors.fullName && <p className="mt-1 text-sm text-red-600">{errors.fullName}</p>}
            </div>

            {/* Email Field */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={formData.email}
                onChange={handleChange}
                className={`appearance-none relative block w-full px-3 py-2 border ${
                  errors.email ? "border-red-300" : "border-gray-300"
                } placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-[#2dd4bf] focus:border-[#2dd4bf] focus:z-10 sm:text-sm`}
                placeholder="you@example.com"
              />
              {errors.email && <p className="mt-1 text-sm text-red-600">{errors.email}</p>}
            </div>

            {/* Password Field */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  className={`appearance-none relative block w-full px-3 py-2 border ${
                    errors.password ? "border-red-300" : "border-gray-300"
                  } placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-[#2dd4bf] focus:border-[#2dd4bf] focus:z-10 sm:text-sm pr-10`}
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </button>
              </div>
              {errors.password && <p className="mt-1 text-sm text-red-600">{errors.password}</p>}
            </div>

            {/* Password Requirements */}
            <div className="space-y-2">
              <p className="text-xs text-gray-500">Password requirements:</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {passwordRequirements.map((req) => (
                  <div
                    key={req.id}
                    className={`flex items-center text-xs ${
                      req.test(formData.password) ? "text-[#2dd4bf]" : "text-gray-500"
                    }`}
                  >
                    {req.test(formData.password) ? <Check className="h-3 w-3 mr-1" /> : <X className="h-3 w-3 mr-1" />}
                    {req.label}
                  </div>
                ))}
              </div>
            </div>

            {/* Confirm Password Field */}
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                Confirm Password
              </label>
              <div className="relative">
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  autoComplete="new-password"
                  required
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className={`appearance-none relative block w-full px-3 py-2 border ${
                    errors.confirmPassword ? "border-red-300" : "border-gray-300"
                  } placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-[#2dd4bf] focus:border-[#2dd4bf] focus:z-10 sm:text-sm pr-10`}
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400" />
                  )}
                </button>
              </div>
              {errors.confirmPassword && <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>}
            </div>

            {/* Terms and Conditions */}
            <div className="text-sm text-center text-gray-600 mt-4">
              <p>
                By registering, you agree to our{" "}
                <button 
                  type="button"
                  onClick={() => setShowTermsPopup(true)}
                  className="text-[#2dd4bf] hover:text-[#2dd4bf]/80 font-medium"
                >
                  Terms and Conditions
                </button>{" "}
                and{" "}
                <button 
                  type="button"
                  onClick={() => setShowPrivacyPopup(true)}
                  className="text-[#2dd4bf] hover:text-[#2dd4bf]/80 font-medium"
                >
                  Privacy Policy
                </button>
              </p>
            </div>
          </div>

          <div>
            <motion.button
              type="submit"
              disabled={isLoading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className={`group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-[#2dd4bf] hover:bg-[#2dd4bf]/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2dd4bf] shadow-md transition-all duration-200 ${
                isLoading ? "opacity-70 cursor-not-allowed" : ""
              }`}
            >
              {isLoading ? (
                <svg
                  className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
              ) : (
                "Create Account"
              )}
            </motion.button>
          </div>
          
          {/* Google Sign Up Option */}
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Or sign up with</span>
              </div>
            </div>
            
            <div className="mt-6">
              <GoogleAuthButton 
                onGoogleLogin={handleGoogleSignup}
                isLoading={isLoading}
                variant="signup"
              />
            </div>
          </div>
          </form>

          <div className="text-center mt-6">
            <Link href="/login" className="inline-flex items-center font-medium text-[#2dd4bf] hover:text-[#2dd4bf]/80 transition-colors duration-200">
              <ArrowLeft className="h-4 w-4 mr-1" />
              Back to login
            </Link>
          </div>
        </div>
        </motion.div>
      </div>
      
      {/* Terms and Privacy Popups */}
      <TermsPrivacyPopup 
        isOpen={showTermsPopup} 
        onClose={() => setShowTermsPopup(false)} 
        type="terms" 
      />
      <TermsPrivacyPopup 
        isOpen={showPrivacyPopup} 
        onClose={() => setShowPrivacyPopup(false)} 
        type="privacy" 
      />
    </div>
  )
}
