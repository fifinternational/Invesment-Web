import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    const market = searchParams.get('market') || 'IDX';
    const timeframe = searchParams.get('timeframe') || 'daily';

    // Initialize Supabase client
    const cookieStore = await cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value;
          },
          set(name: string, value: string, options: any) {
            cookieStore.set({ name, value, ...options });
          },
          remove(name: string, options: any) {
            cookieStore.set({ name, value: '', ...options });
          },
        },
      }
    );

    switch (action) {
      case 'ai-recommendations':
        return await getAIRecommendations(supabase, market, timeframe);
      
      case 'market-performance':
        return await getMarketPerformance(supabase, market);
      
      case 'watchlist':
        return await getUserWatchlist(supabase, request);
      
      case 'market-news':
        return await getMarketNews(supabase, market);
      
      case 'user-preferences':
        return await getUserPreferences(supabase, request);
      
      case 'search-history':
        return await getSearchHistory(supabase, request);
      
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error: any) {
    console.error('Dashboard API error:', error);
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    const cookieStore = await cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value;
          },
          set(name: string, value: string, options: any) {
            cookieStore.set({ name, value, ...options });
          },
          remove(name: string, options: any) {
            cookieStore.set({ name, value: '', ...options });
          },
        },
      }
    );

    switch (action) {
      case 'save-chat':
        return await saveChatHistory(supabase, body);
      
      case 'save-search':
        return await saveSearchHistory(supabase, body);
      
      case 'update-preferences':
        return await updateUserPreferences(supabase, body);
      
      case 'add-to-watchlist':
        return await addToWatchlist(supabase, body);
      
      case 'remove-from-watchlist':
        return await removeFromWatchlist(supabase, body);
      
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// Get AI recommendations based on market and timeframe
async function getAIRecommendations(supabase: any, market: string, timeframe: string) {
  const { data, error } = await supabase
    .from('ai_recommendations')
    .select('*')
    .eq('market', market)
    .eq('timeframe', timeframe)
    .eq('is_active', true)
    .order('confidence', { ascending: false })
    .limit(6);

  if (error) throw error;
  return NextResponse.json({ success: true, data });
}

// Get market performance summary
async function getMarketPerformance(supabase: any, market: string) {
  const today = new Date().toISOString().split('T')[0];
  
  const { data, error } = await supabase
    .from('market_performance')
    .select('*')
    .eq('market', market)
    .eq('date', today)
    .single();

  if (error && error.code !== 'PGRST116') throw error;
  
  // If no data for today, create sample data
  if (!data) {
    const sampleData = {
      market,
      date: today,
      total_volume: market === 'IDX' ? 8500000000 : 12000000000,
      total_value: market === 'IDX' ? 125000000000 : 850000000000,
      gainers_count: Math.floor(Math.random() * 100) + 50,
      losers_count: Math.floor(Math.random() * 80) + 40,
      unchanged_count: Math.floor(Math.random() * 30) + 10,
      top_gainer_symbol: market === 'IDX' ? 'GOTO' : 'TSLA',
      top_gainer_change: Math.random() * 10 + 5,
      top_loser_symbol: market === 'IDX' ? 'BBCA' : 'META',
      top_loser_change: -(Math.random() * 5 + 2)
    };
    
    return NextResponse.json({ success: true, data: sampleData });
  }
  
  return NextResponse.json({ success: true, data });
}

// Get user's watchlist
async function getUserWatchlist(supabase: any, request: NextRequest) {
  // For now, return sample watchlist data
  // In production, get user_id from auth and fetch real watchlist
  const sampleWatchlist = [
    {
      id: '1',
      symbol: 'BRIS',
      company_name: 'Bank BRISyariah Tbk',
      market: 'IDX',
      current_price: 2650,
      change: 50,
      change_percent: 1.92,
      volume: 15000000
    },
    {
      id: '2', 
      symbol: 'UNVR',
      company_name: 'Unilever Indonesia Tbk',
      market: 'IDX',
      current_price: 2580,
      change: -20,
      change_percent: -0.77,
      volume: 8500000
    },
    {
      id: '3',
      symbol: 'AAPL',
      company_name: 'Apple Inc',
      market: 'US',
      current_price: 182.50,
      change: 2.30,
      change_percent: 1.28,
      volume: 45000000
    }
  ];

  return NextResponse.json({ success: true, data: sampleWatchlist });
}

// Get market news
async function getMarketNews(supabase: any, market: string) {
  const { data, error } = await supabase
    .from('market_news')
    .select('*')
    .eq('market', market)
    .order('published_at', { ascending: false })
    .limit(10);

  if (error) throw error;
  
  // If no news, return sample news
  if (!data || data.length === 0) {
    const sampleNews = market === 'IDX' ? [
      {
        title: 'Bank Syariah Indonesia Raih Laba Bersih Rp 2,1 Triliun',
        summary: 'BSI mencatat pertumbuhan laba yang signifikan didukung ekspansi pembiayaan syariah',
        source: 'Kontan',
        published_at: new Date().toISOString(),
        category: 'company',
        url: '#'
      },
      {
        title: 'Indeks Saham Syariah Menguat 1,2% di Penutupan Hari Ini',
        summary: 'Sektor teknologi dan perbankan syariah menjadi pendorong utama kenaikan indeks',
        source: 'Bisnis.com',
        published_at: new Date(Date.now() - 3600000).toISOString(),
        category: 'market',
        url: '#'
      }
    ] : [
      {
        title: 'Apple Reports Strong Q4 Earnings, Beats Expectations',
        summary: 'iPhone sales drive revenue growth as company maintains Shariah compliance',
        source: 'Reuters',
        published_at: new Date().toISOString(),
        category: 'company',
        url: '#'
      },
      {
        title: 'Islamic Finance ETFs See Record Inflows This Quarter',
        summary: 'Growing demand for Shariah-compliant investments drives market growth',
        source: 'Bloomberg',
        published_at: new Date(Date.now() - 7200000).toISOString(),
        category: 'market',
        url: '#'
      }
    ];
    
    return NextResponse.json({ success: true, data: sampleNews });
  }
  
  return NextResponse.json({ success: true, data });
}

// Get user preferences
async function getUserPreferences(supabase: any, request: NextRequest) {
  // For now, return default preferences
  // In production, get user_id from auth and fetch real preferences
  const defaultPreferences = {
    preferred_market: 'IDX',
    preferred_timeframe: 'daily',
    language: 'id',
    currency: 'IDR',
    theme: 'light',
    notifications_enabled: true,
    email_alerts: false,
    push_alerts: true
  };

  return NextResponse.json({ success: true, data: defaultPreferences });
}

// Get search history
async function getSearchHistory(supabase: any, request: NextRequest) {
  // Return sample search history
  const sampleHistory = [
    { query: 'BRIS saham syariah', created_at: new Date().toISOString() },
    { query: 'Apple stock analysis', created_at: new Date(Date.now() - 86400000).toISOString() },
    { query: 'teknologi syariah', created_at: new Date(Date.now() - 172800000).toISOString() }
  ];

  return NextResponse.json({ success: true, data: sampleHistory });
}

// Save chat history
async function saveChatHistory(supabase: any, body: any) {
  const { user_id, message, response, session_id } = body;

  const { data, error } = await supabase
    .from('ai_chat_history')
    .insert({
      user_id,
      message,
      response,
      session_id: session_id || crypto.randomUUID()
    })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ success: true, data });
}

// Save search history
async function saveSearchHistory(supabase: any, body: any) {
  const { user_id, query, results_count, market } = body;

  const { data, error } = await supabase
    .from('search_history')
    .insert({
      user_id,
      query,
      results_count,
      market
    })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ success: true, data });
}

// Update user preferences
async function updateUserPreferences(supabase: any, body: any) {
  const { user_id, preferences } = body;

  const { data, error } = await supabase
    .from('user_preferences')
    .upsert({
      user_id,
      ...preferences
    })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ success: true, data });
}

// Add to watchlist
async function addToWatchlist(supabase: any, body: any) {
  const { user_id, symbol, market } = body;

  // First, get or create default watchlist
  let { data: watchlist } = await supabase
    .from('user_watchlists')
    .select('id')
    .eq('user_id', user_id)
    .eq('is_default', true)
    .single();

  if (!watchlist) {
    const { data: newWatchlist, error: watchlistError } = await supabase
      .from('user_watchlists')
      .insert({
        user_id,
        name: 'My Watchlist',
        is_default: true
      })
      .select()
      .single();

    if (watchlistError) throw watchlistError;
    watchlist = newWatchlist;
  }

  // Get stock_id
  const { data: stock } = await supabase
    .from('shariah_stocks')
    .select('id')
    .eq('symbol', symbol)
    .eq('market', market)
    .single();

  if (!stock) {
    throw new Error('Stock not found');
  }

  // Add to watchlist
  const { data, error } = await supabase
    .from('watchlist_items')
    .insert({
      watchlist_id: watchlist.id,
      stock_id: stock.id
    })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ success: true, data });
}

// Remove from watchlist
async function removeFromWatchlist(supabase: any, body: any) {
  const { user_id, symbol, market } = body;

  // Get watchlist and stock info
  const { data: watchlist } = await supabase
    .from('user_watchlists')
    .select('id')
    .eq('user_id', user_id)
    .eq('is_default', true)
    .single();

  const { data: stock } = await supabase
    .from('shariah_stocks')
    .select('id')
    .eq('symbol', symbol)
    .eq('market', market)
    .single();

  if (!watchlist || !stock) {
    throw new Error('Watchlist or stock not found');
  }

  // Remove from watchlist
  const { error } = await supabase
    .from('watchlist_items')
    .delete()
    .eq('watchlist_id', watchlist.id)
    .eq('stock_id', stock.id);

  if (error) throw error;
  return NextResponse.json({ success: true });
}
