import { NextRequest, NextResponse } from 'next/server';
import { rateLimiter } from '@/lib/free-market-data-sources';

// Yahoo Finance API (No API key required - BEST FREE OPTION)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    const symbol = searchParams.get('symbol');
    const market = searchParams.get('market') || 'US';

    switch (action) {
      case 'quote':
        return await getYahooQuote(symbol, market);
      
      case 'multiple-quotes':
        const symbols = searchParams.get('symbols')?.split(',') || [];
        return await getMultipleYahooQuotes(symbols);
      
      case 'shariah-stocks':
        return await getShariahStocks(market);
      
      case 'market-news':
        return await getMarketNews(market);
      
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error: any) {
    console.error('Free market data API error:', error);
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}

// Yahoo Finance - Single stock quote
async function getYahooQuote(symbol: string | null, market: string) {
  if (!symbol) {
    throw new Error('Symbol is required');
  }

  // Format symbol for different markets
  const formattedSymbol = market === 'IDX' ? `${symbol}.JK` : symbol;
  
  try {
    // Yahoo Finance Chart API
    const chartResponse = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${formattedSymbol}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      }
    );

    if (!chartResponse.ok) {
      throw new Error(`Yahoo Finance API error: ${chartResponse.status}`);
    }

    const chartData = await chartResponse.json();
    const result = chartData.chart?.result?.[0];
    
    if (!result) {
      throw new Error('No data found for symbol');
    }

    const meta = result.meta;
    const quote = result.indicators?.quote?.[0];
    
    // Calculate change
    const currentPrice = meta.regularMarketPrice || meta.previousClose;
    const previousClose = meta.previousClose;
    const change = currentPrice - previousClose;
    const changePercent = (change / previousClose) * 100;

    const stockData = {
      symbol: symbol,
      company_name: meta.longName || symbol,
      market: market,
      current_price: currentPrice,
      open_price: quote?.open?.[quote.open.length - 1] || meta.regularMarketOpen,
      high_price: quote?.high?.[quote.high.length - 1] || meta.regularMarketDayHigh,
      low_price: quote?.low?.[quote.low.length - 1] || meta.regularMarketDayLow,
      close_price: previousClose,
      volume: quote?.volume?.[quote.volume.length - 1] || meta.regularMarketVolume,
      change: change,
      change_percent: changePercent,
      currency: meta.currency,
      market_cap: meta.marketCap,
      timestamp: new Date().toISOString(),
      data_source: 'yahoo_finance'
    };

    return NextResponse.json({ success: true, data: stockData });

  } catch (error: any) {
    console.error('Yahoo Finance error:', error);
    throw new Error(`Failed to fetch data from Yahoo Finance: ${error.message}`);
  }
}

// Yahoo Finance - Multiple stocks
async function getMultipleYahooQuotes(symbols: string[]) {
  if (symbols.length === 0) {
    throw new Error('At least one symbol is required');
  }

  // Format symbols (add .JK for IDX stocks)
  const formattedSymbols = symbols.map(symbol => {
    return symbol.includes('.JK') ? symbol : 
           (symbol.length <= 4 && !['AAPL', 'MSFT', 'GOOGL', 'TSLA'].includes(symbol)) 
           ? `${symbol}.JK` : symbol;
  });

  try {
    const quotesResponse = await fetch(
      `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${formattedSymbols.join(',')}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      }
    );

    if (!quotesResponse.ok) {
      throw new Error(`Yahoo Finance API error: ${quotesResponse.status}`);
    }

    const quotesData = await quotesResponse.json();
    const quotes = quotesData.quoteResponse?.result || [];

    const stocksData = quotes.map((quote: any) => {
      const change = quote.regularMarketChange || 0;
      const changePercent = quote.regularMarketChangePercent || 0;
      
      return {
        symbol: quote.symbol.replace('.JK', ''),
        company_name: quote.longName || quote.shortName || quote.symbol,
        market: quote.symbol.includes('.JK') ? 'IDX' : 'US',
        current_price: quote.regularMarketPrice,
        open_price: quote.regularMarketOpen,
        high_price: quote.regularMarketDayHigh,
        low_price: quote.regularMarketDayLow,
        close_price: quote.regularMarketPreviousClose,
        volume: quote.regularMarketVolume,
        change: change,
        change_percent: changePercent,
        currency: quote.currency,
        market_cap: quote.marketCap,
        timestamp: new Date().toISOString(),
        data_source: 'yahoo_finance'
      };
    });

    return NextResponse.json({ success: true, data: stocksData });

  } catch (error: any) {
    console.error('Yahoo Finance multiple quotes error:', error);
    throw new Error(`Failed to fetch multiple quotes: ${error.message}`);
  }
}

// Get Shariah-compliant stocks list
async function getShariahStocks(market: string) {
  const shariahStocks = {
    IDX: [
      { symbol: 'BRIS', name: 'Bank BRISyariah Tbk', sector: 'Financial Services' },
      { symbol: 'UNVR', name: 'Unilever Indonesia Tbk', sector: 'Consumer Goods' },
      { symbol: 'TLKM', name: 'Telkom Indonesia Tbk', sector: 'Telecommunications' },
      { symbol: 'GOTO', name: 'GoTo Gojek Tokopedia Tbk', sector: 'Technology' },
      { symbol: 'ICBP', name: 'Indofood CBP Sukses Makmur Tbk', sector: 'Consumer Goods' },
      { symbol: 'INDF', name: 'Indofood Sukses Makmur Tbk', sector: 'Consumer Goods' },
      { symbol: 'KLBF', name: 'Kalbe Farma Tbk', sector: 'Healthcare' },
      { symbol: 'ASII', name: 'Astra International Tbk', sector: 'Automotive' },
      { symbol: 'ADRO', name: 'Adaro Energy Tbk', sector: 'Mining' },
      { symbol: 'PTBA', name: 'Bukit Asam Tbk', sector: 'Mining' }
    ],
    US: [
      { symbol: 'AAPL', name: 'Apple Inc', sector: 'Technology' },
      { symbol: 'MSFT', name: 'Microsoft Corporation', sector: 'Technology' },
      { symbol: 'GOOGL', name: 'Alphabet Inc', sector: 'Technology' },
      { symbol: 'TSLA', name: 'Tesla Inc', sector: 'Automotive' },
      { symbol: 'JNJ', name: 'Johnson & Johnson', sector: 'Healthcare' },
      { symbol: 'PFE', name: 'Pfizer Inc', sector: 'Healthcare' },
      { symbol: 'KO', name: 'The Coca-Cola Company', sector: 'Consumer Goods' },
      { symbol: 'PEP', name: 'PepsiCo Inc', sector: 'Consumer Goods' },
      { symbol: 'WMT', name: 'Walmart Inc', sector: 'Retail' },
      { symbol: 'HD', name: 'The Home Depot Inc', sector: 'Retail' }
    ]
  };

  const stocks = shariahStocks[market as keyof typeof shariahStocks] || [];
  
  return NextResponse.json({ 
    success: true, 
    data: stocks.map(stock => ({
      ...stock,
      market,
      shariah_compliant: true,
      last_reviewed: new Date().toISOString().split('T')[0]
    }))
  });
}

// Get market news (sample data since we're avoiding paid APIs)
async function getMarketNews(market: string) {
  const sampleNews = {
    IDX: [
      {
        title: 'Bank Syariah Indonesia Raih Laba Bersih Rp 2,1 Triliun di Q3 2024',
        summary: 'BSI mencatat pertumbuhan laba yang signifikan didukung ekspansi pembiayaan syariah dan peningkatan fee based income.',
        source: 'Kontan',
        published_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        category: 'company',
        market: 'IDX',
        sentiment: 'positive',
        related_symbols: ['BRIS']
      },
      {
        title: 'Indeks Saham Syariah Indonesia Menguat 1,2% di Penutupan Hari Ini',
        summary: 'Sektor teknologi dan perbankan syariah menjadi pendorong utama kenaikan ISSI dengan volume transaksi meningkat 15%.',
        source: 'Bisnis.com',
        published_at: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
        category: 'market',
        market: 'IDX',
        sentiment: 'positive',
        related_symbols: ['BRIS', 'GOTO', 'TLKM']
      },
      {
        title: 'GoTo Luncurkan Fitur Investasi Syariah untuk Pengguna GoPay',
        summary: 'Platform digital terdepan Indonesia menghadirkan layanan investasi syariah terintegrasi dengan ekosistem digital.',
        source: 'Tempo',
        published_at: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
        category: 'company',
        market: 'IDX',
        sentiment: 'positive',
        related_symbols: ['GOTO']
      }
    ],
    US: [
      {
        title: 'Apple Reports Strong Q4 Earnings, iPhone Sales Drive Growth',
        summary: 'Apple exceeded expectations with $89.5B revenue, maintaining its position as a Shariah-compliant technology leader.',
        source: 'Reuters',
        published_at: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
        category: 'company',
        market: 'US',
        sentiment: 'positive',
        related_symbols: ['AAPL']
      },
      {
        title: 'Islamic Finance ETFs See Record Inflows This Quarter',
        summary: 'Shariah-compliant investment funds attract $2.3B in new investments as demand for ethical investing grows globally.',
        source: 'Bloomberg',
        published_at: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
        category: 'market',
        market: 'US',
        sentiment: 'positive',
        related_symbols: ['AAPL', 'MSFT', 'GOOGL']
      },
      {
        title: 'Microsoft Azure Continues Cloud Market Dominance',
        summary: 'Microsoft maintains strong position in cloud computing with 31% market share, supporting Shariah-compliant business operations.',
        source: 'TechCrunch',
        published_at: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
        category: 'company',
        market: 'US',
        sentiment: 'positive',
        related_symbols: ['MSFT']
      }
    ]
  };

  const news = sampleNews[market as keyof typeof sampleNews] || [];
  
  return NextResponse.json({ success: true, data: news });
}
