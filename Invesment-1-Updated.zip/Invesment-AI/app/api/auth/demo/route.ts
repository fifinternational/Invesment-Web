import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    // Demo login validation
    if (email === 'demo@example.com' && password === 'demo123') {
      const demoUser = {
        email: 'demo@example.com',
        id: 'demo-user-id',
        role: 'user',
        name: 'Demo User'
      }

      // Create response with user data
      const response = NextResponse.json({ 
        success: true, 
        user: demoUser 
      })

      // Set authentication cookie
      response.cookies.set('isLoggedIn', 'true', {
        httpOnly: false,
        secure: false,
        sameSite: 'lax',
        maxAge: 24 * 60 * 60, // 24 hours
        path: '/'
      })

      return response
    }

    return NextResponse.json({ 
      success: false, 
      error: 'Invalid demo credentials' 
    }, { status: 401 })

  } catch (error) {
    console.error('Demo auth error:', error)
    return NextResponse.json({ 
      success: false, 
      error: 'Authentication failed' 
    }, { status: 500 })
  }
}
