import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';

// Rate limiting store (in production, use Redis)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

// Rate limiting function
function checkRateLimit(source: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const key = source;
  const current = rateLimitStore.get(key);

  if (!current || now > current.resetTime) {
    rateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
    return true;
  }

  if (current.count >= limit) {
    return false;
  }

  current.count++;
  return true;
}

// Alpha Vantage API calls
async function fetchAlphaVantageData(endpoint: string) {
  if (!checkRateLimit('alpha_vantage', 5, 60000)) {
    throw new Error('Rate limit exceeded for Alpha Vantage');
  }

  const response = await fetch(`https://www.alphavantage.co/query${endpoint}`);
  if (!response.ok) {
    throw new Error(`Alpha Vantage API error: ${response.statusText}`);
  }
  return response.json();
}

// Finnhub API calls
async function fetchFinnhubData(endpoint: string) {
  if (!checkRateLimit('finnhub', 60, 60000)) {
    throw new Error('Rate limit exceeded for Finnhub');
  }

  const response = await fetch(`https://finnhub.io/api/v1${endpoint}`);
  if (!response.ok) {
    throw new Error(`Finnhub API error: ${response.statusText}`);
  }
  return response.json();
}

// NewsAPI calls
async function fetchNewsData(endpoint: string) {
  if (!checkRateLimit('newsapi', 100, 3600000)) { // 100 per hour
    throw new Error('Rate limit exceeded for NewsAPI');
  }

  const response = await fetch(`https://newsapi.org/v2${endpoint}`);
  if (!response.ok) {
    throw new Error(`NewsAPI error: ${response.statusText}`);
  }
  return response.json();
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    const symbol = searchParams.get('symbol');
    const market = searchParams.get('market');

    // Initialize Supabase client
    const cookieStore = await cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value;
          },
          set(name: string, value: string, options: any) {
            cookieStore.set({ name, value, ...options });
          },
          remove(name: string, options: any) {
            cookieStore.set({ name, value: '', ...options });
          },
        },
      }
    );

    switch (action) {
      case 'quote':
        return await handleQuoteRequest(symbol!, market!, supabase);
      
      case 'news':
        return await handleNewsRequest(symbol, market, supabase);
      
      case 'shariah-stocks':
        return await handleShariahStocksRequest(market!, supabase);
      
      case 'watchlist':
        return await handleWatchlistRequest(request, supabase);
      
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error: any) {
    console.error('Market data API error:', error);
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}

async function handleQuoteRequest(symbol: string, market: string, supabase: any) {
  try {
    // Try Alpha Vantage first
    let data;
    try {
      const endpoint = `?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${process.env.ALPHA_VANTAGE_API_KEY}`;
      data = await fetchAlphaVantageData(endpoint);
      
      if (data['Global Quote']) {
        const quote = data['Global Quote'];
        const priceData = {
          symbol: quote['01. symbol'],
          price: parseFloat(quote['05. price']),
          change: parseFloat(quote['09. change']),
          changePercent: parseFloat(quote['10. change percent'].replace('%', '')),
          volume: parseInt(quote['06. volume']),
          open: parseFloat(quote['02. open']),
          high: parseFloat(quote['03. high']),
          low: parseFloat(quote['04. low']),
          previousClose: parseFloat(quote['08. previous close']),
          source: 'alpha_vantage',
          timestamp: new Date().toISOString()
        };

        // Store in Supabase
        await supabase.from('stock_prices').insert({
          symbol: priceData.symbol,
          market: market,
          price: priceData.price,
          open_price: priceData.open,
          high_price: priceData.high,
          low_price: priceData.low,
          volume: priceData.volume,
          change_amount: priceData.change,
          change_percent: priceData.changePercent,
          data_source: 'alpha_vantage'
        });

        return NextResponse.json({ success: true, data: priceData });
      }
    } catch (alphaError) {
      console.log('Alpha Vantage failed, trying Finnhub:', alphaError);
    }

    // Fallback to Finnhub
    try {
      const endpoint = `/quote?symbol=${symbol}&token=${process.env.FINNHUB_API_KEY}`;
      data = await fetchFinnhubData(endpoint);
      
      if (data.c) {
        const priceData = {
          symbol: symbol,
          price: data.c, // current price
          change: data.d, // change
          changePercent: data.dp, // change percent
          open: data.o,
          high: data.h,
          low: data.l,
          previousClose: data.pc,
          source: 'finnhub',
          timestamp: new Date().toISOString()
        };

        // Store in Supabase
        await supabase.from('stock_prices').insert({
          symbol: priceData.symbol,
          market: market,
          price: priceData.price,
          open_price: priceData.open,
          high_price: priceData.high,
          low_price: priceData.low,
          change_amount: priceData.change,
          change_percent: priceData.changePercent,
          data_source: 'finnhub'
        });

        return NextResponse.json({ success: true, data: priceData });
      }
    } catch (finnhubError) {
      console.error('Finnhub also failed:', finnhubError);
    }

    return NextResponse.json({ error: 'Unable to fetch quote data' }, { status: 503 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

async function handleNewsRequest(symbol: string | null, market: string | null, supabase: any) {
  try {
    let articles: any[] = [];

    // Fetch from multiple sources
    if (symbol) {
      // Company-specific news from Finnhub
      try {
        const endpoint = `/company-news?symbol=${symbol}&from=${new Date(Date.now() - 7*24*60*60*1000).toISOString().split('T')[0]}&to=${new Date().toISOString().split('T')[0]}&token=${process.env.FINNHUB_API_KEY}`;
        const finnhubNews = await fetchFinnhubData(endpoint);
        
        articles = articles.concat(finnhubNews.map((article: any) => ({
          title: article.headline,
          summary: article.summary,
          url: article.url,
          source: article.source,
          published_at: new Date(article.datetime * 1000).toISOString(),
          category: 'company',
          market: market || 'US',
          related_symbols: [symbol],
          image_url: article.image
        })));
      } catch (error) {
        console.log('Finnhub news failed:', error);
      }
    }

    // General market news from NewsAPI
    try {
      const query = market === 'IDX' ? 'Indonesia stock market' : 'US stock market';
      const endpoint = `/everything?q=${encodeURIComponent(query)}&language=en&sortBy=publishedAt&pageSize=20&apiKey=${process.env.NEWS_API_KEY}`;
      const newsApiData = await fetchNewsData(endpoint);
      
      if (newsApiData.articles) {
        articles = articles.concat(newsApiData.articles.map((article: any) => ({
          title: article.title,
          summary: article.description,
          content: article.content,
          url: article.url,
          source: article.source.name,
          author: article.author,
          published_at: article.publishedAt,
          category: 'market',
          market: market || 'GLOBAL',
          image_url: article.urlToImage
        })));
      }
    } catch (error) {
      console.log('NewsAPI failed:', error);
    }

    // Store news in Supabase
    if (articles.length > 0) {
      await supabase.from('market_news').upsert(articles, {
        onConflict: 'url',
        ignoreDuplicates: true
      });
    }

    return NextResponse.json({ success: true, data: articles });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

async function handleShariahStocksRequest(market: string, supabase: any) {
  try {
    // Fetch from Supabase first
    const { data: existingStocks, error } = await supabase
      .from('shariah_stocks')
      .select('*')
      .eq('market', market)
      .order('company_name');

    if (error) throw error;

    return NextResponse.json({ success: true, data: existingStocks });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

async function handleWatchlistRequest(request: NextRequest, supabase: any) {
  const method = request.method;
  
  if (method === 'GET') {
    // Get user's watchlists
    const { data, error } = await supabase
      .from('user_watchlists')
      .select(`
        *,
        watchlist_items (
          *,
          shariah_stocks (*)
        )
      `)
      .order('created_at');

    if (error) throw error;
    return NextResponse.json({ success: true, data });
  }

  return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    const cookieStore = await cookies();
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value;
          },
          set(name: string, value: string, options: any) {
            cookieStore.set({ name, value, ...options });
          },
          remove(name: string, options: any) {
            cookieStore.set({ name, value: '', ...options });
          },
        },
      }
    );

    switch (action) {
      case 'sync-shariah-stocks':
        return await syncShariahStocks(supabase);
      
      case 'create-watchlist':
        return await createWatchlist(body, supabase);
      
      case 'add-to-watchlist':
        return await addToWatchlist(body, supabase);
      
      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

async function syncShariahStocks(supabase: any) {
  // Predefined shariah-compliant stocks
  const idxStocks = [
    { symbol: 'BRIS', company_name: 'Bank BRISyariah Tbk', sector: 'Financial Services', industry: 'Islamic Banking' },
    { symbol: 'UNVR', company_name: 'Unilever Indonesia Tbk', sector: 'Consumer Goods', industry: 'Personal Care' },
    { symbol: 'TLKM', company_name: 'Telkom Indonesia Tbk', sector: 'Telecommunications', industry: 'Telecommunications' },
    { symbol: 'GOTO', company_name: 'GoTo Gojek Tokopedia Tbk', sector: 'Technology', industry: 'Internet Services' },
    { symbol: 'PTBA', company_name: 'Bukit Asam Tbk', sector: 'Mining', industry: 'Coal Mining' }
  ];

  const usStocks = [
    { symbol: 'AAPL', company_name: 'Apple Inc.', sector: 'Technology', industry: 'Consumer Electronics' },
    { symbol: 'MSFT', company_name: 'Microsoft Corporation', sector: 'Technology', industry: 'Software' },
    { symbol: 'GOOGL', company_name: 'Alphabet Inc.', sector: 'Technology', industry: 'Internet Services' },
    { symbol: 'TSLA', company_name: 'Tesla Inc.', sector: 'Automotive', industry: 'Electric Vehicles' },
    { symbol: 'JNJ', company_name: 'Johnson & Johnson', sector: 'Healthcare', industry: 'Pharmaceuticals' }
  ];

  try {
    // Insert IDX stocks
    const idxData = idxStocks.map(stock => ({
      ...stock,
      market: 'IDX',
      currency: 'IDR',
      shariah_compliant: true,
      shariah_board: 'DSN-MUI'
    }));

    // Insert US stocks
    const usData = usStocks.map(stock => ({
      ...stock,
      market: 'US',
      currency: 'USD',
      shariah_compliant: true,
      shariah_board: 'MSCI'
    }));

    const { error: idxError } = await supabase
      .from('shariah_stocks')
      .upsert(idxData, { onConflict: 'symbol,market' });

    const { error: usError } = await supabase
      .from('shariah_stocks')
      .upsert(usData, { onConflict: 'symbol,market' });

    if (idxError) throw idxError;
    if (usError) throw usError;

    return NextResponse.json({ 
      success: true, 
      message: `Synced ${idxStocks.length} IDX and ${usStocks.length} US shariah stocks` 
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

async function createWatchlist(body: any, supabase: any) {
  const { name, description, user_id } = body;

  const { data, error } = await supabase
    .from('user_watchlists')
    .insert({ name, description, user_id })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ success: true, data });
}

async function addToWatchlist(body: any, supabase: any) {
  const { watchlist_id, stock_id } = body;

  const { data, error } = await supabase
    .from('watchlist_items')
    .insert({ watchlist_id, stock_id })
    .select()
    .single();

  if (error) throw error;
  return NextResponse.json({ success: true, data });
}
