import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] via-white to-[#ccfbf1]">
      <div className="container mx-auto py-12 px-4 md:px-6">
        <div className="mb-8">
          <Link 
            href="/"
            className="inline-flex items-center text-sm font-medium text-teal-600 hover:text-teal-700 transition-colors duration-200"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6 md:p-8 max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Privacy Policy</h1>
          
          <div className="prose prose-teal max-w-none">
            <p className="text-gray-600 mb-4" suppressHydrationWarning>
              Last updated: {new Date().toLocaleDateString('en-US', {day: 'numeric', month: 'long', year: 'numeric'})}
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">1. Pendahuluan</h2>
            <p className="text-gray-600 mb-4">
              Kami di Invesment menghargai privasi Anda dan berkomitmen untuk melindungi data pribadi Anda. Kebijakan Privasi ini menjelaskan bagaimana kami mengumpulkan, menggunakan, mengungkapkan, dan melindungi informasi pribadi Anda saat Anda menggunakan layanan kami, termasuk situs web, aplikasi, dan layanan terkait (secara kolektif disebut sebagai "Layanan").
            </p>
            <p className="text-gray-600 mb-4">
              Dengan mengakses atau menggunakan Layanan kami, Anda menyetujui praktik yang dijelaskan dalam Kebijakan Privasi ini. Jika Anda tidak setuju dengan Kebijakan Privasi ini, harap jangan gunakan Layanan kami.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">2. Informasi yang Kami Kumpulkan</h2>
            <p className="text-gray-600 mb-4">
              Kami mengumpulkan beberapa jenis informasi dari dan tentang pengguna Layanan kami, termasuk:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-600">
              <li><strong>Informasi Identitas Pribadi:</strong> Seperti nama, alamat email, alamat pos, nomor telepon, dan informasi identifikasi lainnya saat Anda mendaftar akun atau berkomunikasi dengan kami.</li>
              <li><strong>Informasi Keuangan:</strong> Seperti detail rekening bank, informasi kartu kredit, dan riwayat transaksi saat Anda menggunakan layanan investasi kami.</li>
              <li><strong>Informasi Profil:</strong> Seperti nama pengguna, kata sandi, preferensi investasi, umpan balik, dan tanggapan survei.</li>
              <li><strong>Informasi Penggunaan:</strong> Seperti bagaimana dan kapan Anda menggunakan Layanan kami, perangkat keras dan perangkat lunak yang Anda gunakan untuk mengakses Layanan kami, dan informasi lain tentang interaksi Anda dengan Layanan kami.</li>
              <li><strong>Informasi Teknis:</strong> Seperti alamat IP, jenis dan versi browser, pengaturan zona waktu, jenis dan versi plugin browser, sistem operasi dan platform, dan teknologi lain pada perangkat yang Anda gunakan untuk mengakses Layanan kami.</li>
              <li><strong>Data Lokasi:</strong> Seperti lokasi geografis Anda berdasarkan alamat IP atau informasi lokasi yang lebih tepat jika Anda mengizinkan kami mengakses lokasi perangkat Anda.</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">3. Bagaimana Kami Mengumpulkan Informasi Anda</h2>
            <p className="text-gray-600 mb-4">
              Kami mengumpulkan informasi melalui berbagai metode, termasuk:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-600">
              <li><strong>Interaksi Langsung:</strong> Anda dapat memberikan kami informasi identitas, kontak, dan keuangan dengan mengisi formulir atau berkomunikasi dengan kami melalui pos, telepon, email, atau lainnya.</li>
              <li><strong>Teknologi Otomatis:</strong> Saat Anda berinteraksi dengan Layanan kami, kami dapat mengumpulkan informasi teknis tentang perangkat Anda, tindakan dan pola browsing Anda secara otomatis menggunakan cookie, log server, dan teknologi pelacakan serupa.</li>
              <li><strong>Pihak Ketiga:</strong> Kami dapat menerima informasi tentang Anda dari berbagai pihak ketiga, seperti mitra bisnis, penyedia analitik, penyedia informasi pencarian, dan penyedia identitas.</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">4. Bagaimana Kami Menggunakan Informasi Anda</h2>
            <p className="text-gray-600 mb-4">
              Kami menggunakan informasi yang kami kumpulkan tentang Anda untuk berbagai tujuan, termasuk:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-600">
              <li>Menyediakan, memelihara, dan meningkatkan Layanan kami.</li>
              <li>Memproses transaksi dan mengelola akun Anda.</li>
              <li>Mengirim informasi administratif, seperti perubahan pada syarat, ketentuan, dan kebijakan kami.</li>
              <li>Memberikan dukungan pelanggan dan menanggapi permintaan, pertanyaan, dan umpan balik Anda.</li>
              <li>Mengirim komunikasi pemasaran dan promosi yang mungkin menarik bagi Anda.</li>
              <li>Mempersonalisasi pengalaman Anda dan memberikan konten dan fitur yang mungkin paling relevan dan menarik bagi Anda.</li>
              <li>Memantau dan menganalisis tren, penggunaan, dan aktivitas terkait Layanan kami.</li>
              <li>Mendeteksi, menyelidiki, dan mencegah transaksi penipuan dan aktivitas ilegal lainnya.</li>
              <li>Melindungi hak, properti, atau keselamatan kami, pengguna Layanan kami, atau orang lain.</li>
              <li>Mematuhi kewajiban hukum dan peraturan.</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">5. Pengungkapan Informasi Anda</h2>
            <p className="text-gray-600 mb-4">
              Kami dapat mengungkapkan informasi pribadi yang kami kumpulkan kepada pihak ketiga dalam keadaan tertentu, termasuk:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-600">
              <li><strong>Penyedia Layanan:</strong> Kami dapat membagikan informasi Anda dengan penyedia layanan pihak ketiga yang melakukan layanan atas nama kami, seperti pemrosesan pembayaran, analisis data, pengiriman email, hosting, layanan pelanggan, dan pemasaran.</li>
              <li><strong>Mitra Bisnis:</strong> Kami dapat membagikan informasi Anda dengan mitra bisnis untuk menawarkan produk atau layanan tertentu kepada Anda.</li>
              <li><strong>Afiliasi:</strong> Kami dapat membagikan informasi Anda dengan afiliasi kami, yang dapat menggunakan informasi tersebut untuk tujuan yang dijelaskan dalam Kebijakan Privasi ini.</li>
              <li><strong>Kepatuhan Hukum:</strong> Kami dapat mengungkapkan informasi Anda untuk mematuhi hukum, peraturan, proses hukum, atau permintaan pemerintah yang berlaku.</li>
              <li><strong>Perlindungan Hak:</strong> Kami dapat mengungkapkan informasi Anda untuk menegakkan perjanjian kami, melindungi hak, properti, atau keselamatan kami, pengguna Layanan kami, atau orang lain.</li>
              <li><strong>Transaksi Bisnis:</strong> Kami dapat mengungkapkan informasi Anda dalam konteks merger, akuisisi, penjualan aset, atau transaksi bisnis serupa.</li>
              <li><strong>Dengan Persetujuan Anda:</strong> Kami dapat membagikan informasi Anda dengan pihak ketiga ketika Anda telah menyetujui pengungkapan tersebut.</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">6. Keamanan Data</h2>
            <p className="text-gray-600 mb-4">
              Kami telah menerapkan langkah-langkah keamanan yang dirancang untuk melindungi informasi pribadi Anda dari kehilangan, penyalahgunaan, dan akses, pengungkapan, perubahan, dan penghancuran yang tidak sah. Namun, tidak ada metode transmisi melalui Internet atau metode penyimpanan elektronik yang 100% aman. Oleh karena itu, meskipun kami berusaha untuk menggunakan cara yang dapat diterima secara komersial untuk melindungi informasi pribadi Anda, kami tidak dapat menjamin keamanan absolutnya.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">7. Retensi Data</h2>
            <p className="text-gray-600 mb-4">
              Kami akan menyimpan informasi pribadi Anda hanya selama diperlukan untuk memenuhi tujuan yang kami kumpulkan, termasuk untuk tujuan memenuhi persyaratan hukum, akuntansi, atau pelaporan. Untuk menentukan periode retensi yang sesuai untuk informasi pribadi, kami mempertimbangkan jumlah, sifat, dan sensitivitas informasi pribadi, potensi risiko bahaya dari penggunaan atau pengungkapan yang tidak sah, tujuan yang kami proses informasi pribadi Anda, apakah kami dapat mencapai tujuan tersebut melalui cara lain, dan persyaratan hukum yang berlaku.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">8. Hak Privasi Anda</h2>
            <p className="text-gray-600 mb-4">
              Tergantung pada lokasi Anda, Anda mungkin memiliki hak tertentu terkait dengan informasi pribadi Anda, termasuk:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-600">
              <li>Hak untuk mengakses informasi pribadi Anda.</li>
              <li>Hak untuk memperbaiki atau memperbarui informasi pribadi Anda.</li>
              <li>Hak untuk menghapus informasi pribadi Anda.</li>
              <li>Hak untuk membatasi pemrosesan informasi pribadi Anda.</li>
              <li>Hak untuk menolak pemrosesan informasi pribadi Anda.</li>
              <li>Hak atas portabilitas data.</li>
              <li>Hak untuk menarik persetujuan.</li>
              <li>Hak untuk mengajukan keluhan kepada otoritas pengawas.</li>
            </ul>
            <p className="text-gray-600 mb-4">
              Untuk menggunakan hak-hak ini, silakan hubungi kami menggunakan detail kontak yang disediakan di bawah ini. Harap dicatat bahwa hak-hak ini mungkin tidak mutlak, dan kami mungkin berhak untuk menolak permintaan dalam keadaan tertentu.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">9. Cookies and Tracking Technologies</h2>
            <p className="text-gray-600 mb-4">
              We use cookies and similar tracking technologies to collect and use personal information about you, including to serve interest-based advertising. For more information about the types of cookies we use, why, and how you can control cookies, please see our Cookie Policy.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">10. International Data Transfers</h2>
            <p className="text-gray-600 mb-4">
              Your personal information may be transferred to, and processed in, countries other than the country in which you reside. These countries may have data protection laws that are different from the laws of your country. Specifically, our servers are located in the United States, and our third-party service providers and partners may be located in other countries.
            </p>
            <p className="text-gray-600 mb-4">
              By providing your personal information, you acknowledge this transfer, storage, and processing. We will take all commercially reasonable steps to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your personal information to an organization or country will occur unless there are adequate controls in place including the security of your data and other personal information.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">11. Children's Privacy</h2>
            <p className="text-gray-600 mb-4">
              Our Services are not intended for children under 18 years of age, and we do not knowingly collect personal information from children under 18. If you are a parent or guardian and believe that your child has provided us with personal information, please contact us. If we learn that we have collected personal information from children without verification of parental consent, we will take steps to delete that information from our servers.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">12. Changes to This Privacy Policy</h2>
            <p className="text-gray-600 mb-4">
              We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and, if the changes are significant, we will provide a more prominent notice or, in certain cases, send a notification via email. We encourage you to review this Privacy Policy periodically to stay informed about any changes.
            </p>
            <p className="text-gray-600 mb-4">
              The "Last updated" date at the top of this Privacy Policy indicates when this policy was last revised. Changes will become effective immediately after the updated Privacy Policy is posted on the Services.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">13. Financial Research Disclaimer</h2>
            <p className="text-gray-600 mb-4">
              THE INFORMATION PROVIDED THROUGH OUR SERVICES IS FOR INFORMATIONAL PURPOSES ONLY. OUR WEBSITE PROVIDES PROFESSIONAL FINANCIAL RESEARCH ADVICE AND RECOMMENDATIONS. WE ARE NOT RESPONSIBLE FOR ANY FINANCIAL LOSSES OR DAMAGES INCURRED AS A RESULT OF USING OUR SERVICES OR RELYING ON THE INFORMATION PROVIDED.
            </p>
            <p className="text-gray-600 mb-4">
              ALL PAYMENTS MADE FOR OUR SERVICES ARE NON-REFUNDABLE. WE DO NOT GUARANTEE FINANCIAL RETURNS OR PROFITS FROM USING OUR RESEARCH SERVICES. ANY DECISION TO INVEST BASED ON OUR CONTENT IS MADE AT YOUR OWN RISK.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">14. Contact Us</h2>
            <p className="text-gray-600 mb-4">
              If you have any questions, comments, or concerns about this Privacy Policy or our privacy practices, please contact us at:<br />
              Email: privacy@invesment.com<br />
              Phone: +1 (555) 123-4567<br />
              Address: 123 Investment St., New York, NY, USA
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}