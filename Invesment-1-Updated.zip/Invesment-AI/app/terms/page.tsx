import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#f0fdfa] via-white to-[#ccfbf1]">
      <div className="container mx-auto py-12 px-4 md:px-6">
        <div className="mb-8">
          <Link 
            href="/"
            className="inline-flex items-center text-sm font-medium text-teal-600 hover:text-teal-700 transition-colors duration-200"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
        </div>
        
        <div className="bg-white rounded-xl shadow-md p-6 md:p-8 max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">Terms and Conditions</h1>
          
          <div className="prose prose-teal max-w-none">
            <p className="text-gray-600 mb-4" suppressHydrationWarning>
              Last updated: {new Date().toLocaleDateString('en-US', {day: 'numeric', month: 'long', year: 'numeric'})}
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">1. Introduction</h2>
            <p className="text-gray-600 mb-4">
              Welcome to our financial research platform. These Terms and Conditions govern your use of the services provided by our platform, including the website, applications, and related services (collectively referred to as the "Services").
            </p>
            <p className="text-gray-600 mb-4">
              By accessing or using our Services, you agree to be bound by these Terms and Conditions. If you do not agree with any part of this document, you must not access the Services.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">2. Definitions</h2>
            <p className="text-gray-600 mb-4">
              "User" refers to individuals who access or use our Services.<br />
              "Content" refers to all information, data, text, images, graphics, or other materials displayed or available through the Services.<br />
              "Account" refers to the user registration required to access certain features of the Services.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">3. Account Registration</h2>
            <p className="text-gray-600 mb-4">
              To access certain features of our Services, you may be required to register an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.
            </p>
            <p className="text-gray-600 mb-4">
              You are responsible for maintaining the confidentiality of your password and for all activities that occur under your account. You agree to immediately notify us of any unauthorized use of your account or password.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">4. Financial Research Services</h2>
            <p className="text-gray-600 mb-4">
              Our Services provide information and tools to assist users in making investment decisions. The information provided through our Services is for informational purposes only.
            </p>
            <p className="text-gray-600 mb-4">
              All investments involve risk, and past performance of securities, indices, or other financial instruments does not guarantee future results. You should conduct your own research before making any investment decisions.
            </p>
            <p className="text-gray-600 mb-4">
              Financial Research Disclaimer: We are not responsible for any financial losses incurred as a result of using our Services. The financial information provided is for professional financial research advice and recommendations. Users are solely responsible for their investment decisions and any resulting outcomes.
            </p>
            <p className="text-gray-600 mb-4">
              No Refund Policy: All subscription payments for our financial research Services are final and non-refundable. By subscribing to our Services, you acknowledge and agree that we do not provide refunds for any reason, including but not limited to dissatisfaction with the research, financial losses, or change of mind.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">5. Intellectual Property Rights</h2>
            <p className="text-gray-600 mb-4">
              The Services and their content, including but not limited to text, graphics, logos, icons, images, audio clips, digital downloads, data compilations, and software, are the property of us or our licensors and are protected by copyright, trademark, and other intellectual property laws.
            </p>
            <p className="text-gray-600 mb-4">
              You may not reproduce, distribute, modify, create derivative works of, publicly display, publicly perform, republish, download, store, or transmit any of the material on our Services, except as permitted by our Services.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">6. Usage Restrictions</h2>
            <p className="text-gray-600 mb-4">
              You agree not to use our Services:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-600">
              <li>In any way that violates any applicable law or regulation.</li>
              <li>For the purpose of exploiting, harming, or attempting to exploit or harm minors in any way.</li>
              <li>To transmit, receive, upload, download, use, or reuse any material that does not comply with our Content Standards.</li>
              <li>To transmit or procure the sending of any unsolicited or unauthorized advertising or promotional material.</li>
              <li>In any way intended to deceive, mislead, or defraud us or any third party.</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">7. Disclaimer of Warranties</h2>
            <p className="text-gray-600 mb-4">
              Our Services are provided "as is" and "as available" without any warranties of any kind, either express or implied. We do not warrant that our Services will meet your requirements, be uninterrupted, timely, secure, or error-free.
            </p>
            <p className="text-gray-600 mb-4">
              Any advice or information, whether oral or written, obtained by you from us or through our Services will not create any warranty not expressly made in these Terms and Conditions.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">8. Limitation of Liability</h2>
            <p className="text-gray-600 mb-4">
              In no event shall we, our affiliates, or our service providers be liable for any direct, indirect, incidental, consequential, special, or exemplary damages, including but not limited to, loss of profits, data, use, goodwill, or other intangible losses resulting from:
            </p>
            <ul className="list-disc pl-6 mb-4 text-gray-600">
              <li>Your use or inability to use our Services.</li>
              <li>Unauthorized access to or alteration of your transmissions or data.</li>
              <li>Statements or conduct of any third party on our Services.</li>
              <li>Investment decisions made based on information provided through our Services.</li>
              <li>Financial losses of any kind incurred as a result of using our research or services.</li>
            </ul>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">9. Indemnification</h2>
            <p className="text-gray-600 mb-4">
              You agree to defend, indemnify, and hold harmless us, our affiliates, licensors, and service providers, and our and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors, and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys' fees) arising out of or relating to your violation of these Terms and Conditions.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">10. Governing Law</h2>
            <p className="text-gray-600 mb-4">
              These Terms and Conditions shall be governed and construed in accordance with the laws of the United States, without regard to its conflict of law provisions.
            </p>
            <p className="text-gray-600 mb-4">
              Any legal action or proceeding arising out of or related to these Terms and Conditions or the Services shall be settled exclusively in the courts located in the United States, and you agree to submit to the personal jurisdiction of such courts.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">11. Changes to Terms and Conditions</h2>
            <p className="text-gray-600 mb-4">
              We reserve the right, at our sole discretion, to modify or replace these Terms and Conditions at any time. If a revision is material, we will provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
            </p>
            <p className="text-gray-600 mb-4">
              By continuing to access or use our Services after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, you are no longer authorized to use the Services.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">12. Termination</h2>
            <p className="text-gray-600 mb-4">
              We may terminate or suspend your access immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms and Conditions.
            </p>
            <p className="text-gray-600 mb-4">
              All provisions of the Terms and Conditions which by their nature should survive termination shall survive termination, including, without limitation, ownership provisions, warranty disclaimers, indemnity, and limitations of liability.
            </p>
            
            <h2 className="text-xl font-semibold text-gray-800 mt-6 mb-3">13. Contact Us</h2>
            <p className="text-gray-600 mb-4">
              If you have any questions about these Terms and Conditions, please contact us at:<br />
              Email: support@invesment.com<br />
              Phone: +1 (555) 123-4567
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}