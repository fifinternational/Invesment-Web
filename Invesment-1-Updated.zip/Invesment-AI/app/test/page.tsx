"use client"

export default function TestPage() {
  return (
    <div className="p-8 min-h-screen bg-background">
      <h1 className="text-2xl font-bold mb-4 text-foreground">Test Page - Server Working</h1>
      <p className="text-muted-foreground mb-4">Next.js routing and rendering is working correctly.</p>
      
      <div className="space-y-4">
        <div className="p-4 border rounded-lg">
          <h2 className="font-bold">Navigation Tests:</h2>
          <div className="mt-2 space-x-4">
            <a href="/dashboard" className="text-blue-500 underline hover:text-blue-700">
              → Dashboard (Direct)
            </a>
            <a href="/login" className="text-green-500 underline hover:text-green-700">
              → Login Page
            </a>
          </div>
        </div>
        
        <div className="p-4 border rounded-lg">
          <h2 className="font-bold">Status:</h2>
          <ul className="mt-2 space-y-1 text-sm">
            <li>✅ Next.js Server Running</li>
            <li>✅ Middleware Disabled</li>
            <li>✅ Routing Working</li>
            <li>✅ Tailwind CSS Loading</li>
          </ul>
        </div>
      </div>

      <div className="bg-yellow-100 p-4 rounded-lg">
        <h2 className="text-xl font-semibold text-yellow-800">Component Test</h2>
        <p className="text-yellow-600">React component rendering is working.</p>
        <button 
          className="mt-2 px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600"
          onClick={() => alert('Button clicked!')}
        >
          Click Me
        </button>
      </div>
    </div>
  )
}
