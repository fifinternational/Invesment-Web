"use client"

import { useState } from "react"
import { Check, Crown, Zap, Star } from "lucide-react"
import { useSubscription } from "@/contexts/subscription-context"
import { useCurrency } from "@/contexts/currency-context"
import { useLanguage } from "@/contexts/language-context"

export default function SubscriptionPage() {
  const { subscriptionTier, setSubscriptionTier, trialDaysLeft } = useSubscription()
  const { currency } = useCurrency()
  const { t } = useLanguage()
  const [selectedPlan, setSelectedPlan] = useState<string>(subscriptionTier)

  const plans = [
    {
      id: "trial",
      name: "Free Trial",
      price: currency === "IDR" ? "Gratis" : "Free",
      period: `${trialDaysLeft} days left`,
      icon: <Star className="h-6 w-6" />,
      features: [
        "Basic dashboard access",
        "Limited search functionality", 
        "Basic watchlist (5 stocks)",
        "Market overview"
      ],
      limitations: [
        "No AI recommendations",
        "No professional reports",
        "Limited market data"
      ]
    },
    {
      id: "basic",
      name: "Basic Plan",
      price: currency === "IDR" ? "Rp 45,000" : "$3",
      period: "/month",
      icon: <Zap className="h-6 w-6" />,
      features: [
        "Full dashboard access",
        "AI-powered recommendations",
        "AI chat assistant",
        "Full watchlist access",
        "Market analysis tools",
        "Real-time notifications"
      ],
      popular: false
    },
    {
      id: "premium",
      name: "Premium Plan", 
      price: currency === "IDR" ? "Rp 135,000" : "$9",
      period: "/month",
      icon: <Crown className="h-6 w-6" />,
      features: [
        "Everything in Basic",
        "Professional market reports",
        "Advanced analytics",
        "Priority support",
        "Custom alerts",
        "Portfolio optimization",
        "Shariah compliance screening"
      ],
      popular: true
    }
  ]

  const handleUpgrade = (planId: string) => {
    setSubscriptionTier(planId as "trial" | "basic" | "premium")
    setSelectedPlan(planId)
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Choose Your Plan</h1>
          <p className="text-muted-foreground">
            Unlock powerful investment tools and AI-driven insights
          </p>
        </div>

        {/* Current Plan Status */}
        <div className="mb-8 p-4 bg-card rounded-lg border">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-foreground">Current Plan</h3>
              <p className="text-sm text-muted-foreground">
                {subscriptionTier === "trial" && `Free Trial - ${trialDaysLeft} days remaining`}
                {subscriptionTier === "basic" && "Basic Plan - Active"}
                {subscriptionTier === "premium" && "Premium Plan - Active"}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              {subscriptionTier === "trial" && <Star className="h-5 w-5 text-yellow-500" />}
              {subscriptionTier === "basic" && <Zap className="h-5 w-5 text-blue-500" />}
              {subscriptionTier === "premium" && <Crown className="h-5 w-5 text-purple-500" />}
              <span className="font-medium capitalize">{subscriptionTier}</span>
            </div>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative bg-card rounded-xl border p-6 transition-all duration-200 hover:shadow-lg ${
                plan.popular ? "ring-2 ring-primary" : ""
              } ${selectedPlan === plan.id ? "ring-2 ring-primary" : ""}`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                    Most Popular
                  </span>
                </div>
              )}

              <div className="text-center mb-6">
                <div className="flex justify-center mb-3">
                  <div className={`p-3 rounded-full ${
                    plan.id === "trial" ? "bg-yellow-100 text-yellow-600 dark:bg-yellow-900/20 dark:text-yellow-400" :
                    plan.id === "basic" ? "bg-blue-100 text-blue-600 dark:bg-blue-900/20 dark:text-blue-400" :
                    "bg-purple-100 text-purple-600 dark:bg-purple-900/20 dark:text-purple-400"
                  }`}>
                    {plan.icon}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{plan.name}</h3>
                <div className="text-3xl font-bold text-foreground">
                  {plan.price}
                  <span className="text-sm font-normal text-muted-foreground ml-1">
                    {plan.period}
                  </span>
                </div>
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-sm">
                    <Check className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
                {plan.limitations?.map((limitation, index) => (
                  <li key={index} className="flex items-center text-sm opacity-60">
                    <div className="h-4 w-4 mr-3 flex-shrink-0 flex items-center justify-center">
                      <div className="h-1 w-3 bg-muted-foreground rounded"></div>
                    </div>
                    <span className="text-muted-foreground">{limitation}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleUpgrade(plan.id)}
                disabled={subscriptionTier === plan.id}
                className={`w-full py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
                  subscriptionTier === plan.id
                    ? "bg-muted text-muted-foreground cursor-not-allowed"
                    : plan.popular
                    ? "bg-primary text-primary-foreground hover:bg-primary/90"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {subscriptionTier === plan.id ? "Current Plan" : 
                 plan.id === "trial" ? "Continue Trial" : "Upgrade Now"}
              </button>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-card p-6 rounded-lg border">
              <h3 className="font-semibold mb-2">Can I change my plan anytime?</h3>
              <p className="text-sm text-muted-foreground">
                Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately.
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border">
              <h3 className="font-semibold mb-2">What happens after my trial ends?</h3>
              <p className="text-sm text-muted-foreground">
                Your account will be limited to basic features. You can upgrade to continue accessing premium tools.
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border">
              <h3 className="font-semibold mb-2">Is there a refund policy?</h3>
              <p className="text-sm text-muted-foreground">
                We offer a 30-day money-back guarantee for all paid plans if you're not satisfied.
              </p>
            </div>
            <div className="bg-card p-6 rounded-lg border">
              <h3 className="font-semibold mb-2">Do you offer student discounts?</h3>
              <p className="text-sm text-muted-foreground">
                Yes, we offer 50% off for verified students. Contact support with your student ID.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
