"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { createBrowserClient } from "@supabase/ssr"
import { Camera, Edit3, Save, X, User, Mail, Calendar, MapPin, Phone, Briefcase, Globe, Upload, Check, AlertCircle, Crown } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

interface UserProfile {
  id: string
  email: string
  full_name: string
  avatar_url: string
  phone: string
  date_of_birth: string
  location: string
  occupation: string
  bio: string
  website: string
  investment_experience: string
  risk_tolerance: string
  investment_goals: string
  preferred_sectors: string[]
  created_at: string
  last_sign_in_at: string
  email_confirmed_at: string
  provider: string
}

export default function ProfilePage() {
  const router = useRouter()
  const { t } = useLanguage()
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<Partial<UserProfile>>({})
  const [isEditing, setIsEditing] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [mounted, setMounted] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [message, setMessage] = useState({ type: '', text: '' })
  const [uploadingPhoto, setUploadingPhoto] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  const investmentExperienceOptions = [
    { value: 'beginner', label: 'Pemula (< 1 tahun)' },
    { value: 'intermediate', label: 'Menengah (1-5 tahun)' },
    { value: 'advanced', label: 'Berpengalaman (5+ tahun)' },
    { value: 'expert', label: 'Ahli (10+ tahun)' }
  ]

  const riskToleranceOptions = [
    { value: 'conservative', label: 'Konservatif - Risiko Rendah' },
    { value: 'moderate', label: 'Moderat - Risiko Sedang' },
    { value: 'aggressive', label: 'Agresif - Risiko Tinggi' }
  ]

  const sectorOptions = [
    'Teknologi', 'Keuangan Syariah', 'Kesehatan', 'Konsumer', 'Energi',
    'Properti', 'Infrastruktur', 'Pendidikan', 'Pertanian', 'Manufaktur'
  ]

  useEffect(() => {
    setMounted(true)
    loadUserProfile()
  }, [])

  const loadUserProfile = async () => {
    try {
      // Check if user is authenticated
      const { data: { session }, error: sessionError } = await supabase.auth.getSession()
      
      if (sessionError) {
        console.error('Session error:', sessionError)
        router.push('/login')
        return
      }

      if (!session?.user) {
        console.log('No active session, redirecting to login')
        router.push('/login')
        return
      }

      // Skip email confirmation check for Google OAuth users
      if (!session.user.email_confirmed_at && session.user.app_metadata?.provider !== 'google') {
        console.log('Email not confirmed, redirecting to login')
        router.push('/login?message=Please confirm your email first')
        return
      }

      const user = session.user
      setUser(user)

      // Extract data from auth user with better Google data handling
      const authProfile = {
        id: user.id,
        email: user.email || '',
        full_name: user.user_metadata?.full_name || user.user_metadata?.name || user.identities?.[0]?.identity_data?.full_name || '',
        avatar_url: user.user_metadata?.avatar_url || user.user_metadata?.picture || user.identities?.[0]?.identity_data?.avatar_url || user.identities?.[0]?.identity_data?.picture || '',
        created_at: user.created_at,
        last_sign_in_at: user.last_sign_in_at,
        email_confirmed_at: user.email_confirmed_at,
        provider: user.app_metadata?.provider || user.identities?.[0]?.provider || 'email'
      }

      // Try to load additional profile data from profiles table
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single()

      if (profileData) {
        setProfile({ ...authProfile, ...profileData })
      } else {
        // Create initial profile record
        const { error: insertError } = await supabase
          .from('profiles')
          .insert([{
            id: user.id,
            email: authProfile.email,
            full_name: authProfile.full_name,
            avatar_url: authProfile.avatar_url,
            updated_at: new Date().toISOString()
          }])

        if (!insertError) {
          setProfile(authProfile)
        }
      }
    } catch (error) {
      console.error('Error loading profile:', error)
      setMessage({ type: 'error', text: 'Gagal memuat profil' })
    } finally {
      setIsLoading(false)
    }
  }

  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
    if (!allowedTypes.includes(file.type)) {
      setMessage({ type: 'error', text: 'Format file tidak didukung. Gunakan JPG, PNG, atau WebP.' })
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setMessage({ type: 'error', text: 'Ukuran file terlalu besar. Maksimal 5MB.' })
      return
    }

    setUploadingPhoto(true)
    
    try {
      const fileExt = file.name.split('.').pop()
      const fileName = `${user.id}-${Math.floor(Date.now() / 1000)}.${fileExt}`
      const filePath = `avatars/${fileName}`

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, file)

      if (uploadError) {
        throw uploadError
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath)

      // Update profile
      const updatedProfile = { ...profile, avatar_url: publicUrl }
      setProfile(updatedProfile)

      // Save to database
      await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl, updated_at: new Date().toISOString() })
        .eq('id', user.id)

      setMessage({ type: 'success', text: 'Foto profil berhasil diperbarui!' })
    } catch (error) {
      console.error('Error uploading photo:', error)
      setMessage({ type: 'error', text: 'Gagal mengupload foto' })
    } finally {
      setUploadingPhoto(false)
    }
  }

  const handleSaveProfile = async () => {
    setIsSaving(true)
    
    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          ...profile,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id)

      if (error) {
        throw error
      }

      setIsEditing(false)
      setMessage({ type: 'success', text: 'Profil berhasil disimpan!' })
    } catch (error) {
      console.error('Error saving profile:', error)
      setMessage({ type: 'error', text: 'Gagal menyimpan profil' })
    } finally {
      setIsSaving(false)
    }
  }

  const handleSectorToggle = (sector: string) => {
    const currentSectors = profile.preferred_sectors || []
    const updatedSectors = currentSectors.includes(sector)
      ? currentSectors.filter(s => s !== sector)
      : [...currentSectors, sector]
    
    setProfile({ ...profile, preferred_sectors: updatedSectors })
  }

  if (!mounted || isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-card rounded-lg border p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-foreground">User Profile</h1>
            <div className="flex items-center space-x-3">
              <a 
                href="/profile/subscription"
                className="flex items-center space-x-2 px-4 py-2 bg-secondary text-secondary-foreground rounded-lg hover:bg-secondary/80 transition-colors"
              >
                <Crown className="h-4 w-4" />
                <span>Billing & Subscription</span>
              </a>
              <button
                onClick={() => setIsEditing(!isEditing)}
                className="flex items-center space-x-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
              >
                {isEditing ? <X className="h-4 w-4" /> : <Edit3 className="h-4 w-4" />}
                <span>{isEditing ? 'Cancel' : 'Edit Profile'}</span>
              </button>
            </div>
          </div>

          {/* Message */}
          {message.text && (
            <div className={`flex items-center space-x-2 p-3 rounded-lg mb-4 ${
              message.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' :
              'bg-red-50 text-red-700 border border-red-200'
            }`}>
              {message.type === 'success' ? <Check className="h-5 w-5" /> : <AlertCircle className="h-5 w-5" />}
              <span>{message.text}</span>
            </div>
          )}

          {/* Profile Photo and Basic Info */}
          <div className="flex items-start space-x-6">
            <div className="relative">
              <div className="w-32 h-32 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                {profile.avatar_url ? (
                  <img 
                    src={profile.avatar_url} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="h-16 w-16 text-muted-foreground" />
                )}
              </div>
              
              {isEditing && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingPhoto}
                  className="absolute bottom-0 right-0 w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:bg-primary/90 transition-colors"
                >
                  {uploadingPhoto ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
                  ) : (
                    <Camera className="h-4 w-4" />
                  )}
                </button>
              )}
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/jpg,image/png,image/webp"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </div>

            <div className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">
                    Full Name
                  </label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={profile.full_name || ''}
                      onChange={(e) => setProfile({ ...profile, full_name: e.target.value })}
                      className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                    />
                  ) : (
                    <p className="text-foreground">{profile.full_name || 'Not provided'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">
                    Email
                  </label>
                  <p className="text-foreground flex items-center space-x-2">
                    <Mail className="h-4 w-4" />
                    <span>{profile.email}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <span className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span suppressHydrationWarning>Joined: {profile.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : 'Unknown'}</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Globe className="h-4 w-4" />
                  <span>Provider: {profile.provider === 'google' ? 'Google' : 'Email'}</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Information */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Personal Information */}
          <div className="bg-card rounded-lg border p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">Informasi Personal</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">
                  Nomor Telepon
                </label>
                {isEditing ? (
                  <input
                    type="tel"
                    value={profile.phone || ''}
                    onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                    placeholder="+62 812 3456 7890"
                  />
                ) : (
                  <p className="text-foreground flex items-center space-x-2">
                    <Phone className="h-4 w-4" />
                    <span>{profile.phone || 'Belum diisi'}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">
                  Tanggal Lahir
                </label>
                {isEditing ? (
                  <input
                    type="date"
                    value={profile.date_of_birth || ''}
                    onChange={(e) => setProfile({ ...profile, date_of_birth: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                  />
                ) : (
                  <p className="text-foreground">
                    <span suppressHydrationWarning>{profile.date_of_birth ? new Date(profile.date_of_birth).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) : 'Not provided'}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">
                  Lokasi
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    value={profile.location || ''}
                    onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                    placeholder="Jakarta, Indonesia"
                  />
                ) : (
                  <p className="text-foreground flex items-center space-x-2">
                    <MapPin className="h-4 w-4" />
                    <span>{profile.location || 'Belum diisi'}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">
                  Pekerjaan
                </label>
                {isEditing ? (
                  <input
                    type="text"
                    value={profile.occupation || ''}
                    onChange={(e) => setProfile({ ...profile, occupation: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                    placeholder="Software Engineer"
                  />
                ) : (
                  <p className="text-foreground flex items-center space-x-2">
                    <Briefcase className="h-4 w-4" />
                    <span>{profile.occupation || 'Belum diisi'}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">
                  Bio
                </label>
                {isEditing ? (
                  <textarea
                    value={profile.bio || ''}
                    onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                    placeholder="Ceritakan tentang diri Anda..."
                  />
                ) : (
                  <p className="text-foreground">{profile.bio || 'Belum diisi'}</p>
                )}
              </div>
            </div>
          </div>

          {/* Investment Profile */}
          <div className="bg-card rounded-lg border p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">Profil Investasi</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">
                  Pengalaman Investasi
                </label>
                {isEditing ? (
                  <select
                    value={profile.investment_experience || ''}
                    onChange={(e) => setProfile({ ...profile, investment_experience: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                  >
                    <option value="">Pilih pengalaman</option>
                    {investmentExperienceOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <p className="text-foreground">
                    {investmentExperienceOptions.find(opt => opt.value === profile.investment_experience)?.label || 'Belum diisi'}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">
                  Toleransi Risiko
                </label>
                {isEditing ? (
                  <select
                    value={profile.risk_tolerance || ''}
                    onChange={(e) => setProfile({ ...profile, risk_tolerance: e.target.value })}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                  >
                    <option value="">Pilih toleransi risiko</option>
                    {riskToleranceOptions.map(option => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <p className="text-foreground">
                    {riskToleranceOptions.find(opt => opt.value === profile.risk_tolerance)?.label || 'Belum diisi'}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1">
                  Tujuan Investasi
                </label>
                {isEditing ? (
                  <textarea
                    value={profile.investment_goals || ''}
                    onChange={(e) => setProfile({ ...profile, investment_goals: e.target.value })}
                    rows={2}
                    className="w-full px-3 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary bg-background"
                    placeholder="Pensiun, pendidikan anak, dll..."
                  />
                ) : (
                  <p className="text-foreground">{profile.investment_goals || 'Belum diisi'}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">
                  Sektor Preferensi
                </label>
                {isEditing ? (
                  <div className="grid grid-cols-2 gap-2">
                    {sectorOptions.map(sector => (
                      <label key={sector} className="flex items-center space-x-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={(profile.preferred_sectors || []).includes(sector)}
                          onChange={() => handleSectorToggle(sector)}
                          className="rounded border-border text-primary focus:ring-primary"
                        />
                        <span className="text-sm text-foreground">{sector}</span>
                      </label>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {(profile.preferred_sectors || []).map(sector => (
                      <span
                        key={sector}
                        className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full"
                      >
                        {sector}
                      </span>
                    ))}
                    {(!profile.preferred_sectors || profile.preferred_sectors.length === 0) && (
                      <span className="text-muted-foreground">Belum diisi</span>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Save Button */}
        {isEditing && (
          <div className="mt-6 flex justify-end">
            <button
              onClick={handleSaveProfile}
              disabled={isSaving}
              className="flex items-center space-x-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {isSaving ? (
                <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white"></div>
              ) : (
                <Save className="h-4 w-4" />
              )}
              <span>{isSaving ? 'Menyimpan...' : 'Simpan Profil'}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
