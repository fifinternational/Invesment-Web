"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { Eye, EyeOff, ArrowRight, UserPlus } from "lucide-react"
// Logo import removed
import LoginCard3D from "@/components/auth/login-card-3d"
import BubbleBackground from "@/components/auth/bubble-background"
import BouncingBearBall from "@/components/auth/bouncing-bear-ball"
import WebsiteLogo from "@/components/ui/website-logo"
import { loginUser, loginWithGoogle } from "@/utils/supabase/index.js"

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [successMessage, setSuccessMessage] = useState("")
  // State variable for the "remember me" checkbox
  const [rememberMe, setRememberMe] = useState(false)

  // Demo credentials
  const demoCredentials = {
    email: "demo@example.com",
    password: "demo123"
  }

  // Check for registration success message
  useEffect(() => {
    const registered = searchParams.get("registered")
    const registeredEmail = sessionStorage.getItem("registeredEmail")

    if (registered === "true" && registeredEmail) {
      setSuccessMessage(`Account created successfully! You can now log in with ${registeredEmail}`)
      setUsername(registeredEmail)
      // Clear the stored email after displaying the message
      sessionStorage.removeItem("registeredEmail")
    }
  }, [searchParams])

  // Update the handleLogin function to include the remember me functionality
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)
    console.log('Attempting login with:', username)

    try {
      // Authenticate with Supabase
      const result = await loginUser(username, password)
      console.log('Login result:', result) // Debugging
      
      if (result.success) {
        // Set login state with appropriate expiration based on remember me
        const expires = new Date()
        if (rememberMe) {
          // If remember me is checked, set a cookie with a longer expiration (30 days)
          expires.setTime(expires.getTime() + (30 * 24 * 3600 * 1000))
          document.cookie = `isLoggedIn=true; path=/; expires=${expires.toUTCString()}; SameSite=Lax`
          // Also store the username in localStorage for auto-fill on next visit
          localStorage.setItem("rememberedUsername", username)
        } else {
          // Short session (1 hour)
          expires.setTime(expires.getTime() + (3600 * 1000))
          document.cookie = `isLoggedIn=true; path=/; expires=${expires.toUTCString()}; SameSite=Lax`
          // Clear any previously remembered username
          localStorage.removeItem("rememberedUsername")
        }

        // Ensure user data is available and in the correct format
        const userData = result.user || {}
        console.log('User data to store:', userData) // Debugging

        sessionStorage.setItem("isLoggedIn", "true")
        sessionStorage.setItem("userData", JSON.stringify(userData))

        // Force page reload to ensure middleware picks up the cookie
        window.location.href = "/dashboard"
      } else {
        setError(result.error || "Login failed. Please check your credentials.")
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
      console.error("Login error:", err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleGoogleLogin = async () => {
    setIsLoading(true)
    setError("")
    console.log('Attempting login with Google')
    
    try {
      console.log('Starting Google login process')
      const result = await loginWithGoogle()
      
      if (!result.success) {
        console.error('Google login failed:', result.error)
        setError(result.error || "Google login failed. Please try again.")
        setIsLoading(false)
      }
      // If successful, user will be redirected to callback page
      // No need to set isLoading to false because the page will change
    } catch (err) {
      setError("An unexpected error occurred with Google login. Please try again.")
      console.error("Google login error:", err)
      setIsLoading(false)
    }
  }

  // Handle demo login
  const handleDemoLogin = async () => {
    setIsLoading(true)
    setError("")
    
    try {
      console.log('Starting demo login...')
      
      // Call the demo API endpoint
      const response = await fetch('/api/auth/demo', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: demoCredentials.email,
          password: demoCredentials.password
        })
      })

      const result = await response.json()

      if (result.success) {
        // Store demo user data in session
        sessionStorage.setItem("isLoggedIn", "true")
        sessionStorage.setItem("userData", JSON.stringify(result.user))
        
        console.log('Demo login successful, redirecting...')
        
        // Force page reload to ensure middleware picks up the cookie
        window.location.replace("/dashboard")
      } else {
        setError(result.error || "Demo login failed")
        setIsLoading(false)
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
      console.error("Demo login error:", err)
      setIsLoading(false)
    }
  }

  // Add a useEffect to check for remembered username when the component mounts
  useEffect(() => {
    const rememberedUsername = localStorage.getItem("rememberedUsername")
    if (rememberedUsername) {
      setUsername(rememberedUsername)
      setRememberMe(true)
    }
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center relative">
      {/* Animated Background with Bubbles and Trading Icons */}
      <BubbleBackground />
      
      
      {/* 3D Login Card */}
      <div className="relative z-10 w-full max-w-md px-4">
        <LoginCard3D 
          username={username}
          setUsername={setUsername}
          password={password}
          setPassword={setPassword}
          showPassword={showPassword}
          setShowPassword={setShowPassword}
          rememberMe={rememberMe}
          setRememberMe={setRememberMe}
          isLoading={isLoading}
          handleLogin={handleLogin}
          handleGoogleLogin={handleGoogleLogin}
          handleDemoLogin={handleDemoLogin}
          error={error}
          successMessage={successMessage}
        />
      </div>
    </div>
  )
}
