"use client"

import { useState } from "react"
import { Search, Download, FileText, Clock, CheckCircle, AlertCircle } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"
import { useSubscription } from "@/contexts/subscription-context"
import Link from "next/link"

export default function ProfessionalReportPage() {
  const { t } = useLanguage()
  const { subscriptionTier } = useSubscription()
  const [selectedMarket, setSelectedMarket] = useState<"ID" | "US">("ID")
  const [searchQuery, setSearchQuery] = useState("")
  const [requestedAnalysis, setRequestedAnalysis] = useState("")

  // Existing PDF reports
  const existingReports = [
    {
      title: "Indonesia Energy Sector Report",
      file: "indonesia-energy-sector-report.pdf",
      date: "2024-01-15",
      market: "ID",
      sector: "Energy",
      status: "completed"
    },
    {
      title: "Indonesia Financial Sector Report", 
      file: "indonesia-financial-sector-report.pdf",
      date: "2024-01-10",
      market: "ID",
      sector: "Financial",
      status: "completed"
    },
    {
      title: "Indonesia Industry Sector Report",
      file: "indonesia-industry-sector-report.pdf", 
      date: "2024-01-05",
      market: "ID",
      sector: "Industry",
      status: "completed"
    }
  ]

  // Pending analysis requests
  const pendingRequests = [
    {
      title: "US Technology Sector Analysis",
      market: "US",
      sector: "Technology",
      requestDate: "2024-01-20",
      status: "pending",
      estimatedCompletion: "2-3 days"
    },
    {
      title: "Indonesia Healthcare Sector Analysis",
      market: "ID", 
      sector: "Healthcare",
      requestDate: "2024-01-18",
      status: "in_research",
      estimatedCompletion: "1-2 days"
    }
  ]

  const handleRequestAnalysis = () => {
    if (requestedAnalysis.trim()) {
      // Add to pending requests (in real app, this would make API call)
      alert(`Analysis request submitted: ${requestedAnalysis}`)
      setRequestedAnalysis("")
    }
  }

  const filteredReports = existingReports.filter(report => report.market === selectedMarket)
  const filteredPending = pendingRequests.filter(request => request.market === selectedMarket)

  if (subscriptionTier === 'trial') {
    return (
      <div className="p-6 bg-background min-h-screen">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-card rounded-lg border p-8">
            <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h1 className="text-xl font-semibold mb-4">Professional Reports</h1>
            <p className="text-muted-foreground mb-6">
              Access detailed market analysis and sector reports with Basic or Premium subscription
            </p>
            <Link 
              href="/profile/subscription"
              className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors inline-flex items-center space-x-2"
            >
              <span>Upgrade Now</span>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-4">
          <h1 className="text-xl font-semibold text-foreground mb-2">Professional Reports</h1>
          <p className="text-sm text-muted-foreground">
            Access comprehensive market analysis and sector reports
          </p>
        </div>

        {/* Market Selection */}
        <div className="mb-6">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium">Market:</span>
            <div className="flex space-x-2">
              <button
                onClick={() => setSelectedMarket("ID")}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  selectedMarket === "ID"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                Indonesia Shariah Market
              </button>
              <button
                onClick={() => setSelectedMarket("US")}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  selectedMarket === "US"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                US Shariah Market
              </button>
            </div>
          </div>
        </div>

        {/* Request Analysis Section */}
        <div className="mb-8">
          <div className="bg-card rounded-lg border p-6">
            <h2 className="text-xl font-bold mb-4">Request Custom Analysis</h2>
            <div className="flex space-x-4">
              <div className="flex-1">
                <input
                  type="text"
                  placeholder="Enter stock symbol or sector for analysis (e.g., ASII, Technology Sector)"
                  value={requestedAnalysis}
                  onChange={(e) => setRequestedAnalysis(e.target.value)}
                  className="w-full px-4 py-3 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>
              <button
                onClick={handleRequestAnalysis}
                className="bg-primary text-primary-foreground px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors flex items-center space-x-2"
              >
                <Search className="h-4 w-4" />
                <span>Request Analysis</span>
              </button>
            </div>
          </div>
        </div>

        {/* Pending Requests */}
        {filteredPending.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-4">Pending Research</h2>
            <div className="grid gap-4">
              {filteredPending.map((request, index) => (
                <div key={index} className="bg-card rounded-lg border p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-full ${
                        request.status === 'pending' ? 'bg-yellow-100 dark:bg-yellow-900/20' : 'bg-blue-100 dark:bg-blue-900/20'
                      }`}>
                        {request.status === 'pending' ? 
                          <Clock className="h-4 w-4 text-yellow-600 dark:text-yellow-400" /> :
                          <AlertCircle className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                        }
                      </div>
                      <div>
                        <h3 className="font-semibold">{request.title}</h3>
                        <p className="text-sm text-muted-foreground">
                          Requested: {request.requestDate} • Est. completion: {request.estimatedCompletion}
                        </p>
                      </div>
                    </div>
                    <span className={`text-xs px-3 py-1 rounded-full ${
                      request.status === 'pending' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/40 dark:text-yellow-200' :
                      'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-200'
                    }`}>
                      {request.status === 'pending' ? 'Pending' : 'In Research'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Available Reports */}
        <div className="mb-8">
          <h2 className="text-xl font-bold mb-4">
            Available Reports - {selectedMarket === "ID" ? "Indonesia" : "US"} Market
          </h2>
          
          {/* Sector Categories */}
          <div className="grid md:grid-cols-3 gap-6 mb-6">
            <div className="bg-card rounded-lg border p-6">
              <h3 className="font-bold text-lg mb-3">Energy Sector</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Renewable energy, oil & gas, utilities analysis
              </p>
              <div className="space-y-2">
                {selectedMarket === "ID" && (
                  <div className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">Energy Sector Report</span>
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  </div>
                )}
                <div className="text-xs text-muted-foreground">
                  {selectedMarket === "ID" ? "1 report available" : "Coming soon"}
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg border p-6">
              <h3 className="font-bold text-lg mb-3">Industry Sector</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Manufacturing, automotive, infrastructure analysis
              </p>
              <div className="space-y-2">
                {selectedMarket === "ID" && (
                  <div className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">Industry Sector Report</span>
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  </div>
                )}
                <div className="text-xs text-muted-foreground">
                  {selectedMarket === "ID" ? "1 report available" : "Coming soon"}
                </div>
              </div>
            </div>

            <div className="bg-card rounded-lg border p-6">
              <h3 className="font-bold text-lg mb-3">Technology Sector</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Fintech, e-commerce, digital services analysis
              </p>
              <div className="space-y-2">
                {selectedMarket === "US" && (
                  <div className="flex items-center justify-between p-2 bg-yellow-50 dark:bg-yellow-900/20 rounded">
                    <span className="text-sm">Tech Sector Analysis</span>
                    <Clock className="h-4 w-4 text-yellow-500" />
                  </div>
                )}
                <div className="text-xs text-muted-foreground">
                  {selectedMarket === "US" ? "In research" : "Coming soon"}
                </div>
              </div>
            </div>
          </div>

          {/* Report List */}
          <div className="space-y-4">
            {filteredReports.map((report, index) => (
              <div key={index} className="bg-card rounded-lg border p-6 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="bg-primary/10 p-3 rounded-lg">
                      <FileText className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">{report.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {report.sector} • Published: {report.date}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400 text-xs px-3 py-1 rounded-full">
                      Available
                    </span>
                    <a
                      href={`/reports/${report.file}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors flex items-center space-x-2"
                    >
                      <Download className="h-4 w-4" />
                      <span>Download</span>
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredReports.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Reports Available</h3>
              <p className="text-muted-foreground">
                Reports for {selectedMarket === "ID" ? "Indonesia" : "US"} market are coming soon.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
