"use client"

import { useState } from "react"
import { useSubscription } from "@/contexts/subscription-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { toast } from "sonner"
import PayPalButton from "@/components/payments/PayPalButton"
import MidtransButton from "@/components/payments/MidtransButton"
import { useCurrency } from "@/contexts/currency-context"
import { useLanguage } from "@/contexts/language-context"
import { Check, Star, Crown, Zap } from "lucide-react"

export default function SubscribePage() {
  const { isPro, activatePro } = useSubscription()
  const { currency, format } = useCurrency()
  const { language } = useLanguage()
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)

  const plans = [
    {
      id: "free",
      name: language === 'id-ID' ? "Gratis" : "Free",
      price: 0,
      period: language === 'id-ID' ? "/bulan" : "/month",
      description: language === 'id-ID' ? "Akses dasar ke platform investasi syariah" : "Basic access to Shariah investment platform",
      icon: Zap,
      color: "text-gray-600",
      bgColor: "bg-gray-50 dark:bg-gray-800",
      borderColor: "border-gray-200 dark:border-gray-700",
      features: [
        language === 'id-ID' ? "Akses dashboard dasar" : "Basic dashboard access",
        language === 'id-ID' ? "Data pasar terbatas" : "Limited market data",
        language === 'id-ID' ? "Laporan bulanan" : "Monthly reports",
        language === 'id-ID' ? "Dukungan komunitas" : "Community support"
      ],
      current: !isPro
    },
    {
      id: "basic",
      name: language === 'id-ID' ? "Dasar" : "Basic",
      price: 6,
      period: language === 'id-ID' ? "/bulan" : "/month",
      description: language === 'id-ID' ? "Fitur lengkap untuk investor pemula" : "Complete features for beginner investors",
      icon: Star,
      color: "text-blue-600",
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
      borderColor: "border-blue-200 dark:border-blue-700",
      features: [
        language === 'id-ID' ? "Semua fitur gratis" : "All free features",
        language === 'id-ID' ? "Data pasar real-time" : "Real-time market data",
        language === 'id-ID' ? "Analisis teknikal dasar" : "Basic technical analysis",
        language === 'id-ID' ? "Laporan mingguan" : "Weekly reports",
        language === 'id-ID' ? "Dukungan email" : "Email support"
      ],
      popular: true
    },
    {
      id: "premium",
      name: language === 'id-ID' ? "Premium" : "Premium",
      price: 12,
      period: language === 'id-ID' ? "/bulan" : "/month",
      description: language === 'id-ID' ? "Akses penuh untuk investor profesional" : "Full access for professional investors",
      icon: Crown,
      color: "text-amber-600",
      bgColor: "bg-amber-50 dark:bg-amber-900/20",
      borderColor: "border-amber-200 dark:border-amber-700",
      features: [
        language === 'id-ID' ? "Semua fitur dasar" : "All basic features",
        language === 'id-ID' ? "Laporan analisis profesional" : "Professional analyst reports",
        language === 'id-ID' ? "AI investment assistant" : "AI investment assistant",
        language === 'id-ID' ? "Notifikasi prioritas" : "Priority notifications",
        language === 'id-ID' ? "Akses API premium" : "Premium API access"
      ]
    }
  ]

  return (
    <div className="p-6 bg-background min-h-screen">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-xl font-semibold mb-2">
            {language === 'id-ID' ? 'Paket Berlangganan' : 'Subscription Plans'}
          </h1>
          <p className="text-sm text-muted-foreground">
            {language === 'id-ID' 
              ? 'Pilih paket yang sesuai dengan kebutuhan investasi Anda'
              : 'Choose the plan that fits your investment needs'
            }
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {plans.map((plan) => {
            const Icon = plan.icon
            const isSelected = selectedPlan === plan.id
            const displayPrice = language === 'en-US' ? plan.price : plan.price * 15000

            return (
              <Card 
                key={plan.id}
                className={`relative transition-all duration-300 hover:shadow-lg cursor-pointer ${
                  plan.popular ? 'ring-2 ring-blue-500 scale-105' : ''
                } ${isSelected ? 'ring-2 ring-primary' : ''} ${plan.borderColor}`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-500 text-white px-3 py-1">
                      {language === 'id-ID' ? "Paling Populer" : "Most Popular"}
                    </Badge>
                  </div>
                )}
                
                {plan.current && (
                  <div className="absolute -top-3 right-4">
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      {language === 'id-ID' ? "Saat Ini" : "Current"}
                    </Badge>
                  </div>
                )}

                <CardHeader className={`text-center ${plan.bgColor} rounded-t-lg`}>
                  <div className="flex justify-center mb-2">
                    <Icon className={`h-8 w-8 ${plan.color}`} />
                  </div>
                  <CardTitle className="text-xl">{plan.name}</CardTitle>
                  <div className="text-3xl font-bold">
                    {plan.price === 0 ? (
                      <span className={plan.color}>
                        {language === 'id-ID' ? "Gratis" : "Free"}
                      </span>
                    ) : (
                      <>
                        <span className={plan.color}>
                          {language === 'en-US' ? `$${plan.price}` : `Rp ${displayPrice.toLocaleString('id-ID')}`}
                        </span>
                        <span className="text-sm text-muted-foreground font-normal">
                          {plan.period}
                        </span>
                      </>
                    )}
                  </div>
                  <CardDescription className="text-sm">
                    {plan.description}
                  </CardDescription>
                </CardHeader>

                <CardContent className="p-6">
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {plan.id === "free" ? (
                    <Button 
                      variant="outline" 
                      className="w-full" 
                      disabled={plan.current}
                    >
                      {plan.current 
                        ? (language === 'id-ID' ? "Paket Saat Ini" : "Current Plan")
                        : (language === 'id-ID' ? "Mulai Gratis" : "Start Free")
                      }
                    </Button>
                  ) : (
                    <div className="space-y-3">
                      <Button 
                        className="w-full" 
                        variant={plan.popular ? "default" : "outline"}
                        onClick={() => setSelectedPlan(plan.id)}
                      >
                        {language === 'id-ID' ? "Pilih Paket" : "Choose Plan"}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Payment Section */}
        {selectedPlan && selectedPlan !== "free" && (
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center">
              <CardTitle>
                {language === 'id-ID' ? "Pembayaran Aman" : "Secure Payment"}
              </CardTitle>
              <CardDescription>
                {language === 'id-ID' ? "Bayar dengan PayPal" : "Pay securely with PayPal"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <div className="text-2xl font-bold">
                  {language === 'en-US' 
                    ? `$${selectedPlan === "basic" ? 6 : 12}`
                    : `Rp ${(selectedPlan === "basic" ? 6 * 15000 : 12 * 15000).toLocaleString('id-ID')}`
                  }
                  <span className="text-sm text-muted-foreground font-normal">
                    {language === 'id-ID' ? "/bulan" : "/month"}
                  </span>
                </div>
              </div>
              
              {language === 'id-ID' ? (
                <MidtransButton
                  amount={selectedPlan === "basic" ? 90000 : 180000}
                  orderId={`order-${Date.now()}-${selectedPlan}`}
                  customerDetails={{
                    first_name: "User",
                    last_name: "Name", 
                    email: "user@example.com",
                    phone: "08123456789"
                  }}
                  onSuccess={() => {
                    activatePro()
                    toast.success("Pembayaran berhasil! Paket telah diaktifkan!")
                    setSelectedPlan(null)
                  }}
                />
              ) : (
                <PayPalButton
                  amount={selectedPlan === "basic" ? "6.00" : "12.00"}
                  onApproved={() => {
                    activatePro()
                    toast.success("Payment successful! Plan activated!")
                    setSelectedPlan(null)
                  }}
                />
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}


