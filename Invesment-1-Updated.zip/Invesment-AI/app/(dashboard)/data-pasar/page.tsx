"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { YahooFinanceData } from "@/components/market/yahoo-finance-data"
import { useLanguage } from "@/contexts/language-context"

export default function DataPasarPage() {
  const [selectedRegion, setSelectedRegion] = useState<"ID" | "US">("ID")
  const { t } = useLanguage()

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Market Selection */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">{t('market_mode_title')}</h2>
            <div className="flex space-x-2">
              <button
                onClick={() => setSelectedRegion("ID")}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  selectedRegion === "ID"
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                }`}
              >
                {t('market_indonesia')}
              </button>
              <button
                onClick={() => setSelectedRegion("US")}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  selectedRegion === "US"
                    ? "bg-blue-600 text-white"
                    : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                }`}
              >
                {t('market_us')}
              </button>
            </div>
          </div>
        </div>

        {/* Real-time Market Data */}
        <YahooFinanceData selectedMarket={selectedRegion === "ID" ? "IDX" : "US"} />
      </div>
    </DashboardLayout>
  )
}
