"use client"

import { useState, useEffect, useMemo } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useLanguage } from "@/contexts/language-context"
import { useCurrency } from "@/contexts/currency-context"
import { useSubscription } from "@/contexts/subscription-context"
import TradingViewChart from "@/components/market/trading-view-widget"
import MarketTreemap from "@/components/market-treemap"
import { BlubBlubBearLoader } from "@/components/ui/blublub-bear-loader"
import { 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  PieChart, 
  Activity, 
  DollarSign,
  Globe,
  Star,
  Filter,
  RefreshCw,
  Eye,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  BookOpen,
  Shield,
  Search,
  LineChart,
  Bell
} from 'lucide-react'

interface StockData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  shariahCompliant: boolean
  sector: string
  marketCap: string
  volume?: string
}

export default function MarketAnalysisAndResearch() {
  const { language, t } = useLanguage()
  const { format } = useCurrency()
  const { subscriptionTier } = useSubscription()
  const [mounted, setMounted] = useState(false)
  const [selectedMarket, setSelectedMarket] = useState('IDX')
  const [selectedTimeframe, setSelectedTimeframe] = useState('1D')
  const [selectedIndex, setSelectedIndex] = useState('IDX:JII')
  const [selectedStock, setSelectedStock] = useState('ASII')
  const [filterShariah, setFilterShariah] = useState(true)
  const [activeTab, setActiveTab] = useState('analysis')
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const marketData = useMemo(() => ({
    IDX: {
      name: language === 'id-ID' ? "Bursa Efek Indonesia" : "Indonesia Stock Exchange",
      indices: [
        { name: "IHSG", value: "7,245.32", change: 1.24, changeValue: "+88.45", trend: "up", symbol: "IDX:COMPOSITE" },
        { name: "Jakarta Islamic Index", value: "892.45", change: 0.98, changeValue: "+8.67", trend: "up", symbol: "IDX:JII" },
        { name: "LQ45", value: "1,024.67", change: 1.15, changeValue: "+11.65", trend: "up", symbol: "IDX:LQ45" },
        { name: "IDX30", value: "567.89", change: -0.23, changeValue: "-1.31", trend: "down", symbol: "IDX:IDX30" }
      ]
    },
    US: {
      name: language === 'id-ID' ? "Pasar AS (Syariah)" : "US Markets (Shariah Compliant)",
      indices: [
        { name: "S&P 500 Shariah", value: "4,567.89", change: 0.85, changeValue: "+38.45", trend: "up", symbol: "SP:SPX" },
        { name: "Dow Jones Islamic", value: "34,567.12", change: 0.72, changeValue: "+247.89", trend: "up", symbol: "DJ:DJI" },
        { name: "NASDAQ Shariah", value: "14,234.56", change: 1.12, changeValue: "+157.89", trend: "up", symbol: "NASDAQ:IXIC" },
        { name: "FTSE Shariah Global", value: "2,345.67", change: -0.15, changeValue: "-3.52", trend: "down", symbol: "LSE:FTSE" }
      ]
    }
  }), [language])

  const shariahStocks: StockData[] = [
    {
      symbol: "ASII",
      name: "Astra International Tbk",
      price: 6250,
      change: 125,
      changePercent: 2.04,
      shariahCompliant: true,
      sector: language === 'id-ID' ? "Otomotif" : "Automotive",
      marketCap: "Rp 342.1T",
      volume: "28.7M"
    },
    {
      symbol: "TLKM",
      name: "Telkom Indonesia Tbk",
      price: 3850,
      change: 75,
      changePercent: 1.99,
      shariahCompliant: true,
      sector: language === 'id-ID' ? "Telekomunikasi" : "Telecommunications",
      marketCap: "Rp 375.8T",
      volume: "45.2M"
    },
    {
      symbol: "UNVR",
      name: "Unilever Indonesia Tbk",
      price: 4250,
      change: 100,
      changePercent: 2.41,
      shariahCompliant: true,
      sector: language === 'id-ID' ? "Barang Konsumen" : "Consumer Goods",
      marketCap: "Rp 182.4T",
      volume: "15.3M"
    },
    {
      symbol: "ICBP",
      name: "Indofood CBP Sukses Makmur Tbk",
      price: 11250,
      change: 250,
      changePercent: 2.27,
      shariahCompliant: true,
      sector: language === 'id-ID' ? "Makanan & Minuman" : "Food & Beverage",
      marketCap: "Rp 156.7T",
      volume: "12.8M"
    },
    {
      symbol: "BBCA",
      name: "Bank Central Asia Tbk",
      price: 9850,
      change: -50,
      changePercent: -0.51,
      shariahCompliant: true,
      sector: language === 'id-ID' ? "Perbankan" : "Banking",
      marketCap: "Rp 567.2T",
      volume: "32.1M"
    }
  ]

  const filteredStocks = filterShariah 
    ? shariahStocks.filter(stock => stock.shariahCompliant)
    : shariahStocks

  const sectorPerformance = [
    { name: language === 'id-ID' ? "Perbankan Syariah" : "Islamic Banking", performance: "+2.34%", trend: "up" },
    { name: language === 'id-ID' ? "Telekomunikasi" : "Telecommunications", performance: "+1.87%", trend: "up" },
    { name: language === 'id-ID' ? "Konsumer Staples" : "Consumer Staples", performance: "+1.23%", trend: "up" },
    { name: language === 'id-ID' ? "Infrastruktur" : "Infrastructure", performance: "+0.95%", trend: "up" },
    { name: language === 'id-ID' ? "Energi Terbarukan" : "Renewable Energy", performance: "+0.67%", trend: "up" },
    { name: language === 'id-ID' ? "Teknologi" : "Technology", performance: "-0.12%", trend: "down" },
    { name: language === 'id-ID' ? "Properti" : "Property", performance: "-0.45%", trend: "down" },
    { name: language === 'id-ID' ? "Retail" : "Retail", performance: "-0.78%", trend: "down" }
  ]

  const refreshData = () => {
    setIsLoading(true)
    setTimeout(() => {
      setIsLoading(false)
    }, 1500)
  }

  if (!mounted) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <BlubBlubBearLoader size="lg" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-xl font-semibold">
            {language === 'id-ID' ? 'Analisis Pasar' : 'Market Analysis'}
          </h1>
          <p className="text-sm text-muted-foreground">
            {language === 'id-ID' 
              ? 'Analisis pasar modal syariah dan riset investasi'
              : 'Shariah capital market analysis and investment research'
            }
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            {language === 'id-ID' ? 'Data Live' : 'Live Data'}
          </Badge>
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="analysis" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            {language === 'id-ID' ? 'Analisis Pasar' : 'Market Analysis'}
          </TabsTrigger>
          <TabsTrigger value="research" className="flex items-center gap-2">
            <Search className="w-4 h-4" />
            {language === 'id-ID' ? 'Riset Saham' : 'Stock Research'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-6">
          {/* Market Selection */}
          <div className="flex items-center gap-4">
            <Select value={selectedMarket} onValueChange={setSelectedMarket}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder={language === 'id-ID' ? 'Pilih Pasar' : 'Select Market'} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="IDX">🇮🇩 {language === 'id-ID' ? 'Pasar Indonesia' : 'Indonesia Market'}</SelectItem>
                <SelectItem value="US">🇺🇸 {language === 'id-ID' ? 'Pasar AS (Syariah)' : 'US Market (Shariah)'}</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1D">{language === 'id-ID' ? '1 Hari' : '1 Day'}</SelectItem>
                <SelectItem value="1W">{language === 'id-ID' ? '1 Minggu' : '1 Week'}</SelectItem>
                <SelectItem value="1M">{language === 'id-ID' ? '1 Bulan' : '1 Month'}</SelectItem>
                <SelectItem value="3M">{language === 'id-ID' ? '3 Bulan' : '3 Months'}</SelectItem>
                <SelectItem value="1Y">{language === 'id-ID' ? '1 Tahun' : '1 Year'}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Candlestick Chart & Trading Section */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Trading Panel - Left Side */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    {language === 'id-ID' ? 'Panel Trading' : 'Trading Panel'}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Stock Info */}
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold">{selectedStock}</span>
                      <Badge variant="outline" className="text-green-600">
                        <Shield className="h-3 w-3 mr-1" />
                        Syariah
                      </Badge>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{language === 'id-ID' ? 'Harga' : 'Price'}</span>
                        <span className="font-medium">{format(filteredStocks.find(s => s.symbol === selectedStock)?.price || 0)}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{language === 'id-ID' ? 'Perubahan' : 'Change'}</span>
                        <span className={`font-medium ${
                          (filteredStocks.find(s => s.symbol === selectedStock)?.changePercent || 0) >= 0 
                            ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {(filteredStocks.find(s => s.symbol === selectedStock)?.changePercent || 0) >= 0 ? '+' : ''}
                          {(filteredStocks.find(s => s.symbol === selectedStock)?.changePercent || 0).toFixed(2)}%
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">{language === 'id-ID' ? 'Volume' : 'Volume'}</span>
                        <span className="font-medium">{filteredStocks.find(s => s.symbol === selectedStock)?.volume || 'N/A'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Technical Indicators */}
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">{language === 'id-ID' ? 'Indikator Teknikal' : 'Technical Indicators'}</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center p-2 bg-muted rounded">
                        <span className="text-sm">RSI (14)</span>
                        <Badge variant="outline" className="text-yellow-600">65.4</Badge>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-muted rounded">
                        <span className="text-sm">MACD</span>
                        <Badge variant="outline" className="text-green-600">Bullish</Badge>
                      </div>
                      <div className="flex justify-between items-center p-2 bg-muted rounded">
                        <span className="text-sm">SMA (20)</span>
                        <Badge variant="outline" className="text-blue-600">{format(4250)}</Badge>
                      </div>
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">{language === 'id-ID' ? 'Aksi Cepat' : 'Quick Actions'}</h4>
                    <Button variant="outline" className="w-full justify-start text-green-600">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      {language === 'id-ID' ? 'Tambah ke Watchlist' : 'Add to Watchlist'}
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      {language === 'id-ID' ? 'Analisis Mendalam' : 'Deep Analysis'}
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Bell className="h-4 w-4 mr-2" />
                      {language === 'id-ID' ? 'Set Alert Harga' : 'Set Price Alert'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Candlestick Chart - Right Side */}
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="h-5 w-5" />
                      {language === 'id-ID' ? 'Jakarta Islamic Index' : 'Jakarta Islamic Index'}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-green-600">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-1" />
                        {language === 'id-ID' ? 'Live' : 'Live'}
                      </Badge>
                    </div>
                  </div>
                  <CardDescription>
                    {language === 'id-ID' 
                      ? 'Grafik candlestick Jakarta Islamic Index dengan analisis teknikal'
                      : 'Jakarta Islamic Index candlestick chart with technical analysis'
                    }
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[500px] bg-muted rounded-lg overflow-hidden">
                    <TradingViewChart 
                      market={selectedMarket}
                      height={500}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Market Indices */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                {marketData[selectedMarket].name}
              </CardTitle>
              <CardDescription>
                Indeks utama pasar modal syariah
                {language === 'id-ID' ? 'Indeks utama pasar modal syariah' : 'Main Shariah capital market indices'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {marketData[selectedMarket].indices.map((index, i) => (
                  <div 
                    key={i} 
                    className={`p-3 rounded-lg cursor-pointer transition-all hover:bg-muted-foreground/10 ${
                      selectedIndex === index.symbol ? 'bg-blue-50 border border-blue-200' : 'bg-muted'
                    }`}
                    onClick={() => setSelectedIndex(index.symbol)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{index.name}</span>
                      <span className={`text-sm font-semibold ${
                        index.change >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {index.change >= 0 ? '+' : ''}{typeof index.change === 'number' ? index.change.toFixed(2) : index.change}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold">{index.value}</span>
                      <span className="text-xs text-muted-foreground">
                        ({index.changeValue})
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Bottom Section - Balanced Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Sector Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  {language === 'id-ID' ? 'Performa Sektor' : 'Sector Performance'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {sectorPerformance.map((sector, index) => (
                    <div key={index} className="flex items-center justify-between p-2 hover:bg-muted rounded-lg transition-colors">
                      <span className="text-sm">{sector.name}</span>
                      <div className="flex items-center gap-1">
                        <span className={`text-sm font-medium ${
                          sector.trend === 'up' ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {sector.performance}
                        </span>
                        {sector.trend === 'up' ? (
                          <TrendingUp className="h-3 w-3 text-green-600" />
                        ) : (
                          <TrendingDown className="h-3 w-3 text-red-600" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Market Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  {language === 'id-ID' ? 'Statistik Pasar' : 'Market Statistics'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">{language === 'id-ID' ? 'Volume Trading' : 'Trading Volume'}</span>
                  <span className="text-sm font-medium">12.4B</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">{language === 'id-ID' ? 'Nilai Transaksi' : 'Transaction Value'}</span>
                  <span className="text-sm font-medium">Rp 8.7T</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">{language === 'id-ID' ? 'Saham Naik' : 'Stocks Up'}</span>
                  <span className="text-sm font-medium text-green-600">234</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">{language === 'id-ID' ? 'Saham Turun' : 'Stocks Down'}</span>
                  <span className="text-sm font-medium text-red-600">156</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">{language === 'id-ID' ? 'Tidak Berubah' : 'Unchanged'}</span>
                  <span className="text-sm font-medium">89</span>
                </div>
              </CardContent>
            </Card>
          </div>

        </TabsContent>

        <TabsContent value="research" className="space-y-6">
          {/* Market Treemap */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                {language === 'id-ID' ? 'Peta Pasar Syariah' : 'Shariah Market Map'}
              </CardTitle>
              <CardDescription>
                {language === 'id-ID' ? 'Visualisasi performa saham syariah' : 'Shariah stock performance visualization'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <MarketTreemap region={selectedMarket} />
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Stock List */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-green-600" />
                      {language === 'id-ID' ? 'Saham Syariah' : 'Shariah Stocks'}
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <Filter className="h-4 w-4 text-muted-foreground" />
                      <label className="flex items-center space-x-2 text-sm">
                        <input
                          type="checkbox"
                          checked={filterShariah}
                          onChange={(e) => setFilterShariah(e.target.checked)}
                          className="rounded"
                        />
                        <span>{language === 'id-ID' ? 'Hanya Syariah' : 'Shariah Only'}</span>
                      </label>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {filteredStocks.map((stock) => (
                      <div
                        key={stock.symbol}
                        onClick={() => setSelectedStock(stock.symbol)}
                        className={`p-3 rounded-lg border cursor-pointer transition-all ${
                          selectedStock === stock.symbol
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="font-semibold text-sm">{stock.symbol}</span>
                            {stock.shariahCompliant && (
                              <Shield className="h-3 w-3 text-green-500" />
                            )}
                          </div>
                          <span className="text-sm font-medium">{format(stock.price)}</span>
                        </div>
                        <div className="text-xs text-muted-foreground mb-1">{stock.name}</div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">{stock.sector}</span>
                          <span className={`text-xs font-medium ${
                            stock.changePercent >= 0 ? "text-green-500" : "text-red-500"
                          }`}>
                            {stock.changePercent >= 0 ? "+" : ""}{stock.changePercent.toFixed(2)}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* TradingView Chart */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <LineChart className="h-5 w-5" />
                      {language === 'id-ID' ? 'Analisis Teknikal' : 'Technical Analysis'} - {selectedStock}
                    </div>
                    <div className="flex items-center space-x-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm text-muted-foreground">
                        {language === 'id-ID' ? 'Syariah' : 'Shariah'}
                      </span>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="w-full h-96 bg-muted rounded-lg overflow-hidden">
                    <TradingViewChart 
                      market={selectedMarket}
                      height={384}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

        </TabsContent>
      </Tabs>
    </div>
  )
}
