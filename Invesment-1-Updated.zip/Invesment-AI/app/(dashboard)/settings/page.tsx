"use client"

import { useEffect, useState } from "react"
import { Settings, User, Bell, Shield, Moon, Sun, Globe, CreditCard, Save, CheckCircle, HelpCircle, Mail, Phone, Info, Activity } from "lucide-react"
import { useTheme } from "@/contexts/theme-context"
import { useLanguage } from "@/contexts/language-context"
import { useCurrency } from "@/contexts/currency-context"
import { RealTimeStatus } from "@/components/ui/real-time-status"

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("account")
  const { theme, setTheme, colorScheme, setColorScheme } = useTheme()
  const { language, setLanguage } = useLanguage()
  const { currency, setCurrency } = useCurrency()
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    browser: true,
  })
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)
  const [accountActivity, setAccountActivity] = useState(true)
  const [tradingActivity, setTradingActivity] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    const storedLang = localStorage.getItem("language")
    if (storedLang === "id-ID" || storedLang === "en-US") {
      setLanguage(storedLang)
      document.documentElement.setAttribute("lang", storedLang)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("language", language)
    document.documentElement.setAttribute("lang", language)
  }, [language])

  if (!mounted) {
    return <div className="min-h-screen bg-background" />
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="bg-primary/10 rounded-full p-2 mr-3 dark:bg-primary/20">
              <Settings className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-foreground dark:text-white">Settings</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">Manage your Islamic investment preferences</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Settings Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg border overflow-hidden dark:bg-gray-800 dark:border-gray-700">
              <div className="p-4 border-b dark:border-gray-700">
                <h2 className="font-medium text-foreground dark:text-white">Settings</h2>
              </div>
              <nav className="p-2">
                <button
                  onClick={() => setActiveTab("account")}
                  className={`flex items-center w-full px-3 py-2 rounded-md text-left ${
                    activeTab === "account" ? "bg-primary/10 text-primary" : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700"
                  }`}
                >
                  <User className="h-4 w-4 mr-3" />
                  {language === "id-ID" ? "Akun" : "Account"}
                </button>
                <button
                  onClick={() => setActiveTab("notifications")}
                  className={`flex items-center w-full px-3 py-2 rounded-md text-left ${
                    activeTab === "notifications" ? "bg-primary/10 text-primary" : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700"
                  }`}
                >
                  <Bell className="h-4 w-4 mr-3" />
                  {language === "id-ID" ? "Notifikasi" : "Notifications"}
                </button>
                <button
                  onClick={() => setActiveTab("appearance")}
                  className={`flex items-center w-full px-3 py-2 rounded-md text-left ${
                    activeTab === "appearance" ? "bg-primary/10 text-primary" : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700"
                  }`}
                >
                  <Moon className="h-4 w-4 mr-3" />
                  {language === "id-ID" ? "Tampilan" : "Appearance"}
                </button>
                <button
                  onClick={() => setActiveTab("language")}
                  className={`flex items-center w-full px-3 py-2 rounded-md text-left ${
                    activeTab === "language" ? "bg-primary/10 text-primary" : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700"
                  }`}
                >
                  <Globe className="h-4 w-4 mr-3" />
                  {language === "id-ID" ? "Bahasa" : "Language"}
                </button>
                <button
                  onClick={() => setActiveTab("payment")}
                  className={`flex items-center w-full px-3 py-2 rounded-md text-left ${
                    activeTab === "payment" ? "bg-primary/10 text-primary" : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700"
                  }`}
                >
                  <CreditCard className="h-4 w-4 mr-3" />
                  {language === "id-ID" ? "Pembayaran" : "Payment"}
                </button>
                <button
                  onClick={() => setActiveTab("security")}
                  className={`flex items-center w-full px-3 py-2 rounded-md text-left ${
                    activeTab === "security" ? "bg-primary/10 text-primary" : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700"
                  }`}
                >
                  <Shield className="h-4 w-4 mr-3" />
                  {language === "id-ID" ? "Keamanan" : "Security"}
                </button>
                <button
                  onClick={() => setActiveTab("realtime")}
                  className={`flex items-center w-full px-3 py-2 rounded-md text-left ${
                    activeTab === "realtime" ? "bg-primary/10 text-primary" : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700"
                  }`}
                >
                  <Activity className="h-4 w-4 mr-3" />
                  {language === "id-ID" ? "Real-time" : "Real-time"}
                </button>
                <button
                  onClick={() => setActiveTab("helpdesk")}
                  className={`flex items-center w-full px-3 py-2 rounded-md text-left ${
                    activeTab === "helpdesk" ? "bg-primary/10 text-primary" : "text-gray-600 hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700"
                  }`}
                >
                  <HelpCircle className="h-4 w-4 mr-3" />
                  {language === "id-ID" ? "Bantuan" : "Help"}
                </button>
              </nav>
            </div>
          </div>

          {/* Settings Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg border dark:bg-gray-800 dark:border-gray-700">
              <div className="p-6">
                {activeTab === "account" && (
                  <div>
                    <h3 className="text-lg font-medium mb-4 text-foreground dark:text-white">
                      {language === "id-ID" ? "Pengaturan Akun" : "Account Settings"}
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          {language === "id-ID" ? "Nama Lengkap" : "Full Name"}
                        </label>
                        <input
                          type="text"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          defaultValue="Demo User"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          {language === "id-ID" ? "Email" : "Email"}
                        </label>
                        <input
                          type="email"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          defaultValue="demo@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          {language === "id-ID" ? "Nomor Telepon" : "Phone Number"}
                        </label>
                        <input
                          type="tel"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                          defaultValue="+62 812 3456 7890"
                        />
                      </div>
                      <button className="bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 flex items-center">
                        <Save className="h-4 w-4 mr-2" />
                        {language === "id-ID" ? "Simpan Perubahan" : "Save Changes"}
                      </button>
                    </div>
                  </div>
                )}

                {activeTab === "notifications" && (
                  <div>
                    <h3 className="text-lg font-medium mb-4 text-foreground dark:text-white">
                      {language === "id-ID" ? "Pengaturan Notifikasi" : "Notification Settings"}
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Mail className="h-5 w-5 mr-3 text-gray-500" />
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {language === "id-ID" ? "Notifikasi Email" : "Email Notifications"}
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={notifications.email}
                          onChange={(e) => setNotifications({...notifications, email: e.target.checked})}
                          className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Bell className="h-5 w-5 mr-3 text-gray-500" />
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {language === "id-ID" ? "Notifikasi Push" : "Push Notifications"}
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={notifications.push}
                          onChange={(e) => setNotifications({...notifications, push: e.target.checked})}
                          className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Phone className="h-5 w-5 mr-3 text-gray-500" />
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {language === "id-ID" ? "Notifikasi SMS" : "SMS Notifications"}
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={notifications.sms}
                          onChange={(e) => setNotifications({...notifications, sms: e.target.checked})}
                          className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "appearance" && (
                  <div>
                    <h3 className="text-lg font-medium mb-4 text-foreground dark:text-white">
                      {language === "id-ID" ? "Pengaturan Tampilan" : "Appearance Settings"}
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          {language === "id-ID" ? "Tema" : "Theme"}
                        </label>
                        <div className="flex space-x-4">
                          <button
                            onClick={() => setTheme("light")}
                            className={`flex items-center px-4 py-2 rounded-md border ${
                              theme === "light" ? "border-primary bg-primary/10 text-primary" : "border-gray-300 text-gray-700 dark:border-gray-600 dark:text-gray-300"
                            }`}
                          >
                            <Sun className="h-4 w-4 mr-2" />
                            {language === "id-ID" ? "Terang" : "Light"}
                          </button>
                          <button
                            onClick={() => setTheme("dark")}
                            className={`flex items-center px-4 py-2 rounded-md border ${
                              theme === "dark" ? "border-primary bg-primary/10 text-primary" : "border-gray-300 text-gray-700 dark:border-gray-600 dark:text-gray-300"
                            }`}
                          >
                            <Moon className="h-4 w-4 mr-2" />
                            {language === "id-ID" ? "Gelap" : "Dark"}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "language" && (
                  <div>
                    <h3 className="text-lg font-medium mb-4 text-foreground dark:text-white">
                      {language === "id-ID" ? "Pengaturan Bahasa" : "Language Settings"}
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          {language === "id-ID" ? "Bahasa Interface" : "Interface Language"}
                        </label>
                        <select
                          value={language}
                          onChange={(e) => setLanguage(e.target.value as "id-ID" | "en-US")}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        >
                          <option value="id-ID">Bahasa Indonesia</option>
                          <option value="en-US">English (US)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          {language === "id-ID" ? "Mata Uang" : "Currency"}
                        </label>
                        <select
                          value={currency}
                          onChange={(e) => setCurrency(e.target.value as "IDR" | "USD")}
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-white"
                        >
                          <option value="IDR">Indonesian Rupiah (IDR)</option>
                          <option value="USD">US Dollar (USD)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "security" && (
                  <div>
                    <h3 className="text-lg font-medium mb-4 text-foreground dark:text-white">
                      {language === "id-ID" ? "Pengaturan Keamanan" : "Security Settings"}
                    </h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {language === "id-ID" ? "Autentikasi Dua Faktor" : "Two-Factor Authentication"}
                          </span>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {language === "id-ID" ? "Tambahkan lapisan keamanan ekstra" : "Add an extra layer of security"}
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={twoFactorEnabled}
                          onChange={(e) => setTwoFactorEnabled(e.target.checked)}
                          className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                        />
                      </div>
                      <button className="bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90">
                        {language === "id-ID" ? "Ubah Password" : "Change Password"}
                      </button>
                    </div>
                  </div>
                )}

                {activeTab === "realtime" && (
                  <div>
                    <h3 className="text-lg font-medium mb-4 text-foreground dark:text-white">
                      {language === "id-ID" ? "Pengaturan Real-time" : "Real-time Settings"}
                    </h3>
                    <div className="space-y-4">
                      <RealTimeStatus />
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {language === "id-ID" ? "Aktivitas Akun" : "Account Activity"}
                          </span>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {language === "id-ID" ? "Pantau aktivitas login dan perubahan akun" : "Monitor login activity and account changes"}
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={accountActivity}
                          onChange={(e) => setAccountActivity(e.target.checked)}
                          className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                            {language === "id-ID" ? "Aktivitas Trading" : "Trading Activity"}
                          </span>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {language === "id-ID" ? "Pantau transaksi dan pergerakan portfolio" : "Monitor transactions and portfolio movements"}
                          </p>
                        </div>
                        <input
                          type="checkbox"
                          checked={tradingActivity}
                          onChange={(e) => setTradingActivity(e.target.checked)}
                          className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === "helpdesk" && (
                  <div>
                    <h3 className="text-lg font-medium mb-4 text-foreground dark:text-white">
                      {language === "id-ID" ? "Pusat Bantuan" : "Help Center"}
                    </h3>
                    <div className="space-y-4">
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                        <div className="flex items-center mb-2">
                          <Info className="h-5 w-5 text-primary mr-2" />
                          <span className="font-medium text-foreground dark:text-white">
                            {language === "id-ID" ? "Informasi Aplikasi" : "Application Information"}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                          {language === "id-ID" ? "Platform Investasi Syariah AI" : "AI Islamic Investment Platform"}
                        </p>
                        <p className="text-xs text-gray-400 dark:text-gray-500 text-center mt-1">
                          {language === "id-ID" ? "Versi 1.0.0 | Terakhir Diperbarui: Agustus 2025" : "Version 1.0.0 | Last Updated: August 2025"}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
