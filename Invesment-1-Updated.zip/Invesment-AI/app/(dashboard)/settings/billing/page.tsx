"use client"

import { useState } from "react"
import { CreditCard, CheckCircle } from "lucide-react"

export default function BillingPage() {
  const [currentPlan, setCurrentPlan] = useState("free")

  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Billing & Subscription</h1>
        <p className="text-muted-foreground">Manage your subscription plan and payment methods</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Current Plan */}
        <div className="col-span-2">
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-md border border-white/50">
            <h2 className="text-xl font-semibold mb-4">Current Plan</h2>
            
            <div className="flex items-center mb-4">
              <div className="bg-primary/10 p-3 rounded-full mr-4">
                <CreditCard className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">{currentPlan === "free" ? "Free Plan" : "Premium Plan"}</p>
                <p className="text-sm text-muted-foreground">
                  {currentPlan === "free" ? "Basic features" : "All premium features"}
                </p>
              </div>
            </div>

            {currentPlan === "free" ? (
              <button className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors">
                Upgrade to Premium
              </button>
            ) : (
              <button className="border border-destructive text-destructive px-4 py-2 rounded-lg hover:bg-destructive/10 transition-colors">
                Cancel Subscription
              </button>
            )}
          </div>
        </div>

        {/* Payment Methods */}
        <div className="col-span-1">
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-md border border-white/50 h-full">
            <h2 className="text-xl font-semibold mb-4">Payment Methods</h2>
            <button className="w-full border border-border px-4 py-2 rounded-lg hover:bg-muted transition-colors text-center">
              Add Payment Method
            </button>
          </div>
        </div>
      </div>

      {/* Subscription Plans */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Available Plans</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Free Plan */}
          <div className={`bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-md border ${currentPlan === "free" ? "border-primary" : "border-white/50"}`}>
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-lg font-medium">Free Plan</h3>
              {currentPlan === "free" && (
                <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full flex items-center">
                  <CheckCircle className="h-3 w-3 mr-1" /> Current
                </span>
              )}
            </div>
            <p className="text-3xl font-bold mb-4">$0 <span className="text-sm font-normal text-muted-foreground">/month</span></p>
            
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-primary mr-2" />
                Basic market research
              </li>
              <li className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-primary mr-2" />
                Limited reports
              </li>
              <li className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-primary mr-2" />
                Standard support
              </li>
            </ul>

            <button 
              className={`w-full px-4 py-2 rounded-lg transition-colors ${currentPlan === "free" ? "bg-muted text-muted-foreground cursor-not-allowed" : "bg-primary text-white hover:bg-primary/90"}`}
              disabled={currentPlan === "free"}
            >
              {currentPlan === "free" ? "Current Plan" : "Select Plan"}
            </button>
          </div>

          {/* Premium Plan */}
          <div className={`bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-md border ${currentPlan === "premium" ? "border-primary" : "border-white/50"}`}>
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-lg font-medium">Premium Plan</h3>
              {currentPlan === "premium" && (
                <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full flex items-center">
                  <CheckCircle className="h-3 w-3 mr-1" /> Current
                </span>
              )}
            </div>
            <p className="text-3xl font-bold mb-4">$29 <span className="text-sm font-normal text-muted-foreground">/month</span></p>
            
            <ul className="space-y-2 mb-6">
              <li className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-primary mr-2" />
                Advanced market research
              </li>
              <li className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-primary mr-2" />
                Unlimited professional reports
              </li>
              <li className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-primary mr-2" />
                AI-powered investment recommendations
              </li>
              <li className="flex items-center text-sm">
                <CheckCircle className="h-4 w-4 text-primary mr-2" />
                Priority support
              </li>
            </ul>

            <button 
              className={`w-full px-4 py-2 rounded-lg transition-colors ${currentPlan === "premium" ? "bg-muted text-muted-foreground cursor-not-allowed" : "bg-primary text-white hover:bg-primary/90"}`}
              disabled={currentPlan === "premium"}
              onClick={() => setCurrentPlan("premium")}
            >
              {currentPlan === "premium" ? "Current Plan" : "Select Plan"}
            </button>
          </div>
        </div>
      </div>

      {/* Billing History */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Billing History</h2>
        <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-md border border-white/50">
          <p className="text-center text-muted-foreground py-8">No billing history available</p>
        </div>
      </div>
    </div>
  )
}