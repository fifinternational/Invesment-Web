"use client"

import type React from "react"

import { useEffect, useState, Suspense, useRef } from "react"
import { useRouter, usePathname } from "next/navigation"
import Link from "next/link"
import { Bell, Globe, Sun, Moon, User, Settings, CreditCard } from "lucide-react"
import { motion } from "framer-motion"
import { useLanguage } from '@/contexts/language-context'
import { HorizontalNav } from '@/components/navigation/horizontal-nav'

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const pathname = usePathname()
  const [isLoading, setIsLoading] = useState(true)
  const [notificationDropdownOpen, setNotificationDropdownOpen] = useState(false)
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const { language, setLanguage, t } = useLanguage()
  const [currentLanguage, setCurrentLanguage] = useState('Indonesian')

  const notificationDropdownRef = useRef<HTMLDivElement>(null)
  const profileDropdownRef = useRef<HTMLDivElement>(null)

  // Check if user is logged in
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const { createBrowserClient } = await import('@supabase/ssr')
        const supabase = createBrowserClient(
          process.env.NEXT_PUBLIC_SUPABASE_URL!,
          process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
        )
        
        const { data: { session } } = await supabase.auth.getSession()
        
        if (!session) {
          // Check demo login fallback
          const isLoggedIn = sessionStorage.getItem("isLoggedIn") === "true" || document.cookie.includes("isLoggedIn=true")
          if (!isLoggedIn) {
            router.push("/login")
            return
          }
        }
        
        setIsLoading(false)
      } catch (error) {
        console.error('Auth check error:', error)
        setIsLoading(false)
      }
    }
    
    checkAuth()
  }, [router])


  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notificationDropdownRef.current && !notificationDropdownRef.current.contains(event.target as Node)) {
        setNotificationDropdownOpen(false)
      }
      if (profileDropdownRef.current && !profileDropdownRef.current.contains(event.target as Node)) {
        setProfileDropdownOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode)
    document.documentElement.classList.toggle('dark')
  }

  const toggleLanguage = () => {
    const newLang = language === 'id-ID' ? 'en-US' : 'id-ID'
    setLanguage(newLang)
    setCurrentLanguage(newLang === 'id-ID' ? 'ID' : 'EN')
  }

  // Sync current language display with context
  useEffect(() => {
    setCurrentLanguage(language === 'id-ID' ? 'ID' : 'EN')
  }, [language])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <svg
            className="animate-spin h-12 w-12 text-primary mx-auto"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
          <p className="mt-4 text-lg font-medium text-foreground">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen w-full text-foreground overflow-hidden bg-background">
      <div className="h-full w-full">
        <div className="bg-transparent h-full relative">
          {/* New Header */}
          <header className="flex h-16 shrink-0 items-center justify-between border-b px-4 bg-white dark:bg-gray-900">
            {/* Left Side - Logo Only */}
            <div className="flex items-center gap-3">
              {/* Polar Bear Ball - Static (no animation) */}
              <img 
                src="/polar-bear-bubble.png?v=2"
                alt="Polar Bear Bubble"
                className="w-10 h-10 object-contain dark:brightness-150 dark:contrast-125"
              />
              
              {/* Blublub Text */}
              <div className="flex items-center">
                <span 
                  className="text-3xl font-extrabold drop-shadow-sm" 
                  style={{ color: '#2dd4bf' }}
                >
                  B
                </span>
                <span className="text-3xl font-extrabold text-gray-500 dark:text-gray-400 drop-shadow-sm">
                  lublub
                </span>
              </div>
            </div>

            {/* Right Side - Features */}
            <div className="flex items-center gap-3">
              {/* Notification Bell */}
              <div className="relative" ref={notificationDropdownRef}>
                <button 
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors relative"
                  onClick={() => setNotificationDropdownOpen(!notificationDropdownOpen)}
                >
                  <Bell className="w-5 h-5" />
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    3
                  </span>
                </button>
                
                {notificationDropdownOpen && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-lg shadow-lg border z-50"
                  >
                    <div className="p-3 border-b">
                      <h3 className="font-medium">{language === 'id-ID' ? 'Notifikasi' : 'Notifications'}</h3>
                    </div>
                    <div className="p-3">
                      <p className="text-sm text-gray-600 dark:text-gray-400">{language === 'id-ID' ? 'Tidak ada notifikasi baru' : 'No new notifications'}</p>
                    </div>
                  </motion.div>
                )}
              </div>
              
              {/* Language Selector - Simple */}
              <button 
                className="px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-all duration-200 flex items-center gap-2"
                onClick={toggleLanguage}
              >
                <Globe className="w-4 h-4" />
                <span className="text-sm font-medium min-w-[24px]">{currentLanguage}</span>
              </button>
              
              {/* Theme Toggle */}
              <button 
                className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                onClick={toggleTheme}
              >
                {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>

              <div className="h-6 w-px bg-gray-300 dark:bg-gray-600"></div>

              {/* Profile Dropdown */}
              <div className="relative" ref={profileDropdownRef}>
                <button 
                  className="w-8 h-8 bg-[#2dd4bf] rounded-full flex items-center justify-center text-white font-semibold ring-2 ring-gray-200 dark:ring-gray-700 hover:ring-[#2dd4bf] transition-all text-sm"
                  onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                >
                  U
                </button>
                
                {profileDropdownOpen && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute right-0 mt-2 w-40 bg-white dark:bg-gray-800 rounded-lg shadow-lg border z-50"
                  >
                    <div className="p-1">
                      <Link href="/profile" className="w-full flex items-center gap-2 px-2 py-1.5 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors">
                        <User className="w-3 h-3" />
                        {language === 'id-ID' ? 'Profil' : 'Profile'}
                      </Link>
                      <Link href="/billing" className="w-full flex items-center gap-2 px-2 py-1.5 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors">
                        <CreditCard className="w-3 h-3" />
                        {language === 'id-ID' ? 'Tagihan' : 'Billing'}
                      </Link>
                      <Link href="/account-settings" className="w-full flex items-center gap-2 px-2 py-1.5 text-xs hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md transition-colors">
                        <Settings className="w-3 h-3" />
                        {language === 'id-ID' ? 'Pengaturan Akun' : 'Account Settings'}
                      </Link>
                    </div>
                  </motion.div>
                )}
              </div>
            </div>
          </header>

          {/* Horizontal Navigation */}
          <HorizontalNav />

          {/* Main Content */}
          <div className="flex-1 overflow-auto w-full">
            <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>
          </div>
        </div>
      </div>
    </div>
  )
}
