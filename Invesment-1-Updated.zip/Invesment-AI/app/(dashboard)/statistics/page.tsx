"use client"

import { useState } from "react"
import { BarChart2, TrendingUp, TrendingDown, Download, RefreshCw, Calendar, Filter } from "lucide-react"

export default function StatisticsPage() {
  const [timeframe, setTimeframe] = useState("1W")
  const [chartType, setChartType] = useState("line")

  // Sample data for charts
  // Shariah products: IDX Shariah (XSSI proxy), and selected stocks (ASII, TLKM)
  const performanceData = [
    { date: "Jan", xssi: 6100, asii: 5800, tlkm: 3650 },
    { date: "Feb", xssi: 6250, asii: 5900, tlkm: 3700 },
    { date: "Mar", xssi: 6350, asii: 6000, tlkm: 3780 },
    { date: "Apr", xssi: 6420, asii: 6120, tlkm: 3850 },
    { date: "May", xssi: 6300, asii: 6020, tlkm: 3820 },
    { date: "Jun", xssi: 6480, asii: 6180, tlkm: 3920 },
    { date: "Jul", xssi: 6550, asii: 6250, tlkm: 3980 },
    { date: "Aug", xssi: 6510, asii: 6200, tlkm: 3950 },
    { date: "Sep", xssi: 6620, asii: 6320, tlkm: 4050 },
    { date: "Oct", xssi: 6700, asii: 6400, tlkm: 4120 },
    { date: "Nov", xssi: 6800, asii: 6520, tlkm: 4200 },
    { date: "Dec", xssi: 6900, asii: 6600, tlkm: 4250 },
  ]

  const marketStats = [
    {
      title: "Shariah Market Cap",
      value: "Rp 2,450T",
      change: "+2.3%",
      trend: "up",
    },
    {
      title: "24h Volume",
      value: "Rp 15.2T",
      change: "-1.2%",
      trend: "down",
    },
    {
      title: "Compliance Rate",
      value: "85%",
      change: "+0.5%",
      trend: "up",
    },
    {
      title: "Shariah Stocks",
      value: "1,234",
      change: "+12",
      trend: "up",
    },
  ]

  const topGainers = [
    { name: "Astra International", symbol: "ASII", price: "Rp 6,250", change: "+15.2%" },
    { name: "Bank Central Asia", symbol: "BBCA", price: "Rp 9,850", change: "+12.8%" },
    { name: "Telkom Indonesia", symbol: "TLKM", price: "Rp 3,850", change: "+10.5%" },
    { name: "Unilever Indonesia", symbol: "UNVR", price: "Rp 4,250", change: "+8.7%" },
    { name: "Indofood CBP", symbol: "ICBP", price: "Rp 11,250", change: "+7.3%" },
  ]

  const topLosers = [
    { name: "Bank Rakyat Indonesia", symbol: "BBRI", price: "Rp 5,450", change: "-8.4%" },
    { name: "Bank Mandiri", symbol: "BMRI", price: "Rp 6,750", change: "-6.2%" },
    { name: "Perusahaan Gas Negara", symbol: "PGAS", price: "Rp 1,650", change: "-5.8%" },
    { name: "Aneka Tambang", symbol: "ANTM", price: "Rp 1,250", change: "-4.3%" },
    { name: "Bukit Asam", symbol: "PTBA", price: "Rp 3,450", change: "-3.9%" },
  ]

  // Compute max for Trading Volume scaling (using XSSI as proxy volume)
  const maxXssi = Math.max(...performanceData.map((d) => d.xssi))

  return (
    <div className="p-4 bg-background dark:bg-gray-900 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
        <div className="flex items-center mb-4 md:mb-0">
          <div className="bg-[#2dd4bf]/20 rounded-full p-2 mr-3">
            <BarChart2 className="h-6 w-6 text-[#2dd4bf]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground dark:text-white">Market Analysis</h1>
            <p className="text-gray-500 dark:text-gray-400 text-sm">Comprehensive analysis of Shariah-compliant investment opportunities</p>
          </div>
        </div>

        <div className="flex space-x-2">
          <button className="px-4 py-2 bg-white dark:bg-gray-800 border dark:border-gray-700 rounded-md text-sm font-medium flex items-center hover:bg-gray-50 dark:hover:bg-gray-700 text-foreground dark:text-white">
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
          <button className="px-4 py-2 bg-[#2dd4bf] text-white rounded-md text-sm font-medium hover:bg-[#2dd4bf]/90">
            <RefreshCw className="h-4 w-4 inline-block mr-2" />
            Refresh
          </button>
        </div>
      </div>

      {/* Market Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {marketStats.map((stat, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700 p-4">
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-1">{stat.title}</div>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold text-foreground dark:text-white">{stat.value}</div>
              <div className={`flex items-center ${stat.trend === "up" ? "text-[#2dd4bf]" : "text-red-500"}`}>
                {stat.trend === "up" ? (
                  <TrendingUp className="h-4 w-4 mr-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 mr-1" />
                )}
                {stat.change}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Portfolio Performance Chart */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700 p-4 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold text-foreground dark:text-white">Portfolio Performance</h2>
          <div className="flex items-center space-x-2">
            <div className="flex space-x-1">
              <button
                className={`px-2 py-1 text-xs rounded text-foreground dark:text-white ${chartType === "line" ? "bg-gray-200 dark:bg-gray-600" : ""}`}
                onClick={() => setChartType("line")}
              >
                Line
              </button>
              <button
                className={`px-2 py-1 text-xs rounded text-foreground dark:text-white ${chartType === "bar" ? "bg-gray-200 dark:bg-gray-600" : ""}`}
                onClick={() => setChartType("bar")}
              >
                Bar
              </button>
              <button
                className={`px-2 py-1 text-xs rounded text-foreground dark:text-white ${chartType === "candle" ? "bg-gray-200 dark:bg-gray-600" : ""}`}
                onClick={() => setChartType("candle")}
              >
                Candle
              </button>
            </div>
            <div className="flex space-x-1">
              {["24H", "1W", "1M", "3M", "1Y", "ALL"].map((period) => (
                <button
                  key={period}
                  className={`px-2 py-1 text-xs rounded text-foreground dark:text-white ${timeframe === period ? "bg-gray-200 dark:bg-gray-600" : ""}`}
                  onClick={() => setTimeframe(period)}
                >
                  {period}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="h-80 w-full">
          {/* Chart visualization - using a placeholder SVG for now */}
          <svg className="w-full h-full" viewBox="0 0 800 300">
            {/* X and Y axes */}
            <line x1="50" y1="250" x2="750" y2="250" stroke="#e5e7eb" strokeWidth="1" />
            <line x1="50" y1="50" x2="50" y2="250" stroke="#e5e7eb" strokeWidth="1" />

            {/* X-axis labels */}
            {performanceData.map((data, i) => (
              <text
                key={i}
                x={50 + i * (700 / (performanceData.length - 1))}
                y="270"
                textAnchor="middle"
                fontSize="10"
                fill="#6b7280"
                className="dark:fill-gray-400"
              >
                {data.date}
              </text>
            ))}

            {/* Y-axis labels (IDR scale) */}
            {[0, 2000, 4000, 6000, 8000].map((value, i) => (
              <text key={i} x="40" y={250 - i * 50} textAnchor="end" fontSize="10" fill="#6b7280" className="dark:fill-gray-400">
                Rp {value.toLocaleString()}
              </text>
            ))}

            {/* XSSI (IDX Shariah) line - bright light teal */}
            <path
              d={performanceData
                .map((data, i) => {
                  const x = 50 + i * (700 / (performanceData.length - 1))
                  const y = 250 - (data.xssi / 9000) * 200
                  return `${i === 0 ? "M" : "L"}${x},${y}`
                })
                .join(" ")}
              fill="none"
              stroke="#2dd4bf"
              strokeWidth="2"
            />

            {/* ASII line - slightly darker teal */}
            <path
              d={performanceData
                .map((data, i) => {
                  const x = 50 + i * (700 / (performanceData.length - 1))
                  const y = 250 - (data.asii / 9000) * 200
                  return `${i === 0 ? "M" : "L"}${x},${y}`
                })
                .join(" ")}
              fill="none"
              stroke="#14b8a6"
              strokeWidth="2"
            />

            {/* TLKM line - muted teal */}
            <path
              d={performanceData
                .map((data, i) => {
                  const x = 50 + i * (700 / (performanceData.length - 1))
                  const y = 250 - (data.tlkm / 9000) * 200
                  return `${i === 0 ? "M" : "L"}${x},${y}`
                })
                .join(" ")}
              fill="none"
              stroke="#99f6e4"
              strokeWidth="2"
            />

            {/* Legend */}
            <circle cx="640" cy="30" r="5" fill="#2dd4bf" />
            <text x="650" y="35" fontSize="12" fill="#6b7280" className="dark:fill-gray-400">IDX Shariah (XSSI)</text>
            <circle cx="640" cy="50" r="5" fill="#14b8a6" />
            <text x="650" y="55" fontSize="12" fill="#6b7280" className="dark:fill-gray-400">ASII</text>
            <circle cx="640" cy="70" r="5" fill="#99f6e4" />
            <text x="650" y="75" fontSize="12" fill="#6b7280" className="dark:fill-gray-400">TLKM</text>
          </svg>
        </div>
      </div>

      {/* Top Gainers & Losers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Top Gainers */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700 p-4">
          <h2 className="text-lg font-bold mb-4 text-foreground dark:text-white">Top Gainers (24h)</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="text-xs text-gray-500 border-b">
                  <th className="pb-2 text-left">NAME</th>
                  <th className="pb-2 text-right">PRICE</th>
                  <th className="pb-2 text-right">CHANGE</th>
                </tr>
              </thead>
              <tbody>
                {topGainers.map((coin, index) => (
                  <tr key={index} className="border-b last:border-0">
                    <td className="py-3">
                      <div className="flex items-center">
                        <div className="font-medium">{coin.name}</div>
                        <div className="text-xs text-gray-500 ml-2">{coin.symbol}</div>
                      </div>
                    </td>
                    <td className="py-3 text-right">{coin.price}</td>
                    <td className="py-3 text-right text-[#2dd4bf]">{coin.change}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Losers */}
        <div className="bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700 p-4">
          <h2 className="text-lg font-bold mb-4 text-foreground dark:text-white">Top Losers (24h)</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="text-xs text-gray-500 border-b">
                  <th className="pb-2 text-left">NAME</th>
                  <th className="pb-2 text-right">PRICE</th>
                  <th className="pb-2 text-right">CHANGE</th>
                </tr>
              </thead>
              <tbody>
                {topLosers.map((coin, index) => (
                  <tr key={index} className="border-b last:border-0">
                    <td className="py-3">
                      <div className="flex items-center">
                        <div className="font-medium">{coin.name}</div>
                        <div className="text-xs text-gray-500 ml-2">{coin.symbol}</div>
                      </div>
                    </td>
                    <td className="py-3 text-right">{coin.price}</td>
                    <td className="py-3 text-right text-red-500">{coin.change}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Trading Volume */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border dark:border-gray-700 p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold text-foreground dark:text-white">Trading Volume</h2>
          <div className="flex items-center space-x-2">
            <button className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 border dark:border-gray-600">
              <Calendar className="h-5 w-5 text-gray-500 dark:text-gray-400" />
            </button>
            <button className="p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 border dark:border-gray-600">
              <Filter className="h-5 w-5 text-gray-500 dark:text-gray-400" />
            </button>
          </div>
        </div>

        <div className="h-60 w-full">
          {/* Bar chart visualization */}
          <svg className="w-full h-full" viewBox="0 0 800 200">
            {/* X and Y axes */}
            <line x1="50" y1="150" x2="750" y2="150" stroke="#e5e7eb" strokeWidth="1" />
            <line x1="50" y1="20" x2="50" y2="150" stroke="#e5e7eb" strokeWidth="1" />

            {/* X-axis labels */}
            {performanceData.map((data, i) => (
              <text
                key={i}
                x={50 + i * (700 / (performanceData.length - 1))}
                y="170"
                textAnchor="middle"
                fontSize="10"
                fill="#6b7280"
                className="dark:fill-gray-400"
              >
                {data.date}
              </text>
            ))}

            {/* Y-axis labels (relative scale) */}
            {[0, 25, 50, 75, 100].map((value, i) => (
              <text key={i} x="40" y={150 - i * 30} textAnchor="end" fontSize="10" fill="#6b7280" className="dark:fill-gray-400">
                ${value}B
              </text>
            ))}

            {/* Volume bars */}
            {performanceData.map((data, i) => {
              const step = 700 / (performanceData.length - 1)
              const barWidth = Math.min(20, step * 0.6)
              const xCenter = 50 + i * step
              const height = Math.max(2, (data.xssi / maxXssi) * 120) // min height 2px for visibility
              const x = xCenter - barWidth / 2
              const y = 150 - height
              return (
                <rect
                  key={i}
                  x={x}
                  y={y}
                  width={barWidth}
                  height={height}
                  rx={4}
                  fill="#2dd4bf"
                  fillOpacity="0.85"
                />
              )
            })}
          </svg>
        </div>
      </div>
    </div>
  )
}
