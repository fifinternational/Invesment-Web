"use client"

import { useState, useEffect } from "react"
import { Search, MessageCircle, TrendingUp, Star, Sparkles } from "lucide-react"
import { YahooFinanceData } from "@/components/market/yahoo-finance-data"
import { DashboardProvider } from "@/components/dashboard/dashboard-provider"
import ExploreMarket from "@/components/explore-market"
import MarketTrades from "@/components/market-trades"
import Watchlist from "@/components/watchlist"
import MarketNews from "@/components/market-news"
import AIChatbot from "@/components/ai-chatbot"
import BouncingBearBall from "@/components/auth/bouncing-bear-ball"

export default function Dashboard() {
  const [mounted, setMounted] = useState(false)
  const [selectedRegion, setSelectedRegion] = useState<"ID" | "US">("ID")
  const [searchQuery, setSearchQuery] = useState("")
  const [chatOpen, setChatOpen] = useState(false)
  const [selectedTimeframe, setSelectedTimeframe] = useState<"daily" | "weekly" | "monthly">("daily")

  useEffect(() => {
    setMounted(true)
  }, [])

  // AI Recommendations Data
  const aiRecommendationsID = {
    daily: [
      { symbol: "ASII", name: "Astra International", recommendation: "BUY", confidence: 85, reason: "Strong intraday momentum", targetPrice: "Rp 6,800" },
      { symbol: "TLKM", name: "Telkom Indonesia", recommendation: "HOLD", confidence: 72, reason: "Consolidating near resistance", targetPrice: "Rp 4,100" },
      { symbol: "ICBP", name: "Indofood CBP", recommendation: "BUY", confidence: 78, reason: "Breaking above moving average", targetPrice: "Rp 12,000" }
    ],
    weekly: [
      { symbol: "ASII", name: "Astra International", recommendation: "BUY", confidence: 88, reason: "Strong weekly trend", targetPrice: "Rp 7,200" },
      { symbol: "UNVR", name: "Unilever Indonesia", recommendation: "BUY", confidence: 82, reason: "Consumer goods strength", targetPrice: "Rp 2,800" },
      { symbol: "BBRI", name: "Bank Rakyat Indonesia", recommendation: "HOLD", confidence: 75, reason: "Banking consolidation", targetPrice: "Rp 4,500" }
    ],
    monthly: [
      { symbol: "ASII", name: "Astra International", recommendation: "BUY", confidence: 90, reason: "Long-term fundamentals", targetPrice: "Rp 8,000" },
      { symbol: "TLKM", name: "Telkom Indonesia", recommendation: "BUY", confidence: 85, reason: "Digital transformation", targetPrice: "Rp 4,800" },
      { symbol: "ICBP", name: "Indofood CBP", recommendation: "HOLD", confidence: 80, reason: "Stable performance", targetPrice: "Rp 13,500" }
    ]
  }

  const aiRecommendationsUS = {
    daily: [
      { symbol: "AAPL", name: "Apple Inc", recommendation: "BUY", confidence: 82, reason: "Strong momentum after earnings", targetPrice: "$230.00" },
      { symbol: "MSFT", name: "Microsoft Corp", recommendation: "HOLD", confidence: 75, reason: "Consolidating after gains", targetPrice: "$420.00" },
      { symbol: "NVDA", name: "NVIDIA Corp", recommendation: "BUY", confidence: 85, reason: "AI sector strength", targetPrice: "$580.00" }
    ],
    weekly: [
      { symbol: "MSFT", name: "Microsoft Corp", recommendation: "BUY", confidence: 88, reason: "Cloud growth driving performance", targetPrice: "$450.00" },
      { symbol: "AAPL", name: "Apple Inc", recommendation: "HOLD", confidence: 78, reason: "Weekly consolidation", targetPrice: "$225.00" },
      { symbol: "HLAL", name: "Wahed FTSE USA Shariah ETF", recommendation: "BUY", confidence: 80, reason: "Shariah ETF strength", targetPrice: "$54.00" }
    ],
    monthly: [
      { symbol: "AAPL", name: "Apple Inc", recommendation: "BUY", confidence: 90, reason: "Long-term ecosystem growth", targetPrice: "$280.00" },
      { symbol: "MSFT", name: "Microsoft Corp", recommendation: "BUY", confidence: 92, reason: "Cloud dominance", targetPrice: "$500.00" },
      { symbol: "HLAL", name: "Wahed FTSE USA Shariah ETF", recommendation: "BUY", confidence: 85, reason: "Diversified growth", targetPrice: "$58.00" }
    ]
  }

  const currentRecommendations = selectedRegion === "ID" ? aiRecommendationsID[selectedTimeframe] : aiRecommendationsUS[selectedTimeframe]

  if (!mounted) {
    return <div className="min-h-screen bg-background" />
  }

  return (
    <DashboardProvider selectedMarket={selectedRegion === "ID" ? "IDX" : "US"} selectedTimeframe={selectedTimeframe}>
      <div className="p-6 space-y-6 max-w-7xl mx-auto relative">

        {/* AI Assistant Card */}
        <div className="bg-gradient-to-r from-primary/10 to-blue-500/10 rounded-lg border border-primary/20 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-primary/20 p-2 rounded-full">
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold">AI Assistant</h3>
                <p className="text-sm text-gray-600">Dapatkan insight investasi syariah dengan AI</p>
              </div>
            </div>
            <button 
              onClick={() => setChatOpen(true)}
              className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors"
            >
              <MessageCircle className="h-4 w-4 mr-2 inline" />
              Chat
            </button>
          </div>
        </div>


        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-xl font-semibold mb-1">Dashboard</h1>
            <p className="text-sm text-muted-foreground">Platform investasi syariah</p>
          </div>
        </div>

        {/* Market Selection */}
        <div className="bg-card rounded-lg border p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold mb-1">Market Mode</h3>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => setSelectedRegion("ID")}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  selectedRegion === "ID"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                🇮🇩 Pasar Indonesia
              </button>
              <button
                onClick={() => setSelectedRegion("US")}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  selectedRegion === "US"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                🇺🇸 Pasar AS
              </button>
            </div>
          </div>
          
          {/* Search */}
          <div className="mt-4 pt-4 border-t border-border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Cari saham, sektor, atau analisis pasar (cth: 'ASII', 'saham teknologi halal')"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && searchQuery.trim()) {
                    const stockSymbols = ['ASII', 'TLKM', 'UNVR', 'ICBP', 'AAPL', 'MSFT', 'GOOGL']
                    const foundSymbol = stockSymbols.find(symbol => 
                      searchQuery.toUpperCase().includes(symbol)
                    )
                    if (foundSymbol) {
                      window.location.href = `/research?symbol=${foundSymbol}&region=${selectedRegion}`
                    } else {
                      setChatOpen(true)
                    }
                  }
                }}
                className="w-full pl-10 pr-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="bg-card rounded-lg border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <h2 className="text-lg font-bold">Rekomendasi AI</h2>
              <span className="bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">Bertenaga AI</span>
            </div>
            <div className="flex space-x-2">
              <button 
                onClick={() => setSelectedTimeframe("daily")}
                className={`px-3 py-1 text-xs rounded-full transition-colors ${
                  selectedTimeframe === "daily"
                    ? "bg-green-500 text-white"
                    : "bg-green-100 text-green-800 hover:bg-green-200"
                }`}
              >
                Harian
              </button>
              <button 
                onClick={() => setSelectedTimeframe("weekly")}
                className={`px-3 py-1 text-xs rounded-full transition-colors ${
                  selectedTimeframe === "weekly"
                    ? "bg-blue-500 text-white"
                    : "bg-blue-100 text-blue-800 hover:bg-blue-200"
                }`}
              >
                Mingguan
              </button>
              <button 
                onClick={() => setSelectedTimeframe("monthly")}
                className={`px-3 py-1 text-xs rounded-full transition-colors ${
                  selectedTimeframe === "monthly"
                    ? "bg-purple-500 text-white"
                    : "bg-purple-100 text-purple-800 hover:bg-purple-200"
                }`}
              >
                Bulanan
              </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {currentRecommendations.map((rec, index) => (
              <div key={index} className="border border-border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold">{rec.symbol}</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    rec.recommendation === 'BUY' ? 'bg-green-100 text-green-800' :
                    rec.recommendation === 'SELL' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }`}>
                    {rec.recommendation}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{rec.name}</p>
                <div className="flex items-center space-x-2 mb-2">
                  <Star className="h-3 w-3 text-yellow-500" />
                  <span className="text-xs">{rec.confidence}% confidence</span>
                </div>
                <p className="text-xs text-muted-foreground mb-2">{rec.reason}</p>
                <p className="text-sm font-medium">Target: {rec.targetPrice}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Left Column - Market Data */}
          <div className="xl:col-span-2 space-y-6">
            <ExploreMarket region={selectedRegion} />
            <MarketTrades />
          </div>

          {/* Right Column - Watchlist and News */}
          <div className="space-y-6">
            <Watchlist region={selectedRegion} />
            <MarketNews region={selectedRegion} />
          </div>
        </div>

        {/* AI Chatbot Modal */}
        <AIChatbot isOpen={chatOpen} onClose={() => setChatOpen(false)} />
      </div>
    </DashboardProvider>
  )
}
