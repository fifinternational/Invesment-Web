"use client"

import { useState, useMemo } from "react"
import { useSearchParams } from "next/navigation"
import { TrendingUp, BookOpen, Shield, Star, Filter } from "lucide-react"
import TradingViewChart from "@/components/tradingview-chart"
import MarketTreemap from "@/components/market-treemap"
import { useLanguage } from "@/contexts/language-context"
import { useCurrency } from "@/contexts/currency-context"
import { useSubscription } from "@/contexts/subscription-context"

interface StockData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  shariahCompliant: boolean
  sector: string
  marketCap: string
}

const sampleStocks: StockData[] = [
  {
    symbol: "ASII",
    name: "Astra International Tbk",
    price: 6250,
    change: 125,
    changePercent: 2.04,
    shariahCompliant: true,
    sector: "Automotive",
    marketCap: "Rp 125.5 T"
  },
  {
    symbol: "BBCA",
    name: "Bank Central Asia Tbk",
    price: 9850,
    change: -50,
    changePercent: -0.51,
    shariahCompliant: true,
    sector: "Banking",
    marketCap: "Rp 245.2 T"
  },
  {
    symbol: "TLKM",
    name: "Telkom Indonesia Tbk",
    price: 3850,
    change: 75,
    changePercent: 1.99,
    shariahCompliant: true,
    sector: "Telecommunications",
    marketCap: "Rp 365.8 T"
  },
  {
    symbol: "UNVR",
    name: "Unilever Indonesia Tbk",
    price: 4250,
    change: 100,
    changePercent: 2.41,
    shariahCompliant: true,
    sector: "Consumer Goods",
    marketCap: "Rp 89.3 T"
  },
  {
    symbol: "ICBP",
    name: "Indofood CBP Sukses Makmur Tbk",
    price: 11250,
    change: 250,
    changePercent: 2.27,
    shariahCompliant: true,
    sector: "Food & Beverage",
    marketCap: "Rp 134.7 T"
  }
]

export default function ResearchPage() {
  const { t } = useLanguage()
  const { format } = useCurrency()
  const { subscriptionTier } = useSubscription()
  const searchParams = useSearchParams()
  const urlSymbol = searchParams.get("symbol") || undefined
  const urlRegion = (searchParams.get("region") as "ID" | "US" | null) || null

  const defaultSymbol = useMemo(() => urlSymbol ?? "ASII", [urlSymbol])
  const [selectedStock, setSelectedStock] = useState<string>(defaultSymbol)
  const [selectedRegion, setSelectedRegion] = useState<"ID" | "US">(urlRegion || "ID")
  const [filterShariah, setFilterShariah] = useState<boolean>(true)

  const filteredStocks = filterShariah 
    ? sampleStocks.filter(stock => stock.shariahCompliant)
    : sampleStocks

  return (
    <div className="p-4 bg-background">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground mb-2">Market Research</h1>
        <p className="text-muted-foreground">Deep analysis for Shariah-compliant investment products</p>
      </div>

      {/* Market Selection */}
      <div className="mb-6">
        <div className="bg-card rounded-lg border p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold mb-1">Research Market</h3>
              <p className="text-sm text-muted-foreground">Select market for detailed analysis</p>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => setSelectedRegion("ID")}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  selectedRegion === "ID"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                🇮🇩 Indonesia Shariah
              </button>
              <button
                onClick={() => setSelectedRegion("US")}
                className={`px-4 py-2 text-sm rounded-lg transition-colors ${
                  selectedRegion === "US"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                🇺🇸 US Shariah
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Market Treemap */}
      <div className="mb-6">
        <MarketTreemap region={selectedRegion} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Stock List */}
        <div className="lg:col-span-1">
          <div className="bg-card rounded-lg border border-border p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Shariah-Compliant Stocks</h2>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <label className="flex items-center space-x-2 text-sm">
                  <input
                    type="checkbox"
                    checked={filterShariah}
                    onChange={(e) => setFilterShariah(e.target.checked)}
                    className="rounded"
                  />
                  <span>Shariah Only</span>
                </label>
              </div>
            </div>
            
            <div className="space-y-2">
              {filteredStocks.map((stock) => (
                <div
                  key={stock.symbol}
                  onClick={() => setSelectedStock(stock.symbol)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    selectedStock === stock.symbol
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold text-sm">{stock.symbol}</span>
                      {stock.shariahCompliant && (
                        <Shield className="h-3 w-3 text-green-500" />
                      )}
                    </div>
                    <span className="text-sm font-medium">{format(stock.price)}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mb-1">{stock.name}</div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{stock.sector}</span>
                    <span className={`text-xs font-medium ${
                      stock.change >= 0 ? "text-green-500" : "text-red-500"
                    }`}>
                      {stock.change >= 0 ? "+" : ""}{stock.changePercent.toFixed(2)}%
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* TradingView Chart */}
        <div className="lg:col-span-2">
          <div className="bg-card rounded-lg border border-border p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">{t("nav_analysis")} - {selectedStock}</h2>
              <div className="flex items-center space-x-2">
                <Star className="h-4 w-4 text-yellow-500" />
                <span className="text-sm text-muted-foreground">{t("label_shariah")}</span>
              </div>
            </div>
            
            {/* TradingView Widget */}
            <div className="w-full h-96 bg-muted rounded-lg overflow-hidden">
              <TradingViewChart 
                symbol={`${urlRegion === "US" ? "NASDAQ" : "IDX"}:${selectedStock}`} 
                width={800} 
                height={384} 
              />
            </div>
          </div>
        </div>
      </div>

      {/* Research Insights */}
      <div className="mt-6">
        <div className="bg-card rounded-lg border border-border p-4">
          <h2 className="text-lg font-semibold mb-4">Research Insights</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 bg-muted rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Shield className="h-4 w-4 text-green-500" />
                <span className="font-medium text-sm">Shariah Compliance</span>
              </div>
              <p className="text-xs text-muted-foreground">
                All listed stocks have been verified for Shariah compliance by our expert panel.
              </p>
            </div>
            
            <div className="p-4 bg-muted rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <BookOpen className="h-4 w-4 text-blue-500" />
                <span className="font-medium text-sm">Research Reports</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Access detailed research reports and fundamental analysis for each stock.
              </p>
            </div>
            
            <div className="p-4 bg-muted rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <TrendingUp className="h-4 w-4 text-purple-500" />
                <span className="font-medium text-sm">Market Trends</span>
              </div>
              <p className="text-xs text-muted-foreground">
                Stay updated with the latest market trends and investment opportunities.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
