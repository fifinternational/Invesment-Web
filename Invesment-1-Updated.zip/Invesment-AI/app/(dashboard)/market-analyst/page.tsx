"use client"

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  TrendingUp, 
  TrendingDown, 
  BarChart3, 
  PieChart, 
  Activity, 
  DollarSign,
  Search,
  Bot,
  FileText,
  Calendar,
  Star,
  AlertTriangle
} from 'lucide-react'

export default function MarketAnalystPage() {
  const [query, setQuery] = useState('')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<any>(null)

  const handleAnalysis = async () => {
    if (!query.trim()) return
    
    setIsAnalyzing(true)
    // Simulate AI analysis
    setTimeout(() => {
      setAnalysisResult({
        summary: "Berdasarkan analisis mendalam terhadap kondisi pasar saat ini, terdapat beberapa tren positif yang dapat dimanfaatkan untuk investasi syariah.",
        sentiment: "positive",
        confidence: 85,
        recommendations: [
          {
            type: "BUY",
            asset: "TLKM.JK",
            reason: "Fundamental kuat dengan pertumbuhan konsisten",
            shariahCompliant: true
          },
          {
            type: "HOLD", 
            asset: "BBRI.JK",
            reason: "Valuasi fair dengan prospek jangka panjang baik",
            shariahCompliant: true
          }
        ],
        risks: [
          "Volatilitas pasar global",
          "Perubahan suku bunga",
          "Kondisi geopolitik"
        ]
      })
      setIsAnalyzing(false)
    }, 2000)
  }

  const marketMetrics = [
    {
      title: "IHSG",
      value: "7,245.32",
      change: "+1.24%",
      trend: "up",
      icon: TrendingUp
    },
    {
      title: "Jakarta Islamic Index",
      value: "892.45", 
      change: "+0.98%",
      trend: "up",
      icon: Activity
    },
    {
      title: "Kapitalisasi Pasar Syariah",
      value: "Rp 4,521T",
      change: "+2.1%",
      trend: "up",
      icon: DollarSign
    },
    {
      title: "Volume Trading",
      value: "12.4B",
      change: "-0.45%",
      trend: "down",
      icon: BarChart3
    }
  ]

  const topShariahStocks = [
    { symbol: "TLKM.JK", name: "Telkom Indonesia", price: "3,850", change: "+2.1%" },
    { symbol: "BBRI.JK", name: "Bank BRI", price: "4,720", change: "+1.8%" },
    { symbol: "ASII.JK", name: "Astra International", price: "5,125", change: "+0.9%" },
    { symbol: "UNVR.JK", name: "Unilever Indonesia", price: "2,480", change: "-0.3%" },
    { symbol: "ICBP.JK", name: "Indofood CBP", price: "8,950", change: "+1.2%" }
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Market Analyst AI</h1>
          <p className="text-muted-foreground">
            Analisis pasar syariah dengan kecerdasan buatan
          </p>
        </div>
        <Badge variant="outline" className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-500 rounded-full" />
          Real-time Data
        </Badge>
      </div>

      {/* Market Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {marketMetrics.map((metric, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {metric.title}
                  </p>
                  <p className="text-2xl font-bold">{metric.value}</p>
                  <p className={`text-sm ${
                    metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {metric.change}
                  </p>
                </div>
                <metric.icon className={`h-8 w-8 ${
                  metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* AI Analysis Panel */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="h-5 w-5" />
                AI Market Analysis
              </CardTitle>
              <CardDescription>
                Masukkan pertanyaan atau permintaan analisis pasar
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Textarea
                  placeholder="Contoh: Analisis prospek saham perbankan syariah untuk 6 bulan ke depan..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
              <Button 
                onClick={handleAnalysis}
                disabled={isAnalyzing || !query.trim()}
                className="w-full"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Menganalisis...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Analisis Pasar
                  </>
                )}
              </Button>

              {/* Analysis Results */}
              {analysisResult && (
                <div className="space-y-4 mt-6">
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="h-4 w-4" />
                      <span className="font-medium">Ringkasan Analisis</span>
                      <Badge variant="secondary">
                        Confidence: {analysisResult.confidence}%
                      </Badge>
                    </div>
                    <p className="text-sm">{analysisResult.summary}</p>
                  </div>

                  <Tabs defaultValue="recommendations" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="recommendations">Rekomendasi</TabsTrigger>
                      <TabsTrigger value="risks">Analisis Risiko</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="recommendations" className="space-y-3">
                      {analysisResult.recommendations.map((rec: any, index: number) => (
                        <div key={index} className="p-3 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <Badge variant={rec.type === 'BUY' ? 'default' : 'secondary'}>
                                {rec.type}
                              </Badge>
                              <span className="font-medium">{rec.asset}</span>
                              {rec.shariahCompliant && (
                                <Badge variant="outline" className="text-green-600">
                                  <Star className="h-3 w-3 mr-1" />
                                  Syariah
                                </Badge>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{rec.reason}</p>
                        </div>
                      ))}
                    </TabsContent>
                    
                    <TabsContent value="risks" className="space-y-3">
                      {analysisResult.risks.map((risk: string, index: number) => (
                        <div key={index} className="flex items-center gap-2 p-3 border rounded-lg">
                          <AlertTriangle className="h-4 w-4 text-yellow-600" />
                          <span className="text-sm">{risk}</span>
                        </div>
                      ))}
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Top Shariah Stocks */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PieChart className="h-5 w-5" />
                Top Saham Syariah
              </CardTitle>
              <CardDescription>
                Performa saham syariah terbaik hari ini
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {topShariahStocks.map((stock, index) => (
                  <div key={index} className="flex items-center justify-between p-2 hover:bg-muted rounded-lg transition-colors">
                    <div>
                      <p className="font-medium text-sm">{stock.symbol}</p>
                      <p className="text-xs text-muted-foreground">{stock.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-sm">{stock.price}</p>
                      <p className={`text-xs ${
                        stock.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {stock.change}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Analysis Tools */}
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-lg">Quick Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <Calendar className="h-4 w-4 mr-2" />
                Analisis Mingguan
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <BarChart3 className="h-4 w-4 mr-2" />
                Sektor Analysis
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <TrendingUp className="h-4 w-4 mr-2" />
                Trend Forecast
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
