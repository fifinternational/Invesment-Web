"use client"

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/contexts/language-context"
import { useCurrency } from "@/contexts/currency-context"
import TradingViewChart from "@/components/market/trading-view-widget"
import MarketTreemap from "@/components/market-treemap"
import { BlubBlubBearLoader } from "@/components/ui/blublub-bear-loader"
import { 
  Search, 
  FileText, 
  TrendingUp, 
  Globe, 
  Building2, 
  Users, 
  BarChart3,
  PieChart,
  Download,
  Calendar,
  Filter,
  Star,
  Eye,
  Bell,
  Shield,
  TrendingDown,
  Activity,
  LineChart
} from 'lucide-react'
import { useLanguage } from "@/contexts/language-context"
import { useCurrency } from "@/contexts/currency-context"
import MarketTreemap from "@/components/market-treemap"
import TradingViewChart from "@/components/tradingview-chart"

export default function MarketResearchPage() {
  const { language } = useLanguage()
  const { format } = useCurrency()
  const [mounted, setMounted] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedMarket, setSelectedMarket] = useState('IDX')
  const [filterShariah, setFilterShariah] = useState(true)
  const [selectedStock, setSelectedStock] = useState('ASII')

  useEffect(() => {
    setMounted(true)
  }, [])

  // Sharia Stocks Data
  const shariahStocksData = {
    IDX: [
      {
        symbol: "ASII",
        name: "Astra International Tbk",
        price: 6250,
        change: 125,
        changePercent: 2.04,
        shariahCompliant: true,
        sector: language === 'id-ID' ? "Otomotif" : "Automotive",
        marketCap: "Rp 342.1T",
        volume: "28.7M"
      },
      {
        symbol: "TLKM",
        name: "Telkom Indonesia Tbk",
        price: 3850,
        change: 75,
        changePercent: 1.99,
        shariahCompliant: true,
        sector: language === 'id-ID' ? "Telekomunikasi" : "Telecommunications",
        marketCap: "Rp 375.8T",
        volume: "45.2M"
      },
      {
        symbol: "UNVR",
        name: "Unilever Indonesia Tbk",
        price: 4250,
        change: 100,
        changePercent: 2.41,
        shariahCompliant: true,
        sector: language === 'id-ID' ? "Barang Konsumen" : "Consumer Goods",
        marketCap: "Rp 182.4T",
        volume: "15.3M"
      },
      {
        symbol: "ICBP",
        name: "Indofood CBP Sukses Makmur Tbk",
        price: 11250,
        change: 250,
        changePercent: 2.27,
        shariahCompliant: true,
        sector: language === 'id-ID' ? "Makanan & Minuman" : "Food & Beverage",
        marketCap: "Rp 156.7T",
        volume: "12.8M"
      },
      {
        symbol: "BBCA",
        name: "Bank Central Asia Tbk",
        price: 9850,
        change: -50,
        changePercent: -0.51,
        shariahCompliant: true,
        sector: language === 'id-ID' ? "Perbankan" : "Banking",
        marketCap: "Rp 567.2T",
        volume: "32.1M"
      }
    ],
    US: [
      {
        symbol: "AAPL",
        name: "Apple Inc",
        price: 195.89,
        change: 2.45,
        changePercent: 1.27,
        shariahCompliant: true,
        sector: "Technology",
        marketCap: "$3.1T",
        volume: "45.2M"
      },
      {
        symbol: "MSFT",
        name: "Microsoft Corporation",
        price: 378.85,
        change: 4.12,
        changePercent: 1.10,
        shariahCompliant: true,
        sector: "Technology",
        marketCap: "$2.8T",
        volume: "22.1M"
      },
      {
        symbol: "GOOGL",
        name: "Alphabet Inc",
        price: 142.56,
        change: 1.89,
        changePercent: 1.34,
        shariahCompliant: true,
        sector: "Technology",
        marketCap: "$1.8T",
        volume: "18.7M"
      },
      {
        symbol: "TSLA",
        name: "Tesla Inc",
        price: 248.42,
        change: -3.21,
        changePercent: -1.28,
        shariahCompliant: true,
        sector: "Automotive",
        marketCap: "$791B",
        volume: "67.8M"
      },
      {
        symbol: "NVDA",
        name: "NVIDIA Corporation",
        price: 131.26,
        change: 2.87,
        changePercent: 2.24,
        shariahCompliant: true,
        sector: "Technology",
        marketCap: "$3.2T",
        volume: "298.5M"
      }
    ]
  }

  const filteredStocks = filterShariah 
    ? shariahStocksData[selectedMarket].filter(stock => stock.shariahCompliant)
    : shariahStocksData[selectedMarket]

  const researchReports = [
    {
      id: 1,
      title: "Indonesia Energy Sector Analysis Q4 2024",
      category: "Energy",
      date: "2024-12-15",
      pages: 45,
      rating: 4.8,
      views: 1250,
      summary: "Comprehensive analysis of Indonesia's energy sector including renewable energy trends, oil & gas outlook, and investment opportunities.",
      tags: ["Energy", "Renewable", "Oil & Gas", "Indonesia"],
      downloadUrl: "/reports/indonesia-energy-sector-report.pdf",
      shariahCompliant: true
    },
    {
      id: 2,
      title: "Financial Services Sector Report 2024",
      category: "Financial",
      date: "2024-12-10",
      pages: 38,
      rating: 4.6,
      views: 980,
      summary: "Deep dive into Indonesia's financial services sector with focus on Islamic banking growth and fintech disruption.",
      tags: ["Banking", "Fintech", "Islamic Finance", "Digital"],
      downloadUrl: "/reports/indonesia-financial-sector-report.pdf",
      shariahCompliant: true
    },
    {
      id: 3,
      title: "Manufacturing & Industrial Outlook 2025",
      category: "Industrial",
      date: "2024-12-08",
      pages: 52,
      rating: 4.7,
      views: 1100,
      summary: "Analysis of Indonesia's manufacturing sector including automotive, textiles, and electronics industries.",
      tags: ["Manufacturing", "Automotive", "Electronics", "Export"],
      downloadUrl: "/reports/indonesia-industry-sector-report.pdf",
      shariahCompliant: true
    }
  ]

  const marketInsights = [
    {
      title: "Pasar Modal Syariah Tumbuh 15% YoY",
      description: "Kapitalisasi pasar modal syariah Indonesia mencapai rekor tertinggi",
      date: "2024-12-20",
      type: "positive"
    },
    {
      title: "Sektor Teknologi Menunjukkan Resiliensi",
      description: "Saham teknologi lokal outperform indeks utama di Q4 2024",
      date: "2024-12-18",
      type: "neutral"
    },
    {
      title: "Proyeksi Inflasi 2025 Terkendali",
      description: "Bank Indonesia memproyeksikan inflasi 2025 dalam target 2.5-4.5%",
      date: "2024-12-15",
      type: "positive"
    }
  ]

  const categories = [
    { id: 'all', name: 'Semua Kategori', count: 12 },
    { id: 'energy', name: 'Energi', count: 3 },
    { id: 'financial', name: 'Keuangan', count: 4 },
    { id: 'industrial', name: 'Industri', count: 2 },
    { id: 'technology', name: 'Teknologi', count: 3 }
  ]

  const filteredReports = useMemo(() => {
    return researchReports.filter(report => {
      const matchesSearch = report.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           report.summary.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesCategory = selectedCategory === 'all' || report.category.toLowerCase() === selectedCategory.toLowerCase()
      const matchesShariah = !filterShariah || report.shariahCompliant
      
      return matchesSearch && matchesCategory && matchesShariah
    })
  }, [searchQuery, selectedCategory, filterShariah])

  if (!mounted) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <BlubBlubBearLoader size="lg" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Market Research</h1>
          <p className="text-muted-foreground">
            Riset pasar mendalam dan laporan analisis profesional
          </p>
        </div>
        <Badge variant="outline" className="flex items-center gap-2">
          <FileText className="h-3 w-3" />
          {researchReports.length} Laporan Tersedia
        </Badge>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Cari laporan, sektor, atau topik..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="flex items-center gap-1"
                >
                  <Filter className="h-3 w-3" />
                  {category.name}
                  <Badge variant="secondary" className="ml-1">
                    {category.count}
                  </Badge>
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* TradingView Chart Section - At Top */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            {language === 'id-ID' ? 'Analisis Teknikal Saham Syariah' : 'Shariah Stock Technical Analysis'}
          </CardTitle>
          <CardDescription>
            {language === 'id-ID' ? 'Grafik candlestick dengan analisis teknikal lengkap' : 'Candlestick chart with complete technical analysis'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[500px] bg-muted rounded-lg overflow-hidden">
            <TradingViewChart 
              market={selectedMarket}
              height={500}
            />
          </div>
        </CardContent>
      </Card>

      {/* Shariah Stocks Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Indonesia Shariah Stocks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              {language === 'id-ID' ? 'Saham Syariah Indonesia' : 'Indonesia Shariah Stocks'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {shariahStocksData.IDX.map((stock, index) => (
                <div 
                  key={index} 
                  className={`p-3 rounded-lg border cursor-pointer transition-all hover:bg-muted ${
                    selectedStock === `IDX:${stock.symbol}` ? 'bg-blue-50 border-blue-200' : 'hover:border-gray-300'
                  }`}
                  onClick={() => {
                    setSelectedStock(`IDX:${stock.symbol}`)
                    setSelectedMarket('IDX')
                  }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{stock.symbol}</span>
                      <Badge variant="outline" className="text-green-600 text-xs">
                        <Shield className="h-2 w-2 mr-1" />
                        Syariah
                      </Badge>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-sm">{format(stock.price)}</p>
                      <p className={`text-xs ${
                        stock.changePercent >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">{stock.name}</p>
                    <p className="text-xs text-muted-foreground">{stock.sector}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* US Shariah Stocks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5" />
              {language === 'id-ID' ? 'Saham Syariah Amerika' : 'US Shariah Stocks'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {shariahStocksData.US.map((stock, index) => (
                <div 
                  key={index} 
                  className={`p-3 rounded-lg border cursor-pointer transition-all hover:bg-muted ${
                    selectedStock === `NASDAQ:${stock.symbol}` ? 'bg-blue-50 border-blue-200' : 'hover:border-gray-300'
                  }`}
                  onClick={() => {
                    setSelectedStock(`NASDAQ:${stock.symbol}`)
                    setSelectedMarket('US')
                  }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{stock.symbol}</span>
                      <Badge variant="outline" className="text-green-600 text-xs">
                        <Shield className="h-2 w-2 mr-1" />
                        Syariah
                      </Badge>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-sm">${stock.price}</p>
                      <p className={`text-xs ${
                        stock.changePercent >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">{stock.name}</p>
                    <p className="text-xs text-muted-foreground">{stock.sector}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-1 gap-6">
        {/* Research Reports */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Laporan Riset Terbaru
              </CardTitle>
              <CardDescription>
                Akses laporan riset profesional dan analisis mendalam
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredReports.map((report) => (
                  <div key={report.id} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">{report.title}</h3>
                          {report.shariahCompliant && (
                            <Badge variant="outline" className="text-green-600">
                              <Star className="h-3 w-3 mr-1" />
                              Syariah
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">
                          {report.summary}
                        </p>
                        <div className="flex flex-wrap gap-1 mb-3">
                          {report.tags.map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {new Date(report.date).toLocaleDateString('id-ID')}
                        </div>
                        <div className="flex items-center gap-1">
                          <FileText className="h-3 w-3" />
                          {report.pages} halaman
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          {report.views.toLocaleString()} views
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                          {report.rating}
                        </div>
                      </div>
                      <Button size="sm" className="flex items-center gap-1">
                        <Download className="h-3 w-3" />
                        Download PDF
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Market Insights */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Market Insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {marketInsights.map((insight, index) => (
                  <div key={index} className="p-3 border rounded-lg">
                    <div className="flex items-start gap-2">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        insight.type === 'positive' ? 'bg-green-500' : 
                        insight.type === 'negative' ? 'bg-red-500' : 'bg-yellow-500'
                      }`} />
                      <div className="flex-1">
                        <h4 className="font-medium text-sm mb-1">{insight.title}</h4>
                        <p className="text-xs text-muted-foreground mb-2">
                          {insight.description}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(insight.date).toLocaleDateString('id-ID')}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Research Categories */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Kategori Riset
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 hover:bg-muted rounded-lg transition-colors">
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    <span className="text-sm">Sektor Keuangan</span>
                  </div>
                  <Badge variant="secondary">4</Badge>
                </div>
                <div className="flex items-center justify-between p-2 hover:bg-muted rounded-lg transition-colors">
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    <span className="text-sm">Energi & Sumber Daya</span>
                  </div>
                  <Badge variant="secondary">3</Badge>
                </div>
                <div className="flex items-center justify-between p-2 hover:bg-muted rounded-lg transition-colors">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span className="text-sm">Konsumen & Retail</span>
                  </div>
                  <Badge variant="secondary">2</Badge>
                </div>
                <div className="flex items-center justify-between p-2 hover:bg-muted rounded-lg transition-colors">
                  <div className="flex items-center gap-2">
                    <PieChart className="h-4 w-4" />
                    <span className="text-sm">Teknologi</span>
                  </div>
                  <Badge variant="secondary">3</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" className="w-full justify-start">
                <Calendar className="h-4 w-4 mr-2" />
                Jadwal Riset Mingguan
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Bell className="h-4 w-4 mr-2" />
                Notifikasi Laporan Baru
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <FileText className="h-4 w-4 mr-2" />
                Request Riset Khusus
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* TradingView Chart Section - Moved to Top */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            {language === 'id-ID' ? 'Analisis Teknikal Saham Syariah' : 'Shariah Stock Technical Analysis'}
          </CardTitle>
          <CardDescription>
            {language === 'id-ID' ? 'Grafik candlestick dengan analisis teknikal lengkap' : 'Candlestick chart with complete technical analysis'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[500px] bg-muted rounded-lg overflow-hidden">
            <TradingViewChart 
              market={selectedMarket}
              height={500}
            />
          </div>
        </CardContent>
      </Card>

      {/* Shariah Market Map - Moved to Bottom */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            {language === 'id-ID' ? 'Peta Pasar Syariah' : 'Shariah Market Map'}
          </CardTitle>
          <CardDescription>
            {language === 'id-ID' ? 'Visualisasi performa saham syariah' : 'Shariah stock performance visualization'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <MarketTreemap region={selectedMarket} />
        </CardContent>
      </Card>
    </div>
  )
}
