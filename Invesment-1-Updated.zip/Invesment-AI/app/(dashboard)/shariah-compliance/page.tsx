"use client"

import { Shield, CheckCircle, XCircle, BookOpen, TrendingUp, Users, DollarSign } from "lucide-react"

interface ComplianceCriteria {
  title: string
  description: string
  compliant: boolean
  details: string
}

const complianceCriteria: ComplianceCriteria[] = [
  {
    title: "Interest-Free Operations",
    description: "Company does not engage in interest-based transactions",
    compliant: true,
    details: "The company operates without charging or paying interest (riba) in its core business activities."
  },
  {
    title: "Halal Business Activities",
    description: "Core business activities are permissible under Shariah law",
    compliant: true,
    details: "Primary business activities do not involve alcohol, gambling, pork, or other non-halal products/services."
  },
  {
    title: "Debt-to-Market Cap Ratio",
    description: "Total debt is less than 33% of market capitalization",
    compliant: true,
    details: "Company maintains a healthy debt-to-market cap ratio of 25%, well below the 33% threshold."
  },
  {
    title: "Interest-Bearing Securities",
    description: "Less than 33% of total assets in interest-bearing securities",
    compliant: true,
    details: "Only 15% of total assets are in interest-bearing securities, compliant with Shariah requirements."
  },
  {
    title: "Non-Halal Income",
    description: "Less than 5% of total income from non-halal sources",
    compliant: true,
    details: "Non-halal income represents only 2% of total revenue, well within acceptable limits."
  }
]

const shariahPrinciples = [
  {
    icon: Shield,
    title: "Prohibition of Riba (Interest)",
    description: "Islamic finance prohibits charging or paying interest on loans and deposits."
  },
  {
    icon: Users,
    title: "Risk Sharing",
    description: "Investors and entrepreneurs share both profits and losses in business ventures."
  },
  {
    icon: CheckCircle,
    title: "Asset-Backed Transactions",
    description: "All financial transactions must be backed by real, tangible assets."
  },
  {
    icon: TrendingUp,
    title: "Ethical Investment",
    description: "Investments must avoid businesses involving gambling, alcohol, or other prohibited activities."
  }
]

export default function ShariahCompliancePage() {
  return (
    <div className="p-4 bg-background">
      <div className="mb-4">
        <h1 className="text-xl font-semibold text-foreground mb-2">Shariah Compliance</h1>
        <p className="text-sm text-muted-foreground">Understanding Islamic investment principles and compliance criteria</p>
      </div>

      {/* Shariah Principles */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Islamic Investment Principles</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {shariahPrinciples.map((principle, index) => (
            <div key={index} className="bg-card rounded-lg border border-border p-4">
              <div className="flex items-center space-x-3 mb-3">
                <principle.icon className="h-6 w-6 text-primary" />
                <h3 className="font-medium text-sm">{principle.title}</h3>
              </div>
              <p className="text-xs text-muted-foreground">{principle.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Compliance Criteria */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Compliance Assessment Criteria</h2>
        <div className="space-y-4">
          {complianceCriteria.map((criteria, index) => (
            <div key={index} className="bg-card rounded-lg border border-border p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  {criteria.compliant ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500" />
                  )}
                  <div>
                    <h3 className="font-medium">{criteria.title}</h3>
                    <p className="text-sm text-muted-foreground">{criteria.description}</p>
                  </div>
                </div>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                  criteria.compliant 
                    ? "bg-green-100 text-green-700" 
                    : "bg-red-100 text-red-700"
                }`}>
                  {criteria.compliant ? "Compliant" : "Non-Compliant"}
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{criteria.details}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Compliance Statistics */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Market Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-card rounded-lg border border-border p-4">
            <div className="flex items-center space-x-3 mb-2">
              <Shield className="h-5 w-5 text-green-500" />
              <span className="font-medium">Shariah Compliant</span>
            </div>
            <div className="text-2xl font-bold text-green-600">85%</div>
            <p className="text-xs text-muted-foreground">of listed stocks meet Shariah criteria</p>
          </div>
          
          <div className="bg-card rounded-lg border border-border p-4">
            <div className="flex items-center space-x-3 mb-2">
              <DollarSign className="h-5 w-5 text-blue-500" />
              <span className="font-medium">Market Cap</span>
            </div>
            <div className="text-2xl font-bold text-blue-600">Rp 2,450 T</div>
            <p className="text-xs text-muted-foreground">Total Shariah-compliant market capitalization</p>
          </div>
          
          <div className="bg-card rounded-lg border border-border p-4">
            <div className="flex items-center space-x-3 mb-2">
              <TrendingUp className="h-5 w-5 text-purple-500" />
              <span className="font-medium">Growth Rate</span>
            </div>
            <div className="text-2xl font-bold text-purple-600">12.5%</div>
            <p className="text-xs text-muted-foreground">Annual growth in Shariah-compliant investments</p>
          </div>
        </div>
      </div>

      {/* Educational Resources */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Educational Resources</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-card rounded-lg border border-border p-4">
            <div className="flex items-center space-x-3 mb-3">
              <BookOpen className="h-5 w-5 text-primary" />
              <h3 className="font-medium">Shariah Investment Guide</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              Comprehensive guide to understanding Islamic investment principles and practices.
            </p>
            <button className="text-sm text-primary hover:text-primary/80 font-medium">
              Read Guide →
            </button>
          </div>
          
          <div className="bg-card rounded-lg border border-border p-4">
            <div className="flex items-center space-x-3 mb-3">
              <Shield className="h-5 w-5 text-primary" />
              <h3 className="font-medium">Compliance Reports</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              Detailed quarterly reports on Shariah compliance for all listed companies.
            </p>
            <button className="text-sm text-primary hover:text-primary/80 font-medium">
              View Reports →
            </button>
          </div>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="bg-muted rounded-lg border border-border p-4">
        <h3 className="font-medium mb-2">Important Disclaimer</h3>
        <p className="text-sm text-muted-foreground">
          The Shariah compliance assessments provided are based on our analysis and should not be considered as religious rulings. 
          Investors are advised to consult with qualified Islamic scholars for religious guidance on their investment decisions.
        </p>
      </div>
    </div>
  )
}

