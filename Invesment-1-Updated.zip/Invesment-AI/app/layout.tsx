import type React from "react"
import "@/app/globals.css"
import { Inter } from "next/font/google"
import type { Metadata } from "next"
import { ThemeProvider } from "@/contexts/theme-context"
import { LanguageProvider } from "@/contexts/language-context"
import { CurrencyProvider } from "@/contexts/currency-context"
import { SubscriptionProvider } from "@/contexts/subscription-context"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "BluBlub - Sharia Investment Research Platform",
  description: "Comprehensive Sharia investment research platform with Shariah-compliant analysis, TradingView integration, and expert insights",
  generator: "v0.dev",
  metadataBase: new URL("https://blublub-investment.com"),
  openGraph: {
    title: "BluBlub - Sharia Investment Research Platform",
    description:
      "Discover Shariah-compliant investment opportunities with our advanced research platform featuring real-time market analysis, TradingView charts, and expert insights.",
    images: [
      {
        url: "/placeholder-logo.png",
        width: 1200,
        height: 630,
        alt: "BluBlub Sharia Investment Research Platform",
      },
    ],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "BluBlub - Sharia Investment Research Platform",
    description:
      "Discover Shariah-compliant investment opportunities with our advanced research platform featuring real-time market analysis, TradingView charts, and expert insights.",
    images: [
      "/placeholder-logo.png",
    ],
    creator: "@blublub_investment",
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <LanguageProvider>
            <CurrencyProvider>
              <SubscriptionProvider>
                {children}
                <Toaster />
              </SubscriptionProvider>
            </CurrencyProvider>
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
