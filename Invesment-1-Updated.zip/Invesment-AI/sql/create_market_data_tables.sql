-- Supabase Database Schema for Islamic Investment Platform
-- Market Data Tables for Indonesian and US Shariah-compliant markets

-- 0. User Profiles Table (required for foreign key references)
CREATE TABLE profiles (
    id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255),
    avatar_url VARCHAR(1000),
    phone VARCHAR(20),
    date_of_birth DATE,
    country VARCHAR(2) DEFAULT 'ID',
    preferred_language VARCHAR(5) DEFAULT 'id',
    is_verified BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS for profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policy for profiles
CREATE POLICY "Users can view and update their own profile" ON profiles
    FOR ALL USING (auth.uid() = id);

-- Note: Profiles trigger will be created after the function is defined below

-- 1. Shariah Stock Lists
CREATE TABLE shariah_stocks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    market VARCHAR(10) NOT NULL CHECK (market IN ('IDX', 'US')),
    sector VARCHAR(100),
    industry VARCHAR(100),
    shariah_compliant BOOLEAN DEFAULT true,
    shariah_board VARCHAR(50), -- DSN-MUI for IDX, AAOIFI/MSCI for US
    last_reviewed DATE,
    market_cap DECIMAL(20,2),
    currency VARCHAR(3) DEFAULT 'IDR',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(symbol, market)
);

-- 2. Real-time Stock Prices
CREATE TABLE stock_prices (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    stock_id UUID REFERENCES shariah_stocks(id) ON DELETE CASCADE,
    symbol VARCHAR(20) NOT NULL,
    market VARCHAR(10) NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    open_price DECIMAL(15,4),
    high_price DECIMAL(15,4),
    low_price DECIMAL(15,4),
    close_price DECIMAL(15,4),
    volume BIGINT,
    change_amount DECIMAL(15,4),
    change_percent DECIMAL(8,4),
    currency VARCHAR(3),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_source VARCHAR(50), -- 'alpha_vantage', 'finnhub', 'yahoo_finance'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Market News
CREATE TABLE market_news (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    summary TEXT,
    content TEXT,
    url VARCHAR(1000),
    source VARCHAR(100),
    author VARCHAR(200),
    published_at TIMESTAMP WITH TIME ZONE,
    category VARCHAR(50), -- 'market', 'company', 'economic', 'shariah'
    market VARCHAR(10), -- 'IDX', 'US', 'GLOBAL'
    sentiment VARCHAR(20), -- 'positive', 'negative', 'neutral'
    related_symbols TEXT[], -- Array of stock symbols
    image_url VARCHAR(1000),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Economic Indicators
CREATE TABLE economic_indicators (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    indicator_name VARCHAR(100) NOT NULL,
    country VARCHAR(10) NOT NULL, -- 'ID', 'US'
    value DECIMAL(15,4),
    unit VARCHAR(50),
    period VARCHAR(20), -- 'monthly', 'quarterly', 'yearly'
    date DATE NOT NULL,
    previous_value DECIMAL(15,4),
    forecast_value DECIMAL(15,4),
    data_source VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(indicator_name, country, date)
);

-- 5. Trading Sessions
CREATE TABLE trading_sessions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    market VARCHAR(10) NOT NULL,
    session_date DATE NOT NULL,
    session_type VARCHAR(20), -- 'regular', 'pre_market', 'after_hours'
    start_time TIME,
    end_time TIME,
    timezone VARCHAR(50),
    is_active BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(market, session_date, session_type)
);

-- 6. User Watchlists
CREATE TABLE user_watchlists (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_default BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. Watchlist Items
CREATE TABLE watchlist_items (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    watchlist_id UUID REFERENCES user_watchlists(id) ON DELETE CASCADE,
    stock_id UUID REFERENCES shariah_stocks(id) ON DELETE CASCADE,
    added_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(watchlist_id, stock_id)
);

-- 8. Market Alerts
CREATE TABLE market_alerts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    stock_id UUID REFERENCES shariah_stocks(id) ON DELETE CASCADE,
    alert_type VARCHAR(20) NOT NULL, -- 'price_above', 'price_below', 'volume_spike', 'news'
    target_value DECIMAL(15,4),
    condition_met BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    triggered_at TIMESTAMP WITH TIME ZONE
);

-- Indexes for better performance
CREATE INDEX idx_stock_prices_symbol_timestamp ON stock_prices(symbol, timestamp DESC);
CREATE INDEX idx_stock_prices_market_timestamp ON stock_prices(market, timestamp DESC);
CREATE INDEX idx_market_news_published_at ON market_news(published_at DESC);
CREATE INDEX idx_market_news_category_market ON market_news(category, market);
CREATE INDEX idx_shariah_stocks_market ON shariah_stocks(market);
CREATE INDEX idx_shariah_stocks_sector ON shariah_stocks(sector);
CREATE INDEX idx_economic_indicators_country_date ON economic_indicators(country, date DESC);

-- Enable Row Level Security (RLS)
ALTER TABLE shariah_stocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_news ENABLE ROW LEVEL SECURITY;
ALTER TABLE economic_indicators ENABLE ROW LEVEL SECURITY;
ALTER TABLE trading_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_watchlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE watchlist_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_alerts ENABLE ROW LEVEL SECURITY;

-- RLS Policies
-- Public read access for market data
CREATE POLICY "Public read access for shariah stocks" ON shariah_stocks FOR SELECT USING (true);
CREATE POLICY "Public read access for stock prices" ON stock_prices FOR SELECT USING (true);
CREATE POLICY "Public read access for market news" ON market_news FOR SELECT USING (true);
CREATE POLICY "Public read access for economic indicators" ON economic_indicators FOR SELECT USING (true);
CREATE POLICY "Public read access for trading sessions" ON trading_sessions FOR SELECT USING (true);

-- User-specific access for watchlists and alerts
CREATE POLICY "Users can manage their watchlists" ON user_watchlists 
    FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can manage their watchlist items" ON watchlist_items 
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM user_watchlists 
            WHERE id = watchlist_items.watchlist_id 
            AND user_id = auth.uid()
        )
    );

CREATE POLICY "Users can manage their alerts" ON market_alerts 
    FOR ALL USING (auth.uid() = user_id);

-- Functions for automatic timestamp updates
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create the function first before using it in triggers above
-- Move the profiles trigger after function creation

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_shariah_stocks_updated_at BEFORE UPDATE ON shariah_stocks 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_market_news_updated_at BEFORE UPDATE ON market_news 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_user_watchlists_updated_at BEFORE UPDATE ON user_watchlists 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Additional tables for complete dashboard functionality

-- 9. AI Recommendations
CREATE TABLE ai_recommendations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    market VARCHAR(10) NOT NULL CHECK (market IN ('IDX', 'US')),
    recommendation VARCHAR(10) NOT NULL CHECK (recommendation IN ('BUY', 'SELL', 'HOLD')),
    confidence INTEGER CHECK (confidence >= 0 AND confidence <= 100),
    reason TEXT,
    target_price VARCHAR(50),
    timeframe VARCHAR(20) CHECK (timeframe IN ('daily', 'weekly', 'monthly')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true
);

-- 10. AI Chat History
CREATE TABLE ai_chat_history (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    response TEXT NOT NULL,
    context JSONB, -- Store conversation context
    session_id UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 11. User Preferences
CREATE TABLE user_preferences (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE UNIQUE,
    preferred_market VARCHAR(10) DEFAULT 'IDX' CHECK (preferred_market IN ('IDX', 'US')),
    preferred_timeframe VARCHAR(20) DEFAULT 'daily' CHECK (preferred_timeframe IN ('daily', 'weekly', 'monthly')),
    language VARCHAR(5) DEFAULT 'id' CHECK (language IN ('id', 'en')),
    currency VARCHAR(3) DEFAULT 'IDR' CHECK (currency IN ('IDR', 'USD')),
    theme VARCHAR(10) DEFAULT 'light' CHECK (theme IN ('light', 'dark', 'system')),
    notifications_enabled BOOLEAN DEFAULT true,
    email_alerts BOOLEAN DEFAULT false,
    push_alerts BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 12. Market Sectors (for categorization)
CREATE TABLE market_sectors (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    market VARCHAR(10) NOT NULL CHECK (market IN ('IDX', 'US')),
    description TEXT,
    is_shariah_compliant BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(name, market)
);

-- 13. Search History
CREATE TABLE search_history (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    query TEXT NOT NULL,
    results_count INTEGER DEFAULT 0,
    market VARCHAR(10),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 14. Market Performance Summary (for dashboard widgets)
CREATE TABLE market_performance (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    market VARCHAR(10) NOT NULL CHECK (market IN ('IDX', 'US')),
    date DATE NOT NULL,
    total_volume BIGINT,
    total_value DECIMAL(20,2),
    gainers_count INTEGER DEFAULT 0,
    losers_count INTEGER DEFAULT 0,
    unchanged_count INTEGER DEFAULT 0,
    top_gainer_symbol VARCHAR(20),
    top_gainer_change DECIMAL(8,4),
    top_loser_symbol VARCHAR(20),
    top_loser_change DECIMAL(8,4),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(market, date)
);

-- Indexes for new tables
CREATE INDEX idx_ai_recommendations_market_timeframe ON ai_recommendations(market, timeframe, is_active);
CREATE INDEX idx_ai_recommendations_symbol ON ai_recommendations(symbol);
CREATE INDEX idx_ai_chat_history_user_session ON ai_chat_history(user_id, session_id);
CREATE INDEX idx_ai_chat_history_created_at ON ai_chat_history(created_at DESC);
CREATE INDEX idx_user_preferences_user_id ON user_preferences(user_id);
CREATE INDEX idx_market_sectors_market ON market_sectors(market);
CREATE INDEX idx_search_history_user_created ON search_history(user_id, created_at DESC);
CREATE INDEX idx_market_performance_market_date ON market_performance(market, date DESC);

-- Enable RLS for new tables
ALTER TABLE ai_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_chat_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_sectors ENABLE ROW LEVEL SECURITY;
ALTER TABLE search_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_performance ENABLE ROW LEVEL SECURITY;

-- RLS Policies for new tables
CREATE POLICY "Public read AI recommendations" ON ai_recommendations FOR SELECT USING (true);
CREATE POLICY "Users can access their chat history" ON ai_chat_history FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users can manage their preferences" ON user_preferences FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Public read market sectors" ON market_sectors FOR SELECT USING (true);
CREATE POLICY "Users can access their search history" ON search_history FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Public read market performance" ON market_performance FOR SELECT USING (true);

-- Triggers for new tables
CREATE TRIGGER update_user_preferences_updated_at BEFORE UPDATE ON user_preferences 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert default market sectors
INSERT INTO market_sectors (name, market, description, is_shariah_compliant) VALUES
-- Indonesian sectors
('Perbankan Syariah', 'IDX', 'Islamic banking and financial services', true),
('Teknologi', 'IDX', 'Technology and digital services', true),
('Telekomunikasi', 'IDX', 'Telecommunications and media', true),
('Consumer Goods', 'IDX', 'Consumer staples and discretionary', true),
('Pertambangan', 'IDX', 'Mining and natural resources', true),
('Infrastruktur', 'IDX', 'Infrastructure and construction', true),
('Kesehatan', 'IDX', 'Healthcare and pharmaceuticals', true),

-- US sectors
('Technology', 'US', 'Technology hardware and software', true),
('Healthcare', 'US', 'Healthcare equipment and services', true),
('Consumer Discretionary', 'US', 'Consumer goods and services', true),
('Communication Services', 'US', 'Telecommunications and media', true),
('Industrials', 'US', 'Industrial goods and services', true),
('Renewable Energy', 'US', 'Clean and renewable energy', true),
('Real Estate', 'US', 'Shariah-compliant real estate', true);

-- Insert sample AI recommendations
INSERT INTO ai_recommendations (symbol, company_name, market, recommendation, confidence, reason, target_price, timeframe) VALUES
-- Indonesian recommendations
('BRIS', 'Bank BRISyariah Tbk', 'IDX', 'BUY', 85, 'Strong Islamic banking fundamentals with growing market share', 'Rp 2,800', 'monthly'),
('UNVR', 'Unilever Indonesia Tbk', 'IDX', 'HOLD', 75, 'Stable consumer goods performance', 'Rp 2,600', 'weekly'),
('TLKM', 'Telkom Indonesia Tbk', 'IDX', 'BUY', 80, 'Digital transformation driving growth', 'Rp 4,200', 'daily'),
('GOTO', 'GoTo Gojek Tokopedia Tbk', 'IDX', 'BUY', 78, 'Leading digital ecosystem in Indonesia', 'Rp 150', 'monthly'),
('ICBP', 'Indofood CBP Sukses Makmur Tbk', 'IDX', 'HOLD', 72, 'Consumer staples showing resilience', 'Rp 12,500', 'weekly'),

-- US recommendations
('AAPL', 'Apple Inc', 'US', 'BUY', 88, 'Strong ecosystem and innovation pipeline', '$185.00', 'monthly'),
('MSFT', 'Microsoft Corporation', 'US', 'BUY', 90, 'Cloud dominance and AI leadership', '$380.00', 'monthly'),
('GOOGL', 'Alphabet Inc', 'US', 'HOLD', 82, 'Search leadership with AI integration', '$140.00', 'weekly'),
('TSLA', 'Tesla Inc', 'US', 'BUY', 75, 'EV market leadership and energy storage', '$250.00', 'daily'),
('JNJ', 'Johnson & Johnson', 'US', 'HOLD', 78, 'Stable healthcare fundamentals', '$165.00', 'monthly');
