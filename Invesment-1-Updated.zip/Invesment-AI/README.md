# Investment-AI

🚀 **Sharia-Compliant Investment Platform with AI Analytics**

A modern Next.js application for Islamic investment management with AI-powered market analysis and portfolio optimization.

## Features

- 📊 Real-time market data analysis
- 🤖 AI-powered investment recommendations
- 📱 Responsive dashboard interface
- 🔐 Secure authentication system
- 📈 Portfolio tracking and analytics
- 🌙 Dark/Light theme support

## Tech Stack

- **Frontend**: Next.js 15, React, TypeScript
- **Styling**: Tailwind CSS
- **Authentication**: Supabase Auth
- **Database**: Supabase PostgreSQL
- **Deployment**: Vercel

## Quick Start

1. Clone the repository
```bash
git clone https://github.com/fifinternational/Invesment-AI.git
cd Invesment-AI
```

2. Install dependencies
```bash
npm install
# or
pnpm install
```

3. Set up environment variables
```bash
cp env/env.example .env.local
```

4. Run the development server
```bash
npm run dev
# or
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000) to view the application.

## Project Structure

```
├── app/                 # Next.js app directory
├── components/          # Reusable UI components
├── contexts/           # React contexts
├── hooks/              # Custom React hooks
├── lib/                # Utility libraries
├── public/             # Static assets
└── docs/               # Documentation
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License.
