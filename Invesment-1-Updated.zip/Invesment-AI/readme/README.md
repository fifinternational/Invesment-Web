# BluBlub - Sharia Investment Research Platform

![BluBlub Investment Research Platform](https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-04-21%20at%2000.01.09-1DI8PlTigyTXyu5nPuXVjFdbqYc5Av.png)

## Features

- Shariah-compliant stock analysis and screening
- Real-time market data with TradingView integration
- Sharia investment principles and compliance criteria
- Portfolio statistics with interactive charts
- Market research and analysis tools
- Watchlist for tracking Shariah-compliant stocks
- AI-powered research assistant
- Educational resources on Sharia finance

## Technologies Used

- Next.js 14 (App Router)
- Tailwind CSS
- Recharts for data visualization
- Lucide React for icons
- TypeScript

## Getting Started

1. Clone the repository
2. Install dependencies with `npm install`
3. Run the development server with `npm run dev`
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

- `/app` - Next.js app router pages
- `/components` - Reusable UI components
- `/public` - Static assets

## License

MIT
# Invesment-AI
# Invesment-AI
# Invesment-AI
