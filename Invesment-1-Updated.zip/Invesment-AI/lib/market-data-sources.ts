// Market Data Sources Configuration
// Sumber data terpercaya untuk pasar syariah Indonesia dan US

export interface MarketDataSource {
  name: string;
  baseUrl: string;
  apiKey?: string;
  rateLimit: number; // requests per minute
  markets: string[];
  features: string[];
}

export const MARKET_DATA_SOURCES: Record<string, MarketDataSource> = {
  // Alpha Vantage - Comprehensive financial data
  ALPHA_VANTAGE: {
    name: 'Alpha Vantage',
    baseUrl: 'https://www.alphavantage.co/query',
    rateLimit: 5, // Free tier: 5 requests per minute
    markets: ['US', 'IDX'],
    features: ['real-time-quotes', 'historical-data', 'news', 'fundamentals', 'technical-indicators']
  },

  // Finnhub - Real-time market data
  FINNHUB: {
    name: 'Finnhub',
    baseUrl: 'https://finnhub.io/api/v1',
    rateLimit: 60, // Free tier: 60 requests per minute
    markets: ['US', 'IDX'],
    features: ['real-time-quotes', 'company-news', 'market-news', 'earnings', 'insider-trading']
  },

  // Yahoo Finance (via RapidAPI) - Backup source
  YAHOO_FINANCE: {
    name: 'Yahoo Finance',
    baseUrl: 'https://yahoo-finance15.p.rapidapi.com',
    rateLimit: 500, // Varies by plan
    markets: ['US', 'IDX'],
    features: ['real-time-quotes', 'historical-data', 'news', 'options']
  },

  // NewsAPI - Financial news
  NEWS_API: {
    name: 'NewsAPI',
    baseUrl: 'https://newsapi.org/v2',
    rateLimit: 1000, // Free tier: 1000 requests per day
    markets: ['GLOBAL'],
    features: ['financial-news', 'company-news', 'market-sentiment']
  },

  // Indonesian specific sources
  IDX_API: {
    name: 'IDX Data Services',
    baseUrl: 'https://www.idx.co.id/umbraco/Surface/Helper',
    rateLimit: 100,
    markets: ['IDX'],
    features: ['shariah-stocks', 'market-data', 'trading-sessions']
  }
};

// Shariah-compliant stock symbols for Indonesia (IDX Islamic)
export const IDX_SHARIAH_STOCKS = [
  // Banking & Financial Services (Syariah)
  'BRIS', 'BTPS', 'BSIM', 'MAYA', 'PNBS',
  
  // Consumer Goods
  'UNVR', 'INDF', 'ICBP', 'KLBF', 'KAEF', 'SIDO', 'PYFA', 'MYOR',
  
  // Telecommunications
  'TLKM', 'ISAT', 'EXCL', 'FREN',
  
  // Mining & Energy
  'PTBA', 'ADRO', 'ITMG', 'HRUM', 'DOID', 'GEMS',
  
  // Infrastructure & Transportation
  'JSMR', 'WIKA', 'WSKT', 'PTPP', 'ADHI', 'WTON',
  
  // Technology
  'GOTO', 'BUKA', 'EMTK', 'KBLV',
  
  // Healthcare & Pharmaceuticals
  'KAEF', 'KLBF', 'SIDO', 'PYFA', 'MERK',
  
  // Retail & Trade
  'ACES', 'MAPI', 'LPPF', 'HERO', 'RALS'
];

// US Shariah-compliant stocks (MSCI Islamic indices)
export const US_SHARIAH_STOCKS = [
  // Technology
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'TSLA', 'NVDA', 'NFLX', 'ADBE', 'CRM',
  
  // Healthcare
  'JNJ', 'PFE', 'UNH', 'ABBV', 'TMO', 'DHR', 'BMY', 'AMGN', 'GILD', 'BIIB',
  
  // Consumer Goods
  'PG', 'KO', 'PEP', 'WMT', 'HD', 'MCD', 'NKE', 'SBUX', 'TGT', 'COST',
  
  // Industrial
  'BA', 'CAT', 'GE', 'MMM', 'HON', 'UPS', 'LMT', 'RTX', 'DE', 'EMR',
  
  // Energy (Renewable focus)
  'NEE', 'DUK', 'SO', 'EXC', 'XEL', 'AEP', 'SRE', 'D', 'PCG', 'ED'
];

// API endpoint configurations
export const API_ENDPOINTS = {
  // Alpha Vantage endpoints
  ALPHA_VANTAGE_QUOTE: (symbol: string) => 
    `?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${process.env.ALPHA_VANTAGE_API_KEY}`,
  
  ALPHA_VANTAGE_INTRADAY: (symbol: string, interval: string = '5min') =>
    `?function=TIME_SERIES_INTRADAY&symbol=${symbol}&interval=${interval}&apikey=${process.env.ALPHA_VANTAGE_API_KEY}`,
  
  ALPHA_VANTAGE_NEWS: (symbol?: string) =>
    `?function=NEWS_SENTIMENT${symbol ? `&tickers=${symbol}` : ''}&apikey=${process.env.ALPHA_VANTAGE_API_KEY}`,

  // Finnhub endpoints
  FINNHUB_QUOTE: (symbol: string) =>
    `/quote?symbol=${symbol}&token=${process.env.FINNHUB_API_KEY}`,
  
  FINNHUB_NEWS: (symbol: string) =>
    `/company-news?symbol=${symbol}&from=${new Date(Date.now() - 7*24*60*60*1000).toISOString().split('T')[0]}&to=${new Date().toISOString().split('T')[0]}&token=${process.env.FINNHUB_API_KEY}`,
  
  FINNHUB_MARKET_NEWS: () =>
    `/news?category=general&token=${process.env.FINNHUB_API_KEY}`,

  // NewsAPI endpoints
  NEWS_API_BUSINESS: () =>
    `/everything?q=stock market OR finance OR investment&language=en&sortBy=publishedAt&apiKey=${process.env.NEWS_API_KEY}`,
  
  NEWS_API_INDONESIA: () =>
    `/everything?q=Indonesia stock market OR IDX OR bursa efek&language=en&sortBy=publishedAt&apiKey=${process.env.NEWS_API_KEY}`
};

// Rate limiting configuration
export const RATE_LIMITS = {
  ALPHA_VANTAGE: { requests: 5, window: 60000 }, // 5 per minute
  FINNHUB: { requests: 60, window: 60000 }, // 60 per minute
  NEWS_API: { requests: 1000, window: 86400000 }, // 1000 per day
  YAHOO_FINANCE: { requests: 500, window: 60000 } // 500 per minute
};

// Market trading hours (in UTC)
export const TRADING_HOURS = {
  IDX: {
    timezone: 'Asia/Jakarta',
    sessions: [
      { name: 'pre_market', start: '02:00', end: '02:30' }, // 09:00-09:30 WIB
      { name: 'session_1', start: '02:30', end: '05:00' }, // 09:30-12:00 WIB
      { name: 'break', start: '05:00', end: '06:30' }, // 12:00-13:30 WIB
      { name: 'session_2', start: '06:30', end: '09:00' }  // 13:30-16:00 WIB
    ]
  },
  US: {
    timezone: 'America/New_York',
    sessions: [
      { name: 'pre_market', start: '09:00', end: '14:30' }, // 04:00-09:30 EST
      { name: 'regular', start: '14:30', end: '21:00' },   // 09:30-16:00 EST
      { name: 'after_hours', start: '21:00', end: '01:00' } // 16:00-20:00 EST
    ]
  }
};

// Shariah compliance criteria
export const SHARIAH_CRITERIA = {
  BUSINESS_ACTIVITIES: {
    prohibited: [
      'conventional_banking',
      'insurance',
      'gambling',
      'alcohol',
      'tobacco',
      'pork_products',
      'adult_entertainment',
      'weapons_manufacturing'
    ],
    allowed: [
      'technology',
      'healthcare',
      'consumer_goods',
      'telecommunications',
      'renewable_energy',
      'islamic_banking',
      'halal_food',
      'education'
    ]
  },
  FINANCIAL_RATIOS: {
    debt_to_market_cap: 0.33, // Max 33%
    cash_to_market_cap: 0.33, // Max 33%
    accounts_receivable_to_market_cap: 0.49, // Max 49%
    non_compliant_income: 0.05 // Max 5%
  }
};
