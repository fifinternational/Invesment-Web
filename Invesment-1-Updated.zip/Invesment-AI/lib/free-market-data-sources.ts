// Alternative Free Market Data Sources
// Comprehensive list of free APIs for Indonesian and US stock markets

export interface MarketDataSource {
  name: string;
  baseUrl: string;
  features: string[];
  rateLimit: string;
  apiKeyRequired: boolean;
  markets: string[];
  reliability: 'high' | 'medium' | 'low';
  setup: string;
}

export const FREE_MARKET_DATA_SOURCES: MarketDataSource[] = [
  // 1. Yahoo Finance (via yfinance - BEST FREE OPTION)
  {
    name: 'Yahoo Finance',
    baseUrl: 'https://query1.finance.yahoo.com/v8/finance/chart/',
    features: ['Real-time quotes', 'Historical data', 'Volume', 'Market cap'],
    rateLimit: 'No official limit (be reasonable)',
    apiKeyRequired: false,
    markets: ['IDX (.JK suffix)', 'US', 'Global'],
    reliability: 'high',
    setup: 'No registration needed - direct API calls'
  },

  // 2. Finnhub (60 calls/minute free)
  {
    name: 'Finnhub',
    baseUrl: 'https://finnhub.io/api/v1/',
    features: ['Real-time quotes', 'Company news', 'Earnings', 'Insider trading'],
    rateLimit: '60 calls/minute (free tier)',
    apiKeyRequired: true,
    markets: ['US', 'Global (limited IDX)'],
    reliability: 'high',
    setup: 'Register at finnhub.io/register'
  },

  // 3. Polygon.io (5 calls/minute free)
  {
    name: 'Polygon.io',
    baseUrl: 'https://api.polygon.io/v2/',
    features: ['Real-time quotes', 'Historical data', 'Market status'],
    rateLimit: '5 calls/minute (free tier)',
    apiKeyRequired: true,
    markets: ['US only'],
    reliability: 'high',
    setup: 'Register at polygon.io'
  },

  // 4. IEX Cloud (500 calls/month free)
  {
    name: 'IEX Cloud',
    baseUrl: 'https://cloud.iexapis.com/stable/',
    features: ['Real-time quotes', 'Company info', 'News', 'Stats'],
    rateLimit: '500 calls/month (free tier)',
    apiKeyRequired: true,
    markets: ['US only'],
    reliability: 'high',
    setup: 'Register at iexcloud.io'
  },

  // 5. Twelve Data (800 calls/day free)
  {
    name: 'Twelve Data',
    baseUrl: 'https://api.twelvedata.com/',
    features: ['Real-time quotes', 'Historical data', 'Technical indicators'],
    rateLimit: '800 calls/day (free tier)',
    apiKeyRequired: true,
    markets: ['US', 'IDX', 'Global'],
    reliability: 'medium',
    setup: 'Register at twelvedata.com'
  },

  // 6. World Trading Data (250 calls/day free)
  {
    name: 'World Trading Data',
    baseUrl: 'https://api.worldtradingdata.com/api/v1/',
    features: ['Real-time quotes', 'Historical data', 'Forex'],
    rateLimit: '250 calls/day (free tier)',
    apiKeyRequired: true,
    markets: ['US', 'Global'],
    reliability: 'medium',
    setup: 'Register at worldtradingdata.com'
  },

  // 7. Financial Modeling Prep (250 calls/day free)
  {
    name: 'Financial Modeling Prep',
    baseUrl: 'https://financialmodelingprep.com/api/v3/',
    features: ['Real-time quotes', 'Financial statements', 'Company profiles'],
    rateLimit: '250 calls/day (free tier)',
    apiKeyRequired: true,
    markets: ['US', 'Global'],
    reliability: 'medium',
    setup: 'Register at financialmodelingprep.com'
  },

  // 8. Quandl (50 calls/day free)
  {
    name: 'Quandl',
    baseUrl: 'https://www.quandl.com/api/v3/',
    features: ['Historical data', 'Economic indicators', 'Alternative data'],
    rateLimit: '50 calls/day (free tier)',
    apiKeyRequired: true,
    markets: ['US', 'Global economic data'],
    reliability: 'high',
    setup: 'Register at quandl.com'
  }
];

// Indonesian Stock Exchange specific sources
export const IDX_SPECIFIC_SOURCES: MarketDataSource[] = [
  // 1. Yahoo Finance for IDX (RECOMMENDED)
  {
    name: 'Yahoo Finance IDX',
    baseUrl: 'https://query1.finance.yahoo.com/v8/finance/chart/',
    features: ['IDX real-time quotes', 'Historical data', 'Volume'],
    rateLimit: 'No official limit',
    apiKeyRequired: false,
    markets: ['IDX (.JK suffix)'],
    reliability: 'high',
    setup: 'Use symbol + .JK (e.g., BBCA.JK, BRIS.JK)'
  },

  // 2. Investing.com (Web scraping - use carefully)
  {
    name: 'Investing.com IDX',
    baseUrl: 'https://www.investing.com/equities/',
    features: ['IDX quotes', 'News', 'Analysis'],
    rateLimit: 'Rate limiting via headers',
    apiKeyRequired: false,
    markets: ['IDX'],
    reliability: 'medium',
    setup: 'Web scraping (respect robots.txt)'
  }
];

// Sample API calls for each source
export const API_EXAMPLES = {
  yahooFinance: {
    // IDX stock (BBCA)
    idxStock: 'https://query1.finance.yahoo.com/v8/finance/chart/BBCA.JK',
    // US stock (AAPL)
    usStock: 'https://query1.finance.yahoo.com/v8/finance/chart/AAPL',
    // Multiple stocks
    multipleStocks: 'https://query1.finance.yahoo.com/v7/finance/quote?symbols=BBCA.JK,BRIS.JK,AAPL,MSFT'
  },
  
  finnhub: {
    // Real-time quote
    quote: 'https://finnhub.io/api/v1/quote?symbol=AAPL&token=YOUR_API_KEY',
    // Company news
    news: 'https://finnhub.io/api/v1/company-news?symbol=AAPL&from=2023-01-01&to=2023-12-31&token=YOUR_API_KEY'
  },

  twelveData: {
    // Real-time quote
    quote: 'https://api.twelvedata.com/quote?symbol=AAPL&apikey=YOUR_API_KEY',
    // IDX stock
    idxQuote: 'https://api.twelvedata.com/quote?symbol=BBCA&exchange=IDX&apikey=YOUR_API_KEY'
  }
};

// Shariah-compliant stocks for each market
export const SHARIAH_STOCKS = {
  IDX: [
    'BRIS.JK', // Bank BRISyariah
    'UNVR.JK', // Unilever Indonesia
    'TLKM.JK', // Telkom Indonesia
    'GOTO.JK', // GoTo Gojek Tokopedia
    'ICBP.JK', // Indofood CBP
    'INDF.JK', // Indofood Sukses Makmur
    'KLBF.JK', // Kalbe Farma
    'ASII.JK', // Astra International
    'ADRO.JK', // Adaro Energy
    'PTBA.JK'  // Bukit Asam
  ],
  
  US: [
    'AAPL',  // Apple Inc
    'MSFT',  // Microsoft
    'GOOGL', // Alphabet
    'TSLA',  // Tesla
    'JNJ',   // Johnson & Johnson
    'PFE',   // Pfizer
    'KO',    // Coca-Cola
    'PEP',   // PepsiCo
    'WMT',   // Walmart
    'HD'     // Home Depot
  ]
};

// Rate limiting helper
export class RateLimiter {
  private calls: { [key: string]: number[] } = {};

  canMakeCall(source: string, limit: number, timeWindow: number = 60000): boolean {
    const now = Date.now();
    const sourceKey = source.toLowerCase();
    
    if (!this.calls[sourceKey]) {
      this.calls[sourceKey] = [];
    }
    
    // Remove old calls outside time window
    this.calls[sourceKey] = this.calls[sourceKey].filter(
      timestamp => now - timestamp < timeWindow
    );
    
    // Check if we can make a new call
    if (this.calls[sourceKey].length < limit) {
      this.calls[sourceKey].push(now);
      return true;
    }
    
    return false;
  }

  getNextAvailableTime(source: string, limit: number, timeWindow: number = 60000): number {
    const sourceKey = source.toLowerCase();
    if (!this.calls[sourceKey] || this.calls[sourceKey].length < limit) {
      return 0; // Can make call now
    }
    
    const oldestCall = Math.min(...this.calls[sourceKey]);
    return oldestCall + timeWindow - Date.now();
  }
}

export const rateLimiter = new RateLimiter();
