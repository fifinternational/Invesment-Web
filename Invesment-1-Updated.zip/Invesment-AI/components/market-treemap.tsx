"use client"

import { useState } from "react"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

type Region = "ID" | "US"

interface StockData {
  symbol: string
  name: string
  sector: string
  marketCap: number
  change: number
  price: string
  shariahCompliant: boolean
}

export default function MarketTreemap({ region = "ID" }: { region?: Region }) {
  const [selectedSector, setSelectedSector] = useState<string | null>(null)

  const indonesiaStocks: StockData[] = [
    // Technology
    { symbol: "GOTO", name: "GoTo Gojek Tokopedia", sector: "Technology", marketCap: 15000, change: 2.45, price: "Rp 118", shariahCompliant: true },
    { symbol: "BUKA", name: "Bukalapak", sector: "Technology", marketCap: 8000, change: -1.23, price: "Rp 85", shariahCompliant: true },
    { symbol: "EMTK", name: "Elang Mahkota Teknologi", sector: "Technology", marketCap: 5000, change: 3.21, price: "Rp 2,450", shariahCompliant: true },
    
    // Consumer Goods
    { symbol: "UNVR", name: "Unilever Indonesia", sector: "Consumer Goods", marketCap: 45000, change: 1.87, price: "Rp 4,250", shariahCompliant: true },
    { symbol: "ICBP", name: "Indofood CBP", sector: "Consumer Goods", marketCap: 35000, change: 2.15, price: "Rp 11,250", shariahCompliant: true },
    { symbol: "KLBF", name: "Kalbe Farma", sector: "Consumer Goods", marketCap: 25000, change: 0.95, price: "Rp 1,485", shariahCompliant: true },
    
    // Industrial
    { symbol: "ASII", name: "Astra International", sector: "Industrial", marketCap: 85000, change: 2.04, price: "Rp 6,250", shariahCompliant: true },
    { symbol: "INTP", name: "Indocement Tunggal", sector: "Industrial", marketCap: 28000, change: -0.45, price: "Rp 9,850", shariahCompliant: true },
    { symbol: "SMGR", name: "Semen Indonesia", sector: "Industrial", marketCap: 22000, change: 1.23, price: "Rp 4,180", shariahCompliant: true },
    
    // Telecommunications
    { symbol: "TLKM", name: "Telkom Indonesia", sector: "Telecommunications", marketCap: 38000, change: 1.99, price: "Rp 3,850", shariahCompliant: true },
    { symbol: "ISAT", name: "Indosat Ooredoo", sector: "Telecommunications", marketCap: 15000, change: 0.67, price: "Rp 5,425", shariahCompliant: true },
    
    // Energy
    { symbol: "PGAS", name: "Perusahaan Gas Negara", sector: "Energy", marketCap: 32000, change: 2.87, price: "Rp 1,875", shariahCompliant: true },
    { symbol: "ADRO", name: "Adaro Energy", sector: "Energy", marketCap: 18000, change: -1.45, price: "Rp 2,950", shariahCompliant: true }
  ]

  const usStocks: StockData[] = [
    // Technology
    { symbol: "AAPL", name: "Apple Inc", sector: "Technology", marketCap: 3200000, change: 0.64, price: "$214.55", shariahCompliant: true },
    { symbol: "MSFT", name: "Microsoft Corp", sector: "Technology", marketCap: 3100000, change: 0.31, price: "$421.12", shariahCompliant: true },
    { symbol: "GOOGL", name: "Alphabet Inc", sector: "Technology", marketCap: 2100000, change: 1.23, price: "$168.45", shariahCompliant: false },
    { symbol: "META", name: "Meta Platforms", sector: "Technology", marketCap: 1400000, change: -0.87, price: "$542.81", shariahCompliant: false },
    
    // Healthcare
    { symbol: "JNJ", name: "Johnson & Johnson", sector: "Healthcare", marketCap: 420000, change: 0.45, price: "$174.23", shariahCompliant: true },
    { symbol: "PFE", name: "Pfizer Inc", sector: "Healthcare", marketCap: 180000, change: -1.23, price: "$32.15", shariahCompliant: true },
    
    // Consumer Goods
    { symbol: "PG", name: "Procter & Gamble", sector: "Consumer Goods", marketCap: 380000, change: 1.12, price: "$158.67", shariahCompliant: true },
    { symbol: "KO", name: "Coca-Cola", sector: "Consumer Goods", marketCap: 260000, change: 0.78, price: "$61.23", shariahCompliant: true },
    
    // Industrial
    { symbol: "CAT", name: "Caterpillar Inc", sector: "Industrial", marketCap: 180000, change: 2.34, price: "$345.12", shariahCompliant: true },
    { symbol: "GE", name: "General Electric", sector: "Industrial", marketCap: 150000, change: 1.87, price: "$138.45", shariahCompliant: true },
    
    // ETFs
    { symbol: "HLAL", name: "Wahed FTSE USA Shariah ETF", sector: "ETF", marketCap: 50000, change: 0.22, price: "$47.98", shariahCompliant: true },
    { symbol: "ISWD", name: "iShares MSCI World Islamic ETF", sector: "ETF", marketCap: 35000, change: 0.35, price: "$78.50", shariahCompliant: true }
  ]

  const currentStocks = region === "ID" ? indonesiaStocks : usStocks
  const shariahStocks = currentStocks.filter(stock => stock.shariahCompliant)
  
  // Group by sector and calculate sizes
  const sectorData = shariahStocks.reduce((acc, stock) => {
    if (!acc[stock.sector]) {
      acc[stock.sector] = {
        sector: stock.sector,
        stocks: [],
        totalMarketCap: 0,
        avgChange: 0
      }
    }
    acc[stock.sector].stocks.push(stock)
    acc[stock.sector].totalMarketCap += stock.marketCap
    return acc
  }, {} as Record<string, { sector: string; stocks: StockData[]; totalMarketCap: number; avgChange: number }>)

  // Calculate average change for each sector
  Object.values(sectorData).forEach(sector => {
    sector.avgChange = sector.stocks.reduce((sum, stock) => sum + stock.change, 0) / sector.stocks.length
  })

  const totalMarketCap = Object.values(sectorData).reduce((sum, sector) => sum + sector.totalMarketCap, 0)

  const getSectorColor = (change: number) => {
    if (change > 1.5) return "bg-green-500"
    if (change > 0.5) return "bg-green-400" 
    if (change > 0) return "bg-green-300"
    if (change > -0.5) return "bg-yellow-300"
    if (change > -1.5) return "bg-red-300"
    return "bg-red-400"
  }

  const getStockSize = (marketCap: number, sectorTotal: number) => {
    const percentage = (marketCap / sectorTotal) * 100
    if (percentage > 40) return "text-sm font-bold"
    if (percentage > 20) return "text-xs font-semibold"
    return "text-xs"
  }

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold">Market Research - Shariah Compliant Stocks</h2>
          <p className="text-sm text-muted-foreground">
            {region === "ID" ? "Indonesia" : "US"} Market Treemap by Market Cap
          </p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Total Market Cap</p>
          <p className="text-lg font-bold">
            {region === "ID" ? `Rp ${(totalMarketCap / 1000).toFixed(0)}T` : `$${(totalMarketCap / 1000000).toFixed(1)}T`}
          </p>
        </div>
      </div>

      {/* Treemap Visualization */}
      <div className="grid grid-cols-12 gap-1 h-96 mb-6">
        {Object.values(sectorData).map((sector, sectorIndex) => {
          const sectorWidth = Math.max(2, Math.round((sector.totalMarketCap / totalMarketCap) * 12))
          
          return (
            <div
              key={sector.sector}
              className={`col-span-${sectorWidth} grid gap-1 cursor-pointer transition-all duration-200 hover:scale-105`}
              onClick={() => setSelectedSector(selectedSector === sector.sector ? null : sector.sector)}
            >
              {/* Sector Header */}
              <div className={`${getSectorColor(sector.avgChange)} p-2 rounded-t text-white text-center`}>
                <div className="text-xs font-bold uppercase tracking-wide">{sector.sector}</div>
                <div className="text-xs flex items-center justify-center space-x-1">
                  {sector.avgChange > 0 ? <TrendingUp className="h-3 w-3" /> : 
                   sector.avgChange < 0 ? <TrendingDown className="h-3 w-3" /> : 
                   <Minus className="h-3 w-3" />}
                  <span>{sector.avgChange > 0 ? '+' : ''}{sector.avgChange.toFixed(2)}%</span>
                </div>
              </div>

              {/* Stocks in Sector */}
              <div className="grid gap-1 flex-1">
                {sector.stocks.map((stock, stockIndex) => {
                  const stockHeight = Math.max(1, Math.round((stock.marketCap / sector.totalMarketCap) * 6))
                  
                  return (
                    <div
                      key={stock.symbol}
                      className={`${getSectorColor(stock.change)} p-1 rounded text-white text-center flex flex-col justify-center min-h-[40px] hover:opacity-90 transition-opacity`}
                      style={{ 
                        height: `${stockHeight * 20}px`,
                        minHeight: '40px'
                      }}
                    >
                      <div className={getStockSize(stock.marketCap, sector.totalMarketCap)}>
                        {stock.symbol}
                      </div>
                      <div className="text-xs opacity-90">
                        {stock.change > 0 ? '+' : ''}{stock.change.toFixed(1)}%
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>

      {/* Legend */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-4">
          <span className="text-sm font-medium">Performance:</span>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-500 rounded"></div>
            <span className="text-xs">Strong (+1.5%+)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-300 rounded"></div>
            <span className="text-xs">Positive (0% to +1.5%)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-yellow-300 rounded"></div>
            <span className="text-xs">Neutral (-0.5% to 0%)</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-red-300 rounded"></div>
            <span className="text-xs">Declining (-0.5%+)</span>
          </div>
        </div>
        <div className="text-xs text-muted-foreground">
          Size = Market Capitalization
        </div>
      </div>

      {/* Selected Sector Details */}
      {selectedSector && (
        <div className="bg-muted/50 rounded-lg p-4">
          <h3 className="font-bold text-lg mb-3">{selectedSector} Sector Details</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sectorData[selectedSector].stocks.map((stock, index) => (
              <div key={index} className="bg-card rounded border p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold">{stock.symbol}</span>
                  <span className={`text-xs px-2 py-1 rounded ${
                    stock.change > 0 ? 'bg-green-100 text-green-800' : 
                    stock.change < 0 ? 'bg-red-100 text-red-800' : 
                    'bg-gray-100 text-gray-800'
                  }`}>
                    {stock.change > 0 ? '+' : ''}{stock.change.toFixed(2)}%
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-1">{stock.name}</p>
                <div className="flex justify-between text-xs">
                  <span>Price: {stock.price}</span>
                  <span>
                    Cap: {region === "ID" ? 
                      `Rp ${(stock.marketCap / 1000).toFixed(0)}T` : 
                      `$${(stock.marketCap / 1000000).toFixed(1)}T`
                    }
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Market Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
        {Object.values(sectorData).map((sector, index) => (
          <div key={index} className="bg-muted/30 rounded-lg p-3 text-center">
            <h4 className="font-semibold text-sm">{sector.sector}</h4>
            <p className="text-xs text-muted-foreground">{sector.stocks.length} stocks</p>
            <p className={`text-sm font-bold ${
              sector.avgChange > 0 ? 'text-green-600' : 
              sector.avgChange < 0 ? 'text-red-600' : 'text-gray-600'
            }`}>
              {sector.avgChange > 0 ? '+' : ''}{sector.avgChange.toFixed(2)}%
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
