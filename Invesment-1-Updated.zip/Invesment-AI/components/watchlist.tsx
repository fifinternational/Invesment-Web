import { MoreVertical } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"
import { useSubscription } from "@/contexts/subscription-context"

type Region = "ID" | "US"

export default function Watchlist({ region = "ID" }: { region?: Region }) {
  const { t } = useLanguage()
  const { subscriptionTier } = useSubscription()
  const watchlistData = [
    // Only list Shariah-friendly categories; banking/tobacco/alcohol excluded
    { stock: "ASII", region: "ID", last: "6,250", change: "+2.04%", changeColor: "text-emerald-500", volume: "Rp 650B" },
    { stock: "ASII", region: "ID", last: "6,250", change: "+2.04%", changeColor: "text-emerald-500", volume: "Rp 650B" },
    { stock: "TLKM", region: "ID", last: "3,850", change: "+1.99%", changeColor: "text-emerald-500", volume: "Rp 430B" },
    { stock: "UNVR", region: "ID", last: "4,250", change: "+2.41%", changeColor: "text-emerald-500", volume: "Rp 210B" },
    { stock: "ICBP", region: "ID", last: "11,250", change: "+2.27%", changeColor: "text-emerald-500", volume: "Rp 340B" },
    { stock: "XSSI", region: "ID", last: "6,255", change: "+0.45%", changeColor: "text-emerald-500", volume: "Rp 95B" },
    { stock: "AAPL", region: "US", last: "$214.55", change: "+0.64%", changeColor: "text-emerald-500", volume: "$51.2M" },
    { stock: "MSFT", region: "US", last: "$421.12", change: "+0.31%", changeColor: "text-emerald-500", volume: "$36.9M" },
    { stock: "HLAL", region: "US", last: "$47.98", change: "+0.22%", changeColor: "text-emerald-500", volume: "$12.4M" },
    { stock: "ISWD", region: "US", last: "$78.50", change: "+0.35%", changeColor: "text-emerald-500", volume: "$18.3M" },
    { stock: "RD-SYA1", region: "ID", last: "1,990", change: "+0.18%", changeColor: "text-emerald-500", volume: "Rp 22B" },
  ] as Array<{ stock: string; region: Region; last: string; change: string; changeColor: string; volume: string }>

  // Limit watchlist items based on subscription tier
  const filtered = watchlistData.filter((w) => w.region === region)
  const limitedWatchlist = subscriptionTier === 'trial' ? filtered.slice(0, 5) : filtered

  return (
    <div className="bg-card rounded-lg border border-border p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">{t("watchlist_title")}</h2>
        <button>
          <MoreVertical className="h-5 w-5 text-muted-foreground" />
        </button>
      </div>

      <div className="overflow-x-auto -mx-4 px-4">
        <div className="min-w-[400px]">
          <div className="grid grid-cols-4 gap-2 mb-2 text-xs text-muted-foreground">
            <div>{t("col_ticker")}</div>
            <div>{t("col_last")}</div>
            <div>{t("col_change_pct")}</div>
            <div>{t("col_volume")}</div>
          </div>

          <div className="space-y-2">
            {limitedWatchlist.map((item, index) => (
              <div
                key={index}
                className="grid grid-cols-4 gap-2 text-xs border-b border-border pb-2 last:border-0 last:pb-0"
              >
                <div>
                  <Link href={`/research?symbol=${encodeURIComponent(item.stock)}&region=${region}`} className="hover:underline">
                    {item.stock}
                  </Link>
                </div>
                <div>{item.last}</div>
                <div className={item.changeColor}>{item.change}</div>
                <div>{item.volume}</div>
              </div>
            ))}
          </div>
          
          {/* Trial limitation notice */}
          {subscriptionTier === 'trial' && filtered.length > 5 && (
            <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                Showing {limitedWatchlist.length} of {filtered.length} stocks. 
                <Link href="/profile/subscription" className="ml-1 underline hover:no-underline">
                  Upgrade to view all
                </Link>
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
