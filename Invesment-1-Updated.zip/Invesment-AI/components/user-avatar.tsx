"use client"

import { useState, useEffect } from "react"
import { createBrowserClient } from "@supabase/ssr"
import { User, Settings, LogOut, UserCircle } from "lucide-react"
import { useRouter } from "next/navigation"

interface UserAvatarProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export default function UserAvatar({ className = "", size = "md" }: UserAvatarProps) {
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [isOpen, setIsOpen] = useState(false)
  const [mounted, setMounted] = useState(false)
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
  const router = useRouter()

  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-10 h-10", 
    lg: "w-12 h-12"
  }

  useEffect(() => {
    setMounted(true)
    loadUserData()
  }, [])

  const loadUserData = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      
      if (session?.user) {
        setUser(session.user)
        
        // Load profile data from database
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single()
        
        if (profile) {
          setProfile(profile)
        }
      } else {
        // Fallback for demo users
        const isLoggedIn = sessionStorage.getItem("isLoggedIn") === "true"
        if (isLoggedIn) {
          const demoUser = {
            id: 'demo-user-id',
            email: 'demo@example.com',
            user_metadata: {
              full_name: 'Demo User',
              avatar_url: null
            }
          }
          setUser(demoUser)
        }
      }
    } catch (error) {
      console.error('Error loading user data:', error)
    }
  }

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut()
      sessionStorage.clear()
      document.cookie = "isLoggedIn=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT"
      router.push('/login')
    } catch (error) {
      console.error('Error logging out:', error)
    }
  }

  // Get avatar URL with fallback
  const avatarUrl = profile?.avatar_url || user?.user_metadata?.avatar_url || user?.user_metadata?.picture
  const displayName = profile?.full_name || user?.user_metadata?.full_name || user?.user_metadata?.name || user?.email?.split('@')[0] || 'User'

  if (!mounted || !user) {
    return (
      <div className={`${sizeClasses[size]} rounded-full bg-muted flex items-center justify-center ${className}`}>
        <User className="h-5 w-5 text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`${sizeClasses[size]} rounded-full overflow-hidden bg-muted flex items-center justify-center hover:ring-2 hover:ring-primary hover:ring-offset-2 transition-all ${className}`}
      >
        {avatarUrl ? (
          <img 
            src={avatarUrl} 
            alt="Profile" 
            className="w-full h-full object-cover"
          />
        ) : (
          <User className={`${size === 'sm' ? 'h-4 w-4' : size === 'md' ? 'h-5 w-5' : 'h-6 w-6'} text-muted-foreground`} />
        )}
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-border z-20">
            <div className="p-4 border-b border-border">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-muted flex items-center justify-center">
                  {avatarUrl ? (
                    <img 
                      src={avatarUrl} 
                      alt="Profile" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <User className="h-6 w-6 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {displayName}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {user.email}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {profile?.provider === 'google' ? 'Google Account' : 'Email Account'}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="py-2">
              <button
                onClick={() => {
                  router.push('/profile')
                  setIsOpen(false)
                }}
                className="w-full flex items-center space-x-3 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
              >
                <UserCircle className="h-4 w-4" />
                <span>Profil Saya</span>
              </button>
              
              <button
                onClick={() => {
                  router.push('/profile/subscription')
                  setIsOpen(false)
                }}
                className="w-full flex items-center space-x-3 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
              >
                <Settings className="h-4 w-4" />
                <span>Pengaturan</span>
              </button>
            </div>
            
            <div className="border-t border-border py-2">
              <button
                onClick={handleLogout}
                className="w-full flex items-center space-x-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Keluar</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
