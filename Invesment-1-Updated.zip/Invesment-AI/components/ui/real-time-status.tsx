"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Activity, Wifi, WifiOff, RefreshCw, CheckCircle, AlertCircle } from 'lucide-react'

interface RealTimeStatusProps {
  onTestConnection?: () => void
}

export function RealTimeStatus({ onTestConnection }: RealTimeStatusProps) {
  const [connectionStatus, setConnectionStatus] = useState<'checking' | 'connected' | 'disconnected'>('checking')
  const [lastPriceUpdate, setLastPriceUpdate] = useState<Date | null>(null)
  const [updateCount, setUpdateCount] = useState(0)
  const [testResults, setTestResults] = useState<any[]>([])

  // Test real-time connection
  const testRealTimeConnection = async () => {
    setConnectionStatus('checking')
    setTestResults([])
    
    try {
      // Test 1: Yahoo Finance API
      console.log('🔄 Testing Yahoo Finance API...')
      const yahooTest = await fetch('/api/free-market-data?action=quote&symbol=AAPL&market=US')
      const yahooResult = await yahooTest.json()
      
      setTestResults(prev => [...prev, {
        name: 'Yahoo Finance API',
        status: yahooResult.success ? 'success' : 'error',
        message: yahooResult.success ? 'Connected ✅' : 'Failed ❌',
        data: yahooResult.success ? `Price: $${yahooResult.data.current_price}` : yahooResult.error
      }])

      // Test 2: Multiple quotes
      console.log('🔄 Testing multiple quotes...')
      const multipleTest = await fetch('/api/free-market-data?action=multiple-quotes&symbols=AAPL,MSFT')
      const multipleResult = await multipleTest.json()
      
      setTestResults(prev => [...prev, {
        name: 'Multiple Quotes',
        status: multipleResult.success ? 'success' : 'error',
        message: multipleResult.success ? `${multipleResult.data.length} stocks loaded ✅` : 'Failed ❌',
        data: multipleResult.success ? `Symbols: ${multipleResult.data.map((s: any) => s.symbol).join(', ')}` : multipleResult.error
      }])

      // Test 3: IDX stocks
      console.log('🔄 Testing IDX stocks...')
      const idxTest = await fetch('/api/free-market-data?action=shariah-stocks&market=IDX')
      const idxResult = await idxTest.json()
      
      setTestResults(prev => [...prev, {
        name: 'IDX Shariah Stocks',
        status: idxResult.success ? 'success' : 'error',
        message: idxResult.success ? `${idxResult.data.length} IDX stocks ✅` : 'Failed ❌',
        data: idxResult.success ? `Stocks: ${idxResult.data.slice(0,3).map((s: any) => s.symbol).join(', ')}...` : idxResult.error
      }])

      // Test 4: Market news
      console.log('🔄 Testing market news...')
      const newsTest = await fetch('/api/free-market-data?action=market-news&market=IDX')
      const newsResult = await newsTest.json()
      
      setTestResults(prev => [...prev, {
        name: 'Market News',
        status: newsResult.success ? 'success' : 'error',
        message: newsResult.success ? `${newsResult.data.length} news items ✅` : 'Failed ❌',
        data: newsResult.success ? `Latest: ${newsResult.data[0]?.title.substring(0, 50)}...` : newsResult.error
      }])

      // Overall connection status
      const allSuccess = testResults.every(test => test.status === 'success')
      setConnectionStatus(allSuccess ? 'connected' : 'disconnected')
      setLastPriceUpdate(new Date())
      setUpdateCount(prev => prev + 1)

    } catch (error: any) {
      console.error('Connection test error:', error)
      setTestResults(prev => [...prev, {
        name: 'Connection Test',
        status: 'error',
        message: 'Test failed ❌',
        data: error.message
      }])
      setConnectionStatus('disconnected')
    }
  }

  // Auto-test on mount
  useEffect(() => {
    testRealTimeConnection()
  }, [])

  // Simulate real-time updates every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      if (connectionStatus === 'connected') {
        setLastPriceUpdate(new Date())
        setUpdateCount(prev => prev + 1)
        console.log(`📊 Real-time update #${updateCount + 1} at ${new Date().toLocaleTimeString()}`)
      }
    }, 30000) // 30 seconds

    return () => clearInterval(interval)
  }, [connectionStatus, updateCount])

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Status Real-Time Data
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Connection Overview */}
        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-3">
            {connectionStatus === 'connected' ? (
              <Wifi className="h-5 w-5 text-green-600" />
            ) : connectionStatus === 'disconnected' ? (
              <WifiOff className="h-5 w-5 text-red-600" />
            ) : (
              <RefreshCw className="h-5 w-5 animate-spin text-blue-600" />
            )}
            
            <div>
              <p className="font-medium">
                {connectionStatus === 'connected' ? 'Real-Time Aktif' : 
                 connectionStatus === 'disconnected' ? 'Koneksi Bermasalah' : 
                 'Mengecek Koneksi...'}
              </p>
              <p className="text-sm text-gray-600">
                Update #{updateCount} • Interval: 30 detik
              </p>
            </div>
          </div>
          
          <Button 
            onClick={testRealTimeConnection}
            variant="outline" 
            size="sm"
            disabled={connectionStatus === 'checking'}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${connectionStatus === 'checking' ? 'animate-spin' : ''}`} />
            Test Koneksi
          </Button>
        </div>

        {/* Real-time Indicators */}
        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 border rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <div className={`w-2 h-2 rounded-full ${
                connectionStatus === 'connected' ? 'bg-green-500 animate-pulse' : 'bg-gray-400'
              }`} />
              <span className="text-sm font-medium">Data Updates</span>
            </div>
            <p className="text-xs text-gray-600">
              {lastPriceUpdate ? 
                `Terakhir: ${lastPriceUpdate.toLocaleTimeString('id-ID')}` : 
                'Belum ada update'
              }
            </p>
          </div>

          <div className="p-3 border rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <div className={`w-2 h-2 rounded-full ${
                updateCount > 0 ? 'bg-blue-500' : 'bg-gray-400'
              }`} />
              <span className="text-sm font-medium">Update Count</span>
            </div>
            <p className="text-xs text-gray-600">
              {updateCount} updates received
            </p>
          </div>
        </div>

        {/* Test Results */}
        {testResults.length > 0 && (
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Test Results:</h4>
            {testResults.map((test, index) => (
              <div key={index} className="flex items-center justify-between p-2 border rounded text-sm">
                <div className="flex items-center gap-2">
                  {test.status === 'success' ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <AlertCircle className="h-4 w-4 text-red-600" />
                  )}
                  <span className="font-medium">{test.name}</span>
                </div>
                <div className="text-right">
                  <p className={test.status === 'success' ? 'text-green-600' : 'text-red-600'}>
                    {test.message}
                  </p>
                  {test.data && (
                    <p className="text-xs text-gray-500 mt-1">{test.data}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Instructions */}
        <div className="p-4 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-sm mb-2">Cara Verifikasi Real-Time:</h4>
          <ul className="text-xs text-gray-600 space-y-1">
            <li>• <strong>Indikator Online</strong>: Badge hijau "Online" menunjukkan koneksi aktif</li>
            <li>• <strong>Countdown Timer</strong>: "Update dalam Xs" menunjukkan waktu update berikutnya</li>
            <li>• <strong>Harga Berubah</strong>: Angka harga akan berubah setiap 30 detik</li>
            <li>• <strong>Timestamp</strong>: "Terakhir: XX:XX:XX" menunjukkan waktu update terakhir</li>
            <li>• <strong>Console Log</strong>: Buka Developer Tools untuk lihat log update</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
