"use client"

import React from 'react'

interface WebsiteLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl'
  showText?: boolean
  className?: string
}

export default function WebsiteLogo({ 
  size = 'md', 
  showText = true, 
  className = '' 
}: WebsiteLogoProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6', 
    lg: 'w-8 h-8',
    xl: 'w-12 h-12'
  }

  const textSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base', 
    xl: 'text-xl'
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {/* Bouncing Ball */}
      <div className={`${sizeClasses[size]} bg-gradient-to-br from-blue-400 to-purple-500 rounded-full animate-bounce shadow-lg`}></div>
      
      {/* BluBlub Text */}
      {showText && (
        <div className="flex items-center">
          <span 
            className={`${textSizeClasses[size]} font-extrabold`} 
            style={{ color: '#2dd4bf' }}
          >
            B
          </span>
          <span className={`${textSizeClasses[size]} font-extrabold text-gray-800 dark:text-white`}>
            lubBlub
          </span>
        </div>
      )}
    </div>
  )
}
