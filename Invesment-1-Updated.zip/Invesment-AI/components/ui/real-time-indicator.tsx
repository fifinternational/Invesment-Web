"use client"

import { useState, useEffect } from 'react'
import { Badge } from "@/components/ui/badge"
import { RefreshCw, Wifi, WifiOff, Clock } from 'lucide-react'

interface RealTimeIndicatorProps {
  isUpdating?: boolean
  lastUpdate?: Date | null
  updateInterval?: number // in seconds
  dataSource?: string
}

export function RealTimeIndicator({ 
  isUpdating = false, 
  lastUpdate = null, 
  updateInterval = 30,
  dataSource = "Yahoo Finance"
}: RealTimeIndicatorProps) {
  const [secondsUntilNext, setSecondsUntilNext] = useState(updateInterval)
  const [isConnected, setIsConnected] = useState(true)

  // Countdown timer for next update
  useEffect(() => {
    const interval = setInterval(() => {
      if (lastUpdate) {
        const timeSinceUpdate = Math.floor((Date.now() - lastUpdate.getTime()) / 1000)
        const remaining = Math.max(0, updateInterval - (timeSinceUpdate % updateInterval))
        setSecondsUntilNext(remaining)
        
        // Check if we're getting updates (connection status)
        setIsConnected(timeSinceUpdate < updateInterval * 2)
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [lastUpdate, updateInterval])

  const formatLastUpdate = (date: Date | null) => {
    if (!date) return 'Belum ada update'
    
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffSeconds = Math.floor(diffMs / 1000)
    const diffMinutes = Math.floor(diffSeconds / 60)
    
    if (diffSeconds < 60) {
      return `${diffSeconds} detik lalu`
    } else if (diffMinutes < 60) {
      return `${diffMinutes} menit lalu`
    } else {
      return date.toLocaleTimeString('id-ID')
    }
  }

  return (
    <div className="flex items-center gap-3 text-sm">
      {/* Connection Status */}
      <Badge 
        variant={isConnected ? "default" : "destructive"}
        className="flex items-center gap-1"
      >
        {isConnected ? (
          <Wifi className="h-3 w-3" />
        ) : (
          <WifiOff className="h-3 w-3" />
        )}
        {isConnected ? 'Online' : 'Offline'}
      </Badge>

      {/* Update Status */}
      <div className="flex items-center gap-1 text-gray-600">
        {isUpdating ? (
          <>
            <RefreshCw className="h-3 w-3 animate-spin" />
            <span>Updating...</span>
          </>
        ) : (
          <>
            <Clock className="h-3 w-3" />
            <span>Update dalam {secondsUntilNext}s</span>
          </>
        )}
      </div>

      {/* Data Source */}
      <Badge variant="outline" className="text-xs">
        {dataSource}
      </Badge>

      {/* Last Update Time */}
      <span className="text-gray-500 text-xs">
        Terakhir: {formatLastUpdate(lastUpdate)}
      </span>
    </div>
  )
}
