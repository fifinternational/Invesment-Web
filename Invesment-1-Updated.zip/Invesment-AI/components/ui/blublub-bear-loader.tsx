"use client"

import { cn } from "@/lib/utils"

interface BlubBlubBearLoaderProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export function BlubBlubBearLoader({ className, size = "md" }: BlubBlubBearLoaderProps) {
  const sizeClasses = {
    sm: "w-12 h-12",
    md: "w-16 h-16", 
    lg: "w-20 h-20"
  }

  return (
    <div className={cn("flex items-center justify-center", className)}>
      <div className={cn(
        "relative",
        sizeClasses[size]
      )}>
        {/* Rotating Bear Ball */}
        <div className="w-full h-full animate-spin" style={{animationDuration: '4s'}}>
          <svg 
            width="100%" 
            height="100%" 
            viewBox="0 0 100 100" 
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Bola Transparan */}
            <circle 
              cx="50" 
              cy="50" 
              r="48" 
              fill="url(#ballGradient)" 
              stroke="rgba(255,255,255,0.6)" 
              strokeWidth="2"
              style={{
                filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.1))'
              }}
            />
            
            {/* Gradient untuk bola */}
            <defs>
              <radialGradient id="ballGradient" cx="0.3" cy="0.3" r="0.8">
                <stop offset="0%" stopColor="rgba(255,255,255,0.8)"/>
                <stop offset="50%" stopColor="rgba(173,216,230,0.4)"/>
                <stop offset="100%" stopColor="rgba(135,206,235,0.6)"/>
              </radialGradient>
              <radialGradient id="highlight" cx="0.3" cy="0.3" r="0.4">
                <stop offset="0%" stopColor="rgba(255,255,255,0.9)"/>
                <stop offset="100%" stopColor="transparent"/>
              </radialGradient>
            </defs>
            
            {/* Highlight kaca */}
            <ellipse cx="35" cy="30" rx="8" ry="12" fill="url(#highlight)" opacity="0.6"/>
            
            {/* Beruang Kutub di dalam bola - Counter rotate */}
            <g transform="translate(50,50) scale(0.6) translate(-50,-50)">
              <g className="animate-spin" style={{animationDuration: '4s', animationDirection: 'reverse'}}>
                {/* Kepala */}
                <ellipse cx="50" cy="45" rx="20" ry="18" fill="#f8fafc" stroke="#e2e8f0" strokeWidth="0.8"/>
                
                {/* Kuping Kiri */}
                <ellipse cx="38" cy="32" rx="4" ry="6" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="0.3"/>
                <ellipse cx="38" cy="33" rx="2" ry="3" fill="#e2e8f0"/>
                
                {/* Kuping Kanan */}
                <ellipse cx="62" cy="32" rx="4" ry="6" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="0.3"/>
                <ellipse cx="62" cy="33" rx="2" ry="3" fill="#e2e8f0"/>
                
                {/* Mata Kiri */}
                <circle cx="44" cy="42" r="3" fill="#0f172a"/>
                <circle cx="44.5" cy="41.5" r="1" fill="#06b6d4"/>
                <circle cx="44.8" cy="41.2" r="0.5" fill="#ffffff"/>
                
                {/* Mata Kanan */}
                <circle cx="56" cy="42" r="3" fill="#0f172a"/>
                <circle cx="56.5" cy="41.5" r="1" fill="#06b6d4"/>
                <circle cx="56.8" cy="41.2" r="0.5" fill="#ffffff"/>
                
                {/* Hidung */}
                <ellipse cx="50" cy="47" rx="2" ry="1.5" fill="#1e293b"/>
                
                {/* Mulut */}
                <path d="M 46 52 Q 50 55 54 52" stroke="#1e293b" strokeWidth="1" fill="none"/>
                <ellipse cx="50" cy="54" rx="2" ry="1.5" fill="#dc2626"/>
                
                {/* Badan */}
                <ellipse cx="50" cy="68" rx="14" ry="12" fill="#f8fafc" stroke="#e2e8f0" strokeWidth="0.8"/>
                
                {/* Kaki */}
                <ellipse cx="43" cy="76" rx="3" ry="4" fill="#f1f5f9"/>
                <ellipse cx="57" cy="76" rx="3" ry="4" fill="#f1f5f9"/>
                
                {/* Telapak Kaki */}
                <ellipse cx="43" cy="78" rx="2" ry="1.5" fill="#64748b"/>
                <ellipse cx="57" cy="78" rx="2" ry="1.5" fill="#64748b"/>
              </g>
            </g>
          </svg>
        </div>
        
        {/* Shadow */}
        <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-8 h-2 bg-black/20 rounded-full blur-sm animate-pulse"></div>
      </div>
    </div>
  )
}

export default BlubBlubBearLoader
