"use client"

import { cn } from "@/lib/utils"

interface SpinningBearLoaderProps {
  className?: string
  size?: "sm" | "md" | "lg"
}

export function SpinningBearLoader({ className, size = "md" }: SpinningBearLoaderProps) {
  const sizeClasses = {
    sm: "w-12 h-12",
    md: "w-16 h-16", 
    lg: "w-20 h-20"
  }

  return (
    <div className={cn("flex items-center justify-center", className)}>
      <div className={cn(
        "relative",
        sizeClasses[size]
      )}>
        {/* Bouncing Bear Ball */}
        <div className="w-full h-full animate-bounce">
          <div className="w-full h-full rounded-full bg-gradient-to-br from-blue-400 to-blue-600 shadow-lg relative overflow-hidden animate-spin">
            {/* Bear face on the ball */}
            <div className="absolute inset-0 flex items-center justify-center">
              <svg
                viewBox="0 0 60 60"
                className="w-3/4 h-3/4"
                fill="white"
              >
                {/* Bear ears */}
                <circle cx="20" cy="18" r="6" className="fill-white" />
                <circle cx="40" cy="18" r="6" className="fill-white" />
                <circle cx="20" cy="18" r="3" className="fill-pink-300" />
                <circle cx="40" cy="18" r="3" className="fill-pink-300" />
                
                {/* Bear head */}
                <circle cx="30" cy="30" r="18" className="fill-white" />
                
                {/* Eyes */}
                <circle cx="25" cy="26" r="2.5" className="fill-black" />
                <circle cx="35" cy="26" r="2.5" className="fill-black" />
                <circle cx="25.5" cy="25.5" r="1" className="fill-white" />
                <circle cx="35.5" cy="25.5" r="1" className="fill-white" />
                
                {/* Nose */}
                <ellipse cx="30" cy="32" rx="1.5" ry="1" className="fill-black" />
                
                {/* Mouth */}
                <path 
                  d="M 27 35 Q 30 37 33 35" 
                  stroke="black" 
                  strokeWidth="1.2" 
                  fill="none"
                />
              </svg>
            </div>
            
            {/* Shine effect */}
            <div className="absolute top-2 left-2 w-4 h-4 bg-white/30 rounded-full blur-sm"></div>
            
            {/* Rotating sparkles */}
            <div className="absolute inset-0 animate-spin" style={{animationDuration: '3s'}}>
              <div className="absolute top-1 left-1/2 w-1 h-1 bg-yellow-300 rounded-full"></div>
              <div className="absolute top-1/4 right-1 w-1 h-1 bg-yellow-300 rounded-full"></div>
              <div className="absolute bottom-1/4 right-1 w-1 h-1 bg-yellow-300 rounded-full"></div>
              <div className="absolute bottom-1 left-1/2 w-1 h-1 bg-yellow-300 rounded-full"></div>
              <div className="absolute bottom-1/4 left-1 w-1 h-1 bg-yellow-300 rounded-full"></div>
              <div className="absolute top-1/4 left-1 w-1 h-1 bg-yellow-300 rounded-full"></div>
            </div>
          </div>
        </div>
        
        {/* Shadow */}
        <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-8 h-2 bg-black/20 rounded-full blur-sm animate-pulse"></div>
      </div>
    </div>
  )
}

export default SpinningBearLoader
