"use client"

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { 
  SidebarProvider, 
  Sidebar, 
  SidebarContent, 
  SidebarHeader, 
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarTrigger,
  SidebarInset,
  SidebarRail
} from "@/components/ui/sidebar"
import { 
  LayoutDashboard, 
  TrendingUp, 
  Newspaper, 
  Bot, 
  Heart, 
  Search, 
  User, 
  Settings, 
  LogOut, 
  Menu, 
  X, 
  Bell, 
  FileText, 
  Shield, 
  BarChart3,
  Activity,
  Languages,
  Sun,
  Moon,
  ChevronDown
} from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import WebsiteLogo from "@/components/ui/website-logo"
import BouncingBearBall from "@/components/auth/bouncing-bear-ball"
import { useLanguage } from "@/contexts/language-context"

interface DashboardLayoutProps {
  children: React.ReactNode
}


export function DashboardLayout({ children }: DashboardLayoutProps) {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  const { language, setLanguage, t } = useLanguage()
  const [user] = useState({
    name: "User Demo",
    email: "demo@example.com",
    avatar: "/placeholder-user.jpg"
  })

  useEffect(() => {
    setMounted(true)
  }, [])

  const handleLogout = () => {
    // Implement logout logic
    if (typeof window !== 'undefined') {
      window.location.href = '/login'
    }
  }

  if (!mounted) {
    return <div className="min-h-screen bg-background" />
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="h-16 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-6">
        {/* Left Side - Logo */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 p-2 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border border-gray-200 dark:border-gray-700 shadow-sm">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-400 via-purple-500 to-teal-400 rounded-full flex items-center justify-center shadow-xl ring-2 ring-white dark:ring-gray-800">
              <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-inner">
                <div className="w-2 h-2 bg-gradient-to-br from-gray-800 to-black rounded-full"></div>
              </div>
            </div>
            <div className="flex items-center logo-container">
              <span 
                className="text-xl font-black tracking-tight transition-all duration-300 logo-b"
                style={{ color: '#2dd4bf' }}
              >
                B
              </span>
              <span className="text-xl font-black text-gray-700 dark:text-gray-200 tracking-tight transition-all duration-300 logo-text">
                lublub
              </span>
              <style jsx global>{`
                .dark .logo-b {
                  filter: drop-shadow(0 0 15px rgba(45, 212, 191, 1)) 
                          drop-shadow(0 0 30px rgba(45, 212, 191, 0.8)) 
                          drop-shadow(0 0 45px rgba(45, 212, 191, 0.6));
                  text-shadow: 0 0 20px rgba(45, 212, 191, 0.9), 
                               0 0 40px rgba(45, 212, 191, 0.7),
                               0 0 60px rgba(45, 212, 191, 0.5);
                  color: #2dd4bf !important;
                }
                .dark .logo-text {
                  filter: drop-shadow(0 0 12px rgba(255, 255, 255, 0.8)) 
                          drop-shadow(0 0 24px rgba(255, 255, 255, 0.6)) 
                          drop-shadow(0 0 36px rgba(255, 255, 255, 0.4));
                  text-shadow: 0 0 15px rgba(255, 255, 255, 0.7),
                               0 0 30px rgba(255, 255, 255, 0.5),
                               0 0 45px rgba(255, 255, 255, 0.3);
                }
                .logo-b {
                  text-shadow: 0 2px 4px rgba(45, 212, 191, 0.3);
                }
                
                /* Animasi berkedip untuk efek neon */
                @keyframes neon-pulse {
                  0%, 100% { 
                    filter: drop-shadow(0 0 15px rgba(45, 212, 191, 1)) 
                            drop-shadow(0 0 30px rgba(45, 212, 191, 0.8)) 
                            drop-shadow(0 0 45px rgba(45, 212, 191, 0.6));
                  }
                  50% { 
                    filter: drop-shadow(0 0 20px rgba(45, 212, 191, 1)) 
                            drop-shadow(0 0 40px rgba(45, 212, 191, 0.9)) 
                            drop-shadow(0 0 60px rgba(45, 212, 191, 0.7));
                  }
                }
                
                @keyframes white-glow-pulse {
                  0%, 100% { 
                    filter: drop-shadow(0 0 12px rgba(255, 255, 255, 0.8)) 
                            drop-shadow(0 0 24px rgba(255, 255, 255, 0.6)) 
                            drop-shadow(0 0 36px rgba(255, 255, 255, 0.4));
                  }
                  50% { 
                    filter: drop-shadow(0 0 16px rgba(255, 255, 255, 0.9)) 
                            drop-shadow(0 0 32px rgba(255, 255, 255, 0.7)) 
                            drop-shadow(0 0 48px rgba(255, 255, 255, 0.5));
                  }
                }
                
                .dark .logo-b {
                  animation: neon-pulse 2s ease-in-out infinite;
                }
                
                .dark .logo-text {
                  animation: white-glow-pulse 2s ease-in-out infinite;
                }
              `}</style>
            </div>
            <div className="hidden sm:block">
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded-full">
                AI Platform
              </span>
            </div>
          </div>
        </div>
        
        {/* Right Side - User Controls */}
        <div className="flex items-center gap-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2">
                <Languages className="h-4 w-4" />
                <span className="hidden sm:inline">
                  {language === 'id-ID' ? '🇮🇩 ID' : '🇺🇸 EN'}
                </span>
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem 
                onClick={() => setLanguage('id-ID')}
                className={language === 'id-ID' ? 'bg-accent' : ''}
              >
                🇮🇩 Bahasa Indonesia
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => setLanguage('en-US')}
                className={language === 'en-US' ? 'bg-accent' : ''}
              >
                🇺🇸 English
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button variant="ghost" size="icon">
            <Bell className="h-4 w-4" />
          </Button>

          <div className="flex items-center gap-2">
            <Avatar className="h-8 w-8">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleLogout}
              className="h-8 w-8"
              title="Logout"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="container mx-auto p-6">
          {children}
        </div>
      </main>
    </div>
  )
}
