"use client"

import { createContext, useContext, useEffect, useState, ReactNode } from 'react'
import { createBrowserClient } from '@supabase/ssr'

interface DashboardData {
  aiRecommendations: any[]
  marketPerformance: any
  watchlist: any[]
  marketNews: any[]
  userPreferences: any
  searchHistory: any[]
}

interface DashboardContextType {
  data: DashboardData
  loading: boolean
  error: string | null
  refreshData: () => Promise<void>
  updatePreferences: (preferences: any) => Promise<void>
  addToWatchlist: (symbol: string, market: string) => Promise<void>
  removeFromWatchlist: (symbol: string, market: string) => Promise<void>
  saveChatMessage: (message: string, response: string) => Promise<void>
  saveSearch: (query: string, resultsCount: number, market: string) => Promise<void>
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined)

export function useDashboard() {
  const context = useContext(DashboardContext)
  if (!context) {
    throw new Error('useDashboard must be used within a DashboardProvider')
  }
  return context
}

interface DashboardProviderProps {
  children: ReactNode
  selectedMarket: 'IDX' | 'US'
  selectedTimeframe: 'daily' | 'weekly' | 'monthly'
}

export function DashboardProvider({ 
  children, 
  selectedMarket, 
  selectedTimeframe 
}: DashboardProviderProps) {
  const [data, setData] = useState<DashboardData>({
    aiRecommendations: [],
    marketPerformance: null,
    watchlist: [],
    marketNews: [],
    userPreferences: null,
    searchHistory: []
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Initialize Supabase client
  const supabase = createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )

  // Fetch all dashboard data
  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      setError(null)

      // Fetch AI recommendations
      const aiRecommendationsResponse = await fetch(
        `/api/dashboard?action=ai-recommendations&market=${selectedMarket}&timeframe=${selectedTimeframe}`
      )
      const aiRecommendationsResult = await aiRecommendationsResponse.json()

      // Fetch market performance
      const marketPerformanceResponse = await fetch(
        `/api/dashboard?action=market-performance&market=${selectedMarket}`
      )
      const marketPerformanceResult = await marketPerformanceResponse.json()

      // Fetch watchlist
      const watchlistResponse = await fetch('/api/dashboard?action=watchlist')
      const watchlistResult = await watchlistResponse.json()

      // Fetch market news
      const marketNewsResponse = await fetch(
        `/api/dashboard?action=market-news&market=${selectedMarket}`
      )
      const marketNewsResult = await marketNewsResponse.json()

      // Fetch user preferences
      const userPreferencesResponse = await fetch('/api/dashboard?action=user-preferences')
      const userPreferencesResult = await userPreferencesResponse.json()

      // Fetch search history
      const searchHistoryResponse = await fetch('/api/dashboard?action=search-history')
      const searchHistoryResult = await searchHistoryResponse.json()

      // Update state with all fetched data
      setData({
        aiRecommendations: aiRecommendationsResult.success ? aiRecommendationsResult.data : [],
        marketPerformance: marketPerformanceResult.success ? marketPerformanceResult.data : null,
        watchlist: watchlistResult.success ? watchlistResult.data : [],
        marketNews: marketNewsResult.success ? marketNewsResult.data : [],
        userPreferences: userPreferencesResult.success ? userPreferencesResult.data : null,
        searchHistory: searchHistoryResult.success ? searchHistoryResult.data : []
      })

    } catch (err: any) {
      console.error('Error fetching dashboard data:', err)
      setError(err.message || 'Failed to fetch dashboard data')
    } finally {
      setLoading(false)
    }
  }

  // Refresh data function
  const refreshData = async () => {
    await fetchDashboardData()
  }

  // Update user preferences
  const updatePreferences = async (preferences: any) => {
    try {
      const response = await fetch('/api/dashboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update-preferences',
          user_id: 'current-user', // Replace with actual user ID from auth
          preferences
        })
      })

      const result = await response.json()
      if (result.success) {
        setData(prev => ({
          ...prev,
          userPreferences: { ...prev.userPreferences, ...preferences }
        }))
      }
    } catch (err) {
      console.error('Error updating preferences:', err)
    }
  }

  // Add to watchlist
  const addToWatchlist = async (symbol: string, market: string) => {
    try {
      const response = await fetch('/api/dashboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'add-to-watchlist',
          user_id: 'current-user', // Replace with actual user ID from auth
          symbol,
          market
        })
      })

      const result = await response.json()
      if (result.success) {
        // Refresh watchlist data
        const watchlistResponse = await fetch('/api/dashboard?action=watchlist')
        const watchlistResult = await watchlistResponse.json()
        if (watchlistResult.success) {
          setData(prev => ({
            ...prev,
            watchlist: watchlistResult.data
          }))
        }
      }
    } catch (err) {
      console.error('Error adding to watchlist:', err)
    }
  }

  // Remove from watchlist
  const removeFromWatchlist = async (symbol: string, market: string) => {
    try {
      const response = await fetch('/api/dashboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'remove-from-watchlist',
          user_id: 'current-user', // Replace with actual user ID from auth
          symbol,
          market
        })
      })

      const result = await response.json()
      if (result.success) {
        // Update watchlist in state
        setData(prev => ({
          ...prev,
          watchlist: prev.watchlist.filter(item => 
            !(item.symbol === symbol && item.market === market)
          )
        }))
      }
    } catch (err) {
      console.error('Error removing from watchlist:', err)
    }
  }

  // Save chat message
  const saveChatMessage = async (message: string, response: string) => {
    try {
      await fetch('/api/dashboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'save-chat',
          user_id: 'current-user', // Replace with actual user ID from auth
          message,
          response,
          session_id: crypto.randomUUID()
        })
      })
    } catch (err) {
      console.error('Error saving chat message:', err)
    }
  }

  // Save search query
  const saveSearch = async (query: string, resultsCount: number, market: string) => {
    try {
      const response = await fetch('/api/dashboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'save-search',
          user_id: 'current-user', // Replace with actual user ID from auth
          query,
          results_count: resultsCount,
          market
        })
      })

      const result = await response.json()
      if (result.success) {
        // Update search history in state
        setData(prev => ({
          ...prev,
          searchHistory: [result.data, ...prev.searchHistory.slice(0, 9)] // Keep last 10 searches
        }))
      }
    } catch (err) {
      console.error('Error saving search:', err)
    }
  }

  // Set up polling-based real-time updates (alternative to Supabase real-time)
  useEffect(() => {
    // Polling interval for real-time updates every 30 seconds
    const pollingInterval = setInterval(async () => {
      try {
        // Fetch latest stock prices from Yahoo Finance
        const stockSymbols = data.watchlist.map(item => item.symbol).slice(0, 5)
        if (stockSymbols.length > 0) {
          const response = await fetch(`/api/free-market-data?action=multiple-quotes&symbols=${stockSymbols.join(',')}`)
          const result = await response.json()
          
          if (result.success) {
            // Update watchlist with latest prices
            setData(prev => ({
              ...prev,
              watchlist: prev.watchlist.map(item => {
                const updatedStock = result.data.find((stock: any) => stock.symbol === item.symbol)
                return updatedStock ? { ...item, ...updatedStock } : item
              })
            }))
          }
        }

        // Check for new market news every 2 minutes
        if (Date.now() % (2 * 60 * 1000) < 30000) {
          const newsResponse = await fetch(`/api/free-market-data?action=market-news&market=${selectedMarket}`)
          const newsResult = await newsResponse.json()
          
          if (newsResult.success) {
            setData(prev => ({
              ...prev,
              marketNews: newsResult.data
            }))
          }
        }

      } catch (error) {
        console.error('Polling update error:', error)
      }
    }, 30000) // Update every 30 seconds

    // Cleanup interval on unmount
    return () => clearInterval(pollingInterval)
  }, [selectedMarket, selectedTimeframe, data.watchlist])

  // Fetch data on mount and when market/timeframe changes
  useEffect(() => {
    fetchDashboardData()
  }, [selectedMarket, selectedTimeframe])

  // Auto-refresh data every 5 minutes
  useEffect(() => {
    const interval = setInterval(() => {
      fetchDashboardData()
    }, 5 * 60 * 1000) // 5 minutes

    return () => clearInterval(interval)
  }, [selectedMarket, selectedTimeframe])

  const contextValue: DashboardContextType = {
    data,
    loading,
    error,
    refreshData,
    updatePreferences,
    addToWatchlist,
    removeFromWatchlist,
    saveChatMessage,
    saveSearch
  }

  return (
    <DashboardContext.Provider value={contextValue}>
      {children}
    </DashboardContext.Provider>
  )
}
