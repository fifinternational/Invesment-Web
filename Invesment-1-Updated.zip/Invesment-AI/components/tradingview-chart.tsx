"use client"

import { useEffect, useRef } from "react"

interface TradingViewChartProps {
  symbol: string
  width?: number
  height?: number
}

declare global {
  interface Window {
    TradingView: any
  }
}

export default function TradingViewChart({ symbol, width = 800, height = 400 }: TradingViewChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Load TradingView widget script
    const script = document.createElement("script")
    script.src = "https://s3.tradingview.com/tv.js"
    script.async = true
    script.onload = () => {
      if (window.TradingView && chartContainerRef.current) {
        new window.TradingView.widget({
          autosize: true,
          symbol: symbol,
          interval: "D",
          timezone: "Asia/Jakarta",
          theme: "light",
          style: "1",
          locale: "en",
          toolbar_bg: "#f1f3f6",
          enable_publishing: false,
          allow_symbol_change: true,
          container_id: chartContainerRef.current.id,
          width: width,
          height: height,
          studies: [
            "RSI@tv-basicstudies",
            "MACD@tv-basicstudies",
            "BB@tv-basicstudies"
          ],
          show_popup_button: true,
          popup_width: "1000",
          popup_height: "650",
        })
      }
    }
    document.head.appendChild(script)

    return () => {
      // Cleanup script when component unmounts
      const existingScript = document.querySelector('script[src="https://s3.tradingview.com/tv.js"]')
      if (existingScript) {
        document.head.removeChild(existingScript)
      }
    }
  }, [symbol, width, height])

  return (
    <div className="w-full h-full">
      <div 
        id={`tradingview-chart-${symbol}`}
        ref={chartContainerRef}
        className="w-full h-full"
        style={{ minHeight: `${height}px` }}
      />
    </div>
  )
}

