"use client"

import { useState } from "react"
import { Send, Bot, User, TrendingUp, BarChart3, DollarSign, Globe } from "lucide-react"
import { useSubscription } from "@/contexts/subscription-context"
import { useLanguage } from "@/contexts/language-context"

interface Message {
  id: string
  type: 'user' | 'ai'
  content: string
  timestamp: Date
}

interface StockAnalysis {
  symbol: string
  price: string
  change: number
  marketCap: string
  pe: number
  dividend: number
  shariahCompliant: boolean
  macroFactors: string[]
  technicalAnalysis: string
  fundamentalAnalysis: string
  risks: string[]
  opportunities: string[]
}

export default function AIChatbot({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { subscriptionTier } = useSubscription()
  const { t, language } = useLanguage()
  
  const getWelcomeMessage = () => {
    if (language === 'id-ID') {
      return 'Halo! Saya analis investasi AI Anda. Tanya saya tentang saham yang patuh Syariah untuk analisis mendalam termasuk faktor makroekonomi, indikator teknis, dan kondisi pasar.'
    }
    return 'Hello! I\'m your AI investment analyst. Ask me about any Shariah-compliant stock for detailed analysis including macroeconomic factors, technical indicators, and market conditions.'
  }

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: getWelcomeMessage(),
      timestamp: new Date('2024-01-01T00:00:00Z')
    }
  ])
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)

  const stockDatabase: Record<string, StockAnalysis> = {
    'ASII': {
      symbol: 'ASII',
      price: 'Rp 6,250',
      change: 2.04,
      marketCap: 'Rp 125.5T',
      pe: 12.5,
      dividend: 4.2,
      shariahCompliant: true,
      macroFactors: [
        'Indonesia GDP growth at 5.2% supports automotive demand',
        'Bank Indonesia interest rate at 6% affects financing costs',
        'Rupiah stability impacts import costs for components',
        'Government infrastructure spending boosts heavy equipment sales'
      ],
      technicalAnalysis: 'Stock shows bullish momentum with RSI at 65, breaking above 50-day MA. Volume increased 25% indicating strong buying interest. Support at Rp 6,000, resistance at Rp 6,500.',
      fundamentalAnalysis: 'Strong market position in automotive and heavy equipment. Revenue growth of 15% YoY driven by economic recovery. Debt-to-equity ratio of 0.45 shows healthy balance sheet. ROE of 18% indicates efficient capital utilization.',
      risks: [
        'Rising raw material costs affecting margins',
        'Competition from Chinese automotive brands',
        'Economic slowdown reducing consumer purchasing power',
        'Supply chain disruptions from global events'
      ],
      opportunities: [
        'Electric vehicle transition creating new market segments',
        'Government green energy initiatives',
        'Export opportunities to ASEAN markets',
        'Digital transformation in automotive services'
      ]
    },
    'TLKM': {
      symbol: 'TLKM',
      price: 'Rp 3,850',
      change: 1.99,
      marketCap: 'Rp 365.8T',
      pe: 15.2,
      dividend: 5.8,
      shariahCompliant: true,
      macroFactors: [
        'Digital transformation accelerating post-pandemic',
        'Government digitalization initiatives supporting growth',
        '5G rollout creating new revenue streams',
        'Inflation at 3.2% affecting operational costs'
      ],
      technicalAnalysis: 'Consolidating in range Rp 3,700-4,000. MACD showing bullish crossover. Trading volume above average suggests institutional interest. Key resistance at Rp 4,100.',
      fundamentalAnalysis: 'Dominant position in Indonesian telecommunications. Consistent dividend payments with 5.8% yield. Revenue diversification into digital services reducing traditional voice dependency. EBITDA margin of 52% shows operational efficiency.',
      risks: [
        'Intense competition in mobile data pricing',
        'Regulatory changes in telecommunications sector',
        'High capital expenditure for 5G infrastructure',
        'Currency fluctuation affecting foreign debt'
      ],
      opportunities: [
        'Cloud services and data center expansion',
        'IoT and smart city projects',
        'Financial technology partnerships',
        'Submarine cable investments for international connectivity'
      ]
    },
    'AAPL': {
      symbol: 'AAPL',
      price: '$214.55',
      change: 0.64,
      marketCap: '$3.2T',
      pe: 28.5,
      dividend: 0.5,
      shariahCompliant: true,
      macroFactors: [
        'US Federal Reserve rate at 5.25% affecting tech valuations',
        'China-US trade relations impacting supply chain',
        'Global smartphone market showing maturity',
        'Strong US consumer spending supporting premium products'
      ],
      technicalAnalysis: 'Trading near all-time highs with strong momentum. RSI at 72 indicating overbought conditions. Support at $200, next resistance at $225. Options flow shows bullish sentiment.',
      fundamentalAnalysis: 'Ecosystem lock-in drives recurring revenue through services. Gross margin of 45% reflects pricing power. Cash position of $165B provides strategic flexibility. Services revenue growing 15% annually.',
      risks: [
        'iPhone sales dependency on upgrade cycles',
        'Regulatory scrutiny on App Store practices',
        'Competition in wearables and services',
        'Geopolitical tensions affecting China operations'
      ],
      opportunities: [
        'Vision Pro and spatial computing market',
        'AI integration across product lineup',
        'Health technology and medical devices',
        'Autonomous vehicle technology development'
      ]
    }
  }

  const generateAIResponse = (userMessage: string): string => {
    const upperMessage = userMessage.toUpperCase()
    const isIndonesian = language === 'id-ID'
    
    // Check for stock analysis requests
    for (const [symbol, data] of Object.entries(stockDatabase)) {
      if (upperMessage.includes(symbol)) {
        if (isIndonesian) {
          return `📊 **Analisis Komprehensif: ${data.symbol}**

**Harga Saat Ini:** ${data.price} (${data.change > 0 ? '+' : ''}${data.change}%)
**Kapitalisasi Pasar:** ${data.marketCap} | **Rasio P/E:** ${data.pe} | **Yield Dividen:** ${data.dividend}%
**Status Syariah:** ✅ Patuh

**🌍 Faktor Makroekonomi:**
${data.macroFactors.map(factor => `• ${factor}`).join('\n')}

**📈 Analisis Teknikal:**
${data.technicalAnalysis}

**💼 Analisis Fundamental:**
${data.fundamentalAnalysis}

**⚠️ Risiko Utama:**
${data.risks.map(risk => `• ${risk}`).join('\n')}

**🚀 Peluang Pertumbuhan:**
${data.opportunities.map(opp => `• ${opp}`).join('\n')}

**Rekomendasi Investasi:** Berdasarkan kondisi pasar saat ini dan kekuatan fundamental, saham ini menunjukkan momentum ${data.change > 1 ? 'kuat' : data.change > 0 ? 'moderat' : 'lemah'}. Pertimbangkan toleransi risiko dan alokasi portofolio Anda sebelum berinvestasi.`
        }
        return `📊 **Comprehensive Analysis: ${data.symbol}**

**Current Price:** ${data.price} (${data.change > 0 ? '+' : ''}${data.change}%)
**Market Cap:** ${data.marketCap} | **P/E Ratio:** ${data.pe} | **Dividend Yield:** ${data.dividend}%
**Shariah Status:** ✅ Compliant

**🌍 Macroeconomic Factors:**
${data.macroFactors.map(factor => `• ${factor}`).join('\n')}

**📈 Technical Analysis:**
${data.technicalAnalysis}

**💼 Fundamental Analysis:**
${data.fundamentalAnalysis}

**⚠️ Key Risks:**
${data.risks.map(risk => `• ${risk}`).join('\n')}

**🚀 Growth Opportunities:**
${data.opportunities.map(opp => `• ${opp}`).join('\n')}

**Investment Recommendation:** Based on current market conditions and fundamental strength, this stock shows ${data.change > 1 ? 'strong' : data.change > 0 ? 'moderate' : 'weak'} momentum. Consider your risk tolerance and portfolio allocation before investing.`
      }
    }

    // General market questions
    if (upperMessage.includes('MARKET') || upperMessage.includes('PASAR') || upperMessage.includes('ECONOMY') || upperMessage.includes('EKONOMI')) {
      if (isIndonesian) {
        return `🌐 **Ringkasan Pasar Saat Ini:**

**Pasar Indonesia:**
• IDX Composite menunjukkan ketahanan di level 5,200+
• Sektor perbankan diuntungkan dari kenaikan suku bunga
• Barang konsumen mempertahankan kinerja stabil
• Belanja infrastruktur mendukung saham konstruksi

**Pasar AS:**
• S&P 500 mendekati rekor tertinggi meski ada kekhawatiran suku bunga
• Sektor teknologi menunjukkan sinyal campuran
• Sektor energi volatil karena faktor geopolitik
• Kesehatan mempertahankan karakteristik defensif

**Faktor Kunci yang Perlu Diperhatikan:**
• Kebijakan moneter bank sentral
• Tren inflasi dan harga komoditas
• Perkembangan geopolitik
• Pertumbuhan laba perusahaan

Apakah Anda ingin analisis saham atau sektor tertentu?`
      }
      return `🌐 **Current Market Overview:**

**Indonesia Market:**
• IDX Composite showing resilience with 5,200+ levels
• Banking sector benefiting from rising interest rates
• Consumer goods maintaining stable performance
• Infrastructure spending supporting construction stocks

**US Market:**
• S&P 500 near historical highs despite rate concerns
• Technology sector showing mixed signals
• Energy sector volatile due to geopolitical factors
• Healthcare maintaining defensive characteristics

**Key Factors to Watch:**
• Central bank monetary policies
• Inflation trends and commodity prices
• Geopolitical developments
• Corporate earnings growth

Would you like analysis on any specific stock or sector?`
    }

    if (upperMessage.includes('SHARIAH') || upperMessage.includes('SYARIAH') || upperMessage.includes('HALAL')) {
      if (isIndonesian) {
        return `☪️ **Panduan Investasi Syariah:**

**Sektor yang Patuh:**
• Teknologi (non-gaming, non-konten dewasa)
• Kesehatan dan farmasi
• Barang konsumen (produk halal)
• Infrastruktur dan utilitas
• Energi terbarukan

**Kriteria Penyaringan:**
• Rasio utang terhadap kapitalisasi pasar < 33%
• Kas dan sekuritas berbunga < 33%
• Pendapatan non-halal < 5%

**Pilihan Patuh Syariah yang Tersedia:**
• Indonesia: ASII, TLKM, UNVR, ICBP, KLBF
• AS: AAPL, MSFT, JNJ, PG, KO
• ETF: HLAL, ISWD untuk eksposur terdiversifikasi

Saham mana yang ingin Anda analisis untuk kepatuhan Syariah?`
      }
      return `☪️ **Shariah Investment Guidelines:**

**Compliant Sectors:**
• Technology (non-gaming, non-adult content)
• Healthcare and pharmaceuticals
• Consumer goods (halal products)
• Infrastructure and utilities
• Renewable energy

**Screening Criteria:**
• Debt-to-market cap ratio < 33%
• Cash and interest-bearing securities < 33%
• Non-permissible income < 5%

**Available Shariah-Compliant Options:**
• Indonesia: ASII, TLKM, UNVR, ICBP, KLBF
• US: AAPL, MSFT, JNJ, PG, KO
• ETFs: HLAL, ISWD for diversified exposure

Which specific stock would you like me to analyze for Shariah compliance?`
    }

    if (isIndonesian) {
      return `Saya di sini untuk memberikan analisis investasi mendalam! Tanya saya tentang:

📊 **Analisis Saham** - "Analisis ASII" atau "Ceritakan tentang Apple"
🌍 **Kondisi Pasar** - "Bagaimana pasar hari ini?"
☪️ **Kepatuhan Syariah** - "Apakah saham ini halal?"
📈 **Analisis Teknikal** - "Pola chart untuk TLKM"
💰 **Analisis Fundamental** - "Kesehatan keuangan Microsoft"

Saya dapat memberikan analisis komprehensif termasuk faktor makroekonomi, indikator teknis, risiko, dan peluang untuk saham yang patuh Syariah.`
    }

    return `I'm here to provide detailed investment analysis! Ask me about:

📊 **Stock Analysis** - "Analyze ASII" or "Tell me about Apple"
🌍 **Market Conditions** - "How's the market today?"
☪️ **Shariah Compliance** - "Is this stock halal?"
📈 **Technical Analysis** - "Chart patterns for TLKM"
💰 **Fundamental Analysis** - "Financial health of Microsoft"

I can provide comprehensive analysis including macroeconomic factors, technical indicators, risks, and opportunities for any Shariah-compliant stock.`
  }

  const handleSend = async () => {
    if (!input.trim()) return

    const userMessage: Message = {
      id: `user-${messages.length + 1}`,
      type: 'user',
      content: input,
      timestamp: new Date()
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsTyping(true)

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse: Message = {
        id: `ai-${messages.length + 2}`,
        type: 'ai',
        content: generateAIResponse(input),
        timestamp: new Date()
      }
      setMessages(prev => [...prev, aiResponse])
      setIsTyping(false)
    }, 1500)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-lg border border-border w-full max-w-4xl h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="bg-primary/20 p-2 rounded-full">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold">{t("ai_analyst_title")}</h3>
              <p className="text-xs text-muted-foreground">{t("ai_analyst_subtitle")}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.type === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-foreground'
                }`}
              >
                <div className="flex items-start space-x-2">
                  {message.type === 'ai' && (
                    <Bot className="h-4 w-4 mt-1 text-primary flex-shrink-0" />
                  )}
                  {message.type === 'user' && (
                    <User className="h-4 w-4 mt-1 text-primary-foreground flex-shrink-0" />
                  )}
                  <div className="text-sm whitespace-pre-line">{message.content}</div>
                </div>
                <div className="text-xs opacity-70 mt-2">
                  {message.timestamp.toLocaleTimeString()}
                </div>
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-muted text-foreground rounded-lg p-3 max-w-[80%]">
                <div className="flex items-center space-x-2">
                  <Bot className="h-4 w-4 text-primary" />
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <div className="p-4 border-t border-border">
          <div className="flex space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder={t("chatbot_placeholder")}
              className="flex-1 px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim()}
              className="bg-primary text-primary-foreground px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
          <div className="flex items-center justify-center space-x-4 mt-3 text-xs text-muted-foreground">
            <div className="flex items-center space-x-1">
              <TrendingUp className="h-3 w-3" />
              <span>{t("technical_analysis")}</span>
            </div>
            <div className="flex items-center space-x-1">
              <BarChart3 className="h-3 w-3" />
              <span>{t("fundamental_data")}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Globe className="h-3 w-3" />
              <span>{t("macro_factors")}</span>
            </div>
            <div className="flex items-center space-x-1">
              <DollarSign className="h-3 w-3" />
              <span>{t("risk_assessment")}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
