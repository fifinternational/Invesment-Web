'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'

interface MidtransButtonProps {
  amount: number
  orderId: string
  customerDetails: {
    first_name: string
    last_name: string
    email: string
    phone: string
  }
  onSuccess: () => void
}

declare global {
  interface Window {
    snap: any
  }
}

export default function MidtransButton({
  amount,
  orderId,
  customerDetails,
  onSuccess
}: MidtransButtonProps) {
  const [loading, setLoading] = useState(false)

  const handlePayment = async () => {
    setLoading(true)
    
    try {
      const response = await fetch('/api/midtrans/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          orderId,
          amount,
          customerDetails
        })
      })

      const data = await response.json()
      
      if (data.token) {
        // Load Midtrans Snap
        const script = document.createElement('script')
        script.src = process.env.MIDTRANS_IS_PRODUCTION === 'true' 
          ? 'https://app.midtrans.com/snap/snap.js'
          : 'https://app.sandbox.midtrans.com/snap/snap.js'
        script.setAttribute('data-client-key', process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY!)
        document.head.appendChild(script)

        script.onload = () => {
          window.snap.pay(data.token, {
            onSuccess: (result: any) => {
              toast.success('Pembayaran berhasil!')
              onSuccess()
            },
            onPending: (result: any) => {
              toast.info('Pembayaran pending, silakan selesaikan pembayaran')
            },
            onError: (result: any) => {
              toast.error('Pembayaran gagal')
            },
            onClose: () => {
              toast.info('Pembayaran dibatalkan')
            }
          })
        }
      }
    } catch (error) {
      toast.error('Gagal memproses pembayaran')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Button 
      onClick={handlePayment} 
      disabled={loading}
      className="w-full bg-blue-600 hover:bg-blue-700"
    >
      {loading ? 'Memproses...' : 'Bayar dengan Midtrans'}
    </Button>
  )
}
