"use client"

import { useEffect, useRef, useState } from "react"
import { toast } from "sonner"

type PayPalButtonsType = {
  render: (selector: string | HTMLElement) => void
}

declare global {
  interface Window {
    paypal?: {
      Buttons: (options: any) => PayPalButtonsType
    }
  }
}

type PayPalButtonProps = {
  amount: string
  currency?: string
  onApproved: () => void
}

export function PayPalButton({ amount, currency = "USD", onApproved }: PayPalButtonProps) {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    const clientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID
    if (!clientId) {
      toast.error("Missing PayPal client id. Set NEXT_PUBLIC_PAYPAL_CLIENT_ID.")
      return
    }

    if (window.paypal) {
      setReady(true)
      return
    }

    const script = document.createElement("script")
    script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=${currency}`
    script.async = true
    script.onload = () => setReady(true)
    script.onerror = () => toast.error("Failed to load PayPal SDK")
    document.body.appendChild(script)
  }, [currency])

  useEffect(() => {
    if (!ready || !window.paypal || !containerRef.current) return

    try {
      window.paypal
        .Buttons({
          style: { layout: "vertical", shape: "rect", label: "paypal" },
          createOrder: (_data: any, actions: any) => {
            return actions.order.create({
              purchase_units: [
                {
                  amount: { value: amount, currency_code: currency },
                },
              ],
            })
          },
          onApprove: async (_data: any, actions: any) => {
            try {
              await actions.order.capture()
              onApproved()
            } catch (e) {
              toast.error("Payment capture failed")
            }
          },
          onError: () => toast.error("PayPal error. Please try again."),
          onCancel: () => toast("Payment cancelled"),
        })
        .render(containerRef.current)
    } catch (e) {
      toast.error("Failed to initialize PayPal Buttons")
    }
  }, [ready, amount, currency, onApproved])

  return <div ref={containerRef} />
}

export default PayPalButton




