import { MoreVertical } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/contexts/language-context"
import { useCurrency } from "@/contexts/currency-context"

type Region = "ID" | "US"

export default function ExploreMarket({ region = "ID" }: { region?: Region }) {
  const { t } = useLanguage()
  const { format, currency } = useCurrency()
  const products = [
    {
      name: "IDX Sharia ETF (XSSI)",
      symbol: "XSSI",
      logo: "https://logo.clearbit.com/idx.co.id",
      iconColor: "bg-emerald-600",
      buyPrice: "Rp 6,245",
      sellPrice: "Rp 6,260",
      lastPrice: "Rp 6,255",
      lowestPrice: "Rp 6,110",
      highestPrice: "Rp 6,320",
    },
    {
      name: "S&P 500 Shariah (SP50SH)",
      symbol: "SP50SH",
      logo: "https://logo.clearbit.com/spglobal.com",
      iconColor: "bg-blue-600",
      buyPrice: "$2,145.20",
      sellPrice: "$2,147.10",
      lastPrice: "$2,146.30",
      lowestPrice: "$2,110.00",
      highestPrice: "$2,165.40",
    },
    {
      name: "iShares MSCI World Islamic (ISWD)",
      symbol: "ISWD",
      logo: "https://logo.clearbit.com/ishares.com",
      iconColor: "bg-purple-600",
      buyPrice: "$78.40",
      sellPrice: "$78.55",
      lastPrice: "$78.50",
      lowestPrice: "$77.10",
      highestPrice: "$79.25",
    },
    {
      name: "ASII (Astra International)",
      symbol: "ASII",
      logo: "https://logo.clearbit.com/astra.co.id",
      iconColor: "bg-amber-600",
      buyPrice: "Rp 6,230",
      sellPrice: "Rp 6,270",
      lastPrice: "Rp 6,250",
      lowestPrice: "Rp 6,120",
      highestPrice: "Rp 6,310",
    },
    {
      name: "TLKM (Telkom Indonesia)",
      symbol: "TLKM",
      logo: "https://logo.clearbit.com/telkom.co.id",
      iconColor: "bg-red-600",
      buyPrice: "Rp 3,835",
      sellPrice: "Rp 3,865",
      lastPrice: "Rp 3,850",
      lowestPrice: "Rp 3,780",
      highestPrice: "Rp 3,900",
    },
    {
      name: "UNVR (Unilever Indonesia)",
      symbol: "UNVR",
      logo: "https://logo.clearbit.com/unilever.co.id",
      iconColor: "bg-blue-500",
      buyPrice: "Rp 2,450",
      sellPrice: "Rp 2,470",
      lastPrice: "Rp 2,460",
      lowestPrice: "Rp 2,380",
      highestPrice: "Rp 2,520",
    },
    {
      name: "AAPL (Apple Inc)",
      symbol: "AAPL",
      logo: "https://logo.clearbit.com/apple.com",
      iconColor: "bg-gray-800",
      buyPrice: "$175.20",
      sellPrice: "$175.45",
      lastPrice: "$175.32",
      lowestPrice: "$172.10",
      highestPrice: "$178.90",
    },
    {
      name: "MSFT (Microsoft Corp)",
      symbol: "MSFT",
      logo: "https://logo.clearbit.com/microsoft.com",
      iconColor: "bg-blue-600",
      buyPrice: "$415.80",
      sellPrice: "$416.20",
      lastPrice: "$416.00",
      lowestPrice: "$410.50",
      highestPrice: "$420.30",
    },
  ]

  // Only include Shariah-compliant products; exclude banking, alcohol, tobacco, etc. (dataset curated)
  const filtered = products.filter((p) => (region === "ID" ? ["XSSI", "ASII", "TLKM", "UNVR"].includes(p.symbol) : ["AAPL", "MSFT", "SP50SH", "ISWD"].includes(p.symbol)))

  return (
    <div className="bg-card rounded-lg border border-border p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Explore Shariah Market · {region === "ID" ? "Indonesia" : "US"}</h2>
        <button>
          <MoreVertical className="h-5 w-5 text-muted-foreground" />
        </button>
      </div>

      <div className="overflow-x-auto -mx-4 px-4">
        <div className="min-w-[800px]">
          <table className="w-full">
            <thead>
              <tr className="text-xs text-muted-foreground border-b border-border">
                <th className="pb-2 text-left">{t("col_product_name")}</th>
                <th className="pb-2 text-left">{t("col_buy_price")}</th>
                <th className="pb-2 text-left">{t("col_sell_price")}</th>
                <th className="pb-2 text-left">{t("col_last_price")}</th>
                <th className="pb-2 text-left">{t("col_lowest_price")}</th>
                <th className="pb-2 text-left">{t("col_highest_price")}</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((product, index) => (
                <tr key={index} className="border-b border-border last:border-0">
                  <td className="py-3">
                    <div className="flex items-center">
                      <div className="rounded-full h-6 w-6 flex items-center justify-center mr-2 overflow-hidden">
                        <img 
                          src={product.logo} 
                          alt={product.symbol}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            const fallback = target.nextElementSibling as HTMLElement;
                            if (fallback) fallback.style.display = 'flex';
                          }}
                        />
                        <div className={`${product.iconColor} rounded-full h-6 w-6 flex items-center justify-center`} style={{display: 'none'}}>
                          <span className="text-white text-xs font-bold">{product.symbol.slice(0,2)}</span>
                        </div>
                      </div>
                      <Link
                        href={`/research?symbol=${encodeURIComponent(product.symbol)}&region=${region}`}
                        className="font-medium text-sm hover:underline"
                      >
                        {product.name}
                      </Link>
                    </div>
                  </td>
                  <td className="py-3 text-sm">{format(Number(String(product.buyPrice).replace(/[^0-9.]/g, "")))}</td>
                  <td className="py-3 text-sm">{format(Number(String(product.sellPrice).replace(/[^0-9.]/g, "")))}</td>
                  <td className="py-3 text-sm">{format(Number(String(product.lastPrice).replace(/[^0-9.]/g, "")))}</td>
                  <td className="py-3 text-sm">{format(Number(String(product.lowestPrice).replace(/[^0-9.]/g, "")))}</td>
                  <td className="py-3 text-sm">{format(Number(String(product.highestPrice).replace(/[^0-9.]/g, "")))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
