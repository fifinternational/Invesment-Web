import { MoreVertical } from "lucide-react"

export default function MarketTrades() {
  const marketTradesData = [
    {
      price: "Rp 9,850",
      size: "1,200 Lot",
      time: "10:34:50 AM",
    },
    {
      price: "Rp 6,250",
      size: "850 Lot",
      time: "10:34:51 AM",
    },
    {
      price: "Rp 3,850",
      size: "430 Lot",
      time: "10:34:55 AM",
    },
    {
      price: "$2,146.30",
      size: "5,200 Shrs",
      time: "10:34:56 AM",
    },
    {
      price: "$78.50",
      size: "2,300 Shrs",
      time: "10:34:58 AM",
    },
    {
      price: "Rp 1,990",
      size: "9,400 Unit",
      time: "10:35:02 AM",
    },
    {
      price: "$47.98",
      size: "1,200 Shrs",
      time: "10:35:07 AM",
    },
    {
      price: "Rp 6,255",
      size: "1,050 Lot",
      time: "10:35:12 AM",
    },
  ]

  return (
    <div className="bg-card rounded-lg border border-border p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-bold">Market Trades</h2>
        <button>
          <MoreVertical className="h-5 w-5 text-muted-foreground" />
        </button>
      </div>

      <div className="overflow-x-auto -mx-4 px-4">
        <div className="min-w-[400px]">
          <div className="grid grid-cols-3 gap-2 mb-2 text-xs text-muted-foreground">
            <div>Price</div>
            <div>Size</div>
            <div>Time</div>
          </div>

          <div className="space-y-2">
            {marketTradesData.map((item, index) => (
              <div
                key={index}
                className="grid grid-cols-3 gap-2 text-xs border-b border-border pb-2 last:border-0 last:pb-0"
              >
                <div className="text-emerald-500">{item.price}</div>
                <div>{item.size}</div>
                <div>{item.time}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
