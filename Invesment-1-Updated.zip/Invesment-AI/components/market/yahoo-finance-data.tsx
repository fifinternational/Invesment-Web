"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RefreshCw, TrendingUp, TrendingDown, Plus, Minus } from 'lucide-react'
import { RealTimeIndicator } from '@/components/ui/real-time-indicator'

interface StockData {
  symbol: string
  company_name: string
  market: string
  current_price: number
  change: number
  change_percent: number
  volume: number
  currency: string
  data_source: string
}

interface NewsItem {
  title: string
  summary: string
  source: string
  published_at: string
  category: string
  sentiment: string
  related_symbols: string[]
}

interface YahooFinanceDataProps {
  selectedMarket: 'IDX' | 'US'
}

export function YahooFinanceData({ selectedMarket }: YahooFinanceDataProps) {
  const [stocks, setStocks] = useState<StockData[]>([])
  const [news, setNews] = useState<NewsItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [watchlist, setWatchlist] = useState<string[]>([])
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)

  // Fetch stock data from Yahoo Finance API
  const fetchStockData = async () => {
    try {
      setLoading(true)
      setError(null)

      // Get Shariah stocks list
      const shariahResponse = await fetch(`/api/free-market-data?action=shariah-stocks&market=${selectedMarket}`)
      const shariahResult = await shariahResponse.json()
      
      if (!shariahResult.success) {
        throw new Error('Failed to fetch Shariah stocks list')
      }

      const shariahStocks = shariahResult.data.slice(0, 8) // Get first 8 stocks
      const symbols = shariahStocks.map((stock: any) => stock.symbol)

      // Get multiple quotes
      const quotesResponse = await fetch(`/api/free-market-data?action=multiple-quotes&symbols=${symbols.join(',')}`)
      const quotesResult = await quotesResponse.json()

      if (quotesResult.success) {
        setStocks(quotesResult.data)
      }

      // Get market news
      const newsResponse = await fetch(`/api/free-market-data?action=market-news&market=${selectedMarket}`)
      const newsResult = await newsResponse.json()

      if (newsResult.success) {
        setNews(newsResult.data)
      }

      setLastUpdate(new Date())

    } catch (err: any) {
      console.error('Error fetching data:', err)
      setError(err.message || 'Failed to fetch market data')
    } finally {
      setLoading(false)
    }
  }

  // Auto-refresh every 5 minutes
  useEffect(() => {
    fetchStockData()
    
    const interval = setInterval(() => {
      fetchStockData()
    }, 5 * 60 * 1000) // 5 minutes

    return () => clearInterval(interval)
  }, [selectedMarket])

  // Toggle watchlist
  const toggleWatchlist = (symbol: string) => {
    setWatchlist(prev => 
      prev.includes(symbol) 
        ? prev.filter(s => s !== symbol)
        : [...prev, symbol]
    )
  }

  // Format price
  const formatPrice = (price: number, currency: string) => {
    if (currency === 'IDR') {
      return `Rp ${price.toLocaleString('id-ID')}`
    }
    return `$${price.toFixed(2)}`
  }

  // Format change
  const formatChange = (change: number, changePercent: number, currency: string) => {
    const changeStr = currency === 'IDR' 
      ? `Rp ${Math.abs(change).toLocaleString('id-ID')}`
      : `$${Math.abs(change).toFixed(2)}`
    
    const percentStr = `${changePercent >= 0 ? '+' : ''}${changePercent.toFixed(2)}%`
    
    return `${change >= 0 ? '+' : '-'}${changeStr} (${percentStr})`
  }

  // Format time ago
  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffMins = Math.floor(diffMs / (1000 * 60))

    if (diffHours > 0) {
      return `${diffHours} jam lalu`
    } else if (diffMins > 0) {
      return `${diffMins} menit lalu`
    } else {
      return 'Baru saja'
    }
  }

  if (loading && stocks.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5 animate-spin" />
            Memuat Data Pasar...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-100 rounded animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-red-600">Error</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-red-600 mb-4">{error}</p>
          <Button onClick={fetchStockData} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Coba Lagi
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold">
            Data Pasar {selectedMarket === 'IDX' ? 'Indonesia' : 'Amerika Serikat'}
          </h2>
          <div className="mt-2">
            <RealTimeIndicator 
              isUpdating={loading}
              lastUpdate={lastUpdate}
              updateInterval={30}
              dataSource="Yahoo Finance"
            />
          </div>
        </div>
        <Button 
          onClick={fetchStockData} 
          disabled={loading}
          variant="outline"
          size="sm"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh Manual
        </Button>
      </div>

      <Tabs defaultValue="stocks" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="stocks">Saham Syariah</TabsTrigger>
          <TabsTrigger value="news">Berita Pasar</TabsTrigger>
        </TabsList>

        <TabsContent value="stocks" className="space-y-4">
          <div className="grid gap-4">
            {stocks.map((stock) => (
              <Card key={stock.symbol} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div>
                          <h3 className="font-semibold text-lg">{stock.symbol}</h3>
                          <p className="text-sm text-gray-600 truncate max-w-[200px]">
                            {stock.company_name}
                          </p>
                        </div>
                        <Badge variant="secondary">Syariah</Badge>
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>Volume: {stock.volume?.toLocaleString() || 'N/A'}</span>
                        <span>Sumber: Yahoo Finance</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-2xl font-bold mb-1">
                        {formatPrice(stock.current_price, stock.currency)}
                      </div>
                      
                      <div className={`flex items-center gap-1 text-sm font-medium ${
                        stock.change >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {stock.change >= 0 ? (
                          <TrendingUp className="h-4 w-4" />
                        ) : (
                          <TrendingDown className="h-4 w-4" />
                        )}
                        {formatChange(stock.change, stock.change_percent, stock.currency)}
                      </div>
                    </div>

                    <div className="ml-4">
                      <Button
                        onClick={() => toggleWatchlist(stock.symbol)}
                        variant={watchlist.includes(stock.symbol) ? "default" : "outline"}
                        size="sm"
                      >
                        {watchlist.includes(stock.symbol) ? (
                          <>
                            <Minus className="h-4 w-4 mr-1" />
                            Hapus
                          </>
                        ) : (
                          <>
                            <Plus className="h-4 w-4 mr-1" />
                            Tambah
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {stocks.length === 0 && !loading && (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-600">Tidak ada data saham tersedia</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="news" className="space-y-4">
          <div className="grid gap-4">
            {news.map((item, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-4">
                      <h3 className="font-semibold text-lg leading-tight flex-1">
                        {item.title}
                      </h3>
                      <Badge 
                        variant={item.sentiment === 'positive' ? 'default' : 
                                item.sentiment === 'negative' ? 'destructive' : 'secondary'}
                      >
                        {item.sentiment === 'positive' ? 'Positif' : 
                         item.sentiment === 'negative' ? 'Negatif' : 'Netral'}
                      </Badge>
                    </div>
                    
                    <p className="text-gray-600 text-sm leading-relaxed">
                      {item.summary}
                    </p>
                    
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center gap-4">
                        <span className="font-medium">{item.source}</span>
                        <span>{formatTimeAgo(item.published_at)}</span>
                        <Badge variant="outline" className="text-xs">
                          {item.category === 'company' ? 'Perusahaan' : 
                           item.category === 'market' ? 'Pasar' : 'Umum'}
                        </Badge>
                      </div>
                      
                      {item.related_symbols.length > 0 && (
                        <div className="flex gap-1">
                          {item.related_symbols.slice(0, 3).map((symbol) => (
                            <Badge key={symbol} variant="outline" className="text-xs">
                              {symbol}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {news.length === 0 && !loading && (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-600">Tidak ada berita tersedia</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Watchlist Summary */}
      {watchlist.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Watchlist Anda</CardTitle>
            <CardDescription>
              {watchlist.length} saham dalam watchlist
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {watchlist.map((symbol) => (
                <Badge key={symbol} variant="default" className="px-3 py-1">
                  {symbol}
                  <button
                    onClick={() => toggleWatchlist(symbol)}
                    className="ml-2 hover:bg-white/20 rounded-full p-0.5"
                  >
                    <Minus className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
