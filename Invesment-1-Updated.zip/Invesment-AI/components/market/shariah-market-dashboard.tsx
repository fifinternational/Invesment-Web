"use client"

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { TrendingUp, TrendingDown, RefreshCw, BarChart3, Globe, Flag } from 'lucide-react'
import { useLanguage } from '@/contexts/language-context'

interface MarketIndex {
  symbol: string
  name: string
  nameId: string
  price: number
  change: number
  changePercent: number
  volume?: number
  marketCap?: string
  tradingViewSymbol: string
}

interface ShariahStock {
  symbol: string
  name: string
  nameId: string
  price: number
  change: number
  changePercent: number
  sector: string
  sectorId: string
  tradingViewSymbol: string
}

export default function ShariahMarketDashboard() {
  const { language } = useLanguage()
  const [selectedMarket, setSelectedMarket] = useState<'IDX' | 'US'>('IDX')
  const [loading, setLoading] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)

  // Indonesian Shariah Indices
  const indonesianIndices: MarketIndex[] = [
    {
      symbol: 'JII',
      name: 'Jakarta Islamic Index',
      nameId: 'Indeks Saham Syariah Jakarta',
      price: 745.50,
      change: 8.25,
      changePercent: 1.12,
      volume: 2450000,
      marketCap: 'Rp 8.5T',
      tradingViewSymbol: 'IDX:JII'
    },
    {
      symbol: 'ISSI',
      name: 'Indonesia Sharia Stock Index',
      nameId: 'Indeks Saham Syariah Indonesia',
      price: 198.75,
      change: 2.15,
      changePercent: 1.09,
      volume: 1850000,
      marketCap: 'Rp 12.3T',
      tradingViewSymbol: 'IDX:ISSI'
    }
  ]

  // US Shariah Indices
  const usIndices: MarketIndex[] = [
    {
      symbol: 'SPUS',
      name: 'SP Funds S&P 500 Sharia Industry Exclusions ETF',
      nameId: 'ETF S&P 500 Syariah',
      price: 142.85,
      change: 1.75,
      changePercent: 1.24,
      volume: 125000,
      marketCap: '$2.8B',
      tradingViewSymbol: 'NASDAQ:SPUS'
    },
    {
      symbol: 'HLAL',
      name: 'Wahed FTSE USA Shariah ETF',
      nameId: 'ETF Saham Syariah AS',
      price: 28.92,
      change: 0.45,
      changePercent: 1.58,
      volume: 89000,
      marketCap: '$145M',
      tradingViewSymbol: 'NASDAQ:HLAL'
    }
  ]

  // Indonesian Shariah Stocks
  const indonesianStocks: ShariahStock[] = [
    {
      symbol: 'BRIS',
      name: 'Bank BRI Syariah Tbk',
      nameId: 'Bank BRI Syariah Tbk',
      price: 2850,
      change: 75,
      changePercent: 2.70,
      sector: 'Banking',
      sectorId: 'Perbankan',
      tradingViewSymbol: 'IDX:BRIS'
    },
    {
      symbol: 'UNVR',
      name: 'Unilever Indonesia Tbk',
      nameId: 'Unilever Indonesia Tbk',
      price: 3980,
      change: -20,
      changePercent: -0.50,
      sector: 'Consumer Goods',
      sectorId: 'Barang Konsumen',
      tradingViewSymbol: 'IDX:UNVR'
    },
    {
      symbol: 'TLKM',
      name: 'Telkom Indonesia Tbk',
      nameId: 'Telkom Indonesia Tbk',
      price: 4150,
      change: 50,
      changePercent: 1.22,
      sector: 'Telecommunications',
      sectorId: 'Telekomunikasi',
      tradingViewSymbol: 'IDX:TLKM'
    },
    {
      symbol: 'PTBA',
      name: 'Bukit Asam Tbk',
      nameId: 'Bukit Asam Tbk',
      price: 2750,
      change: 125,
      changePercent: 4.76,
      sector: 'Mining',
      sectorId: 'Pertambangan',
      tradingViewSymbol: 'IDX:PTBA'
    }
  ]

  // US Shariah Stocks
  const usStocks: ShariahStock[] = [
    {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      nameId: 'Apple Inc.',
      price: 189.45,
      change: 2.15,
      changePercent: 1.15,
      sector: 'Technology',
      sectorId: 'Teknologi',
      tradingViewSymbol: 'NASDAQ:AAPL'
    },
    {
      symbol: 'MSFT',
      name: 'Microsoft Corporation',
      nameId: 'Microsoft Corporation',
      price: 378.92,
      change: 4.25,
      changePercent: 1.13,
      sector: 'Technology',
      sectorId: 'Teknologi',
      tradingViewSymbol: 'NASDAQ:MSFT'
    },
    {
      symbol: 'JNJ',
      name: 'Johnson & Johnson',
      nameId: 'Johnson & Johnson',
      price: 165.78,
      change: -0.85,
      changePercent: -0.51,
      sector: 'Healthcare',
      sectorId: 'Kesehatan',
      tradingViewSymbol: 'NYSE:JNJ'
    },
    {
      symbol: 'PG',
      name: 'Procter & Gamble Co.',
      nameId: 'Procter & Gamble Co.',
      price: 158.34,
      change: 1.92,
      changePercent: 1.23,
      sector: 'Consumer Goods',
      sectorId: 'Barang Konsumen',
      tradingViewSymbol: 'NYSE:PG'
    }
  ]

  const refreshData = useCallback(async () => {
    setLoading(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    setLastUpdate(new Date())
    setLoading(false)
  }, [])

  useEffect(() => {
    refreshData()
    const interval = setInterval(refreshData, 5 * 60 * 1000) // Refresh every 5 minutes
    return () => clearInterval(interval)
  }, [refreshData])

  const formatPrice = (price: number, currency: 'IDR' | 'USD') => {
    if (currency === 'IDR') {
      return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }).format(price)
    } else {
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      }).format(price)
    }
  }

  const formatChange = (change: number, changePercent: number) => {
    const isPositive = change >= 0
    const color = isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
    const bgColor = isPositive ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'
    const icon = isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />
    
    return (
      <div className={`flex items-center gap-1 px-2 py-1 rounded-md ${color} ${bgColor}`}>
        {icon}
        <span className="text-xs font-medium">
          {change >= 0 ? '+' : ''}{changePercent.toFixed(2)}%
        </span>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-teal-600" />
            {language === 'id-ID' ? 'Pasar Saham Syariah' : 'Shariah Stock Markets'}
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            {language === 'id-ID' 
              ? 'Indeks dan saham syariah Indonesia dan Amerika Serikat'
              : 'Indonesian and US Shariah indices and stocks'
            }
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          {lastUpdate && (
            <div className="text-sm text-gray-500">
              {language === 'id-ID' ? 'Update terakhir:' : 'Last update:'} {lastUpdate.toLocaleTimeString()}
            </div>
          )}
          
          <Button 
            onClick={refreshData} 
            disabled={loading}
            variant="outline"
            size="sm"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            {language === 'id-ID' ? 'Refresh' : 'Refresh'}
          </Button>
        </div>
      </div>

      {/* Market Tabs */}
      <Tabs value={selectedMarket} onValueChange={(value) => setSelectedMarket(value as 'IDX' | 'US')}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="IDX" className="flex items-center gap-2">
            <Flag className="w-4 h-4" />
            {language === 'id-ID' ? 'Pasar Indonesia' : 'Indonesian Market'}
          </TabsTrigger>
          <TabsTrigger value="US" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            {language === 'id-ID' ? 'Pasar Amerika' : 'US Market'}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="IDX" className="space-y-6">
          <MarketContent 
            market="IDX"
            indices={indonesianIndices}
            stocks={indonesianStocks}
            currency="IDR"
            formatPrice={formatPrice}
            formatChange={formatChange}
            language={language}
          />
        </TabsContent>

        <TabsContent value="US" className="space-y-6">
          <MarketContent 
            market="US"
            indices={usIndices}
            stocks={usStocks}
            currency="USD"
            formatPrice={formatPrice}
            formatChange={formatChange}
            language={language}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface MarketContentProps {
  market: 'IDX' | 'US'
  indices: MarketIndex[]
  stocks: ShariahStock[]
  currency: 'IDR' | 'USD'
  formatPrice: (price: number, currency: 'IDR' | 'USD') => string
  formatChange: (change: number, changePercent: number) => JSX.Element
  language: string
}

function MarketContent({ 
  market, 
  indices, 
  stocks, 
  currency, 
  formatPrice, 
  formatChange, 
  language 
}: MarketContentProps) {
  const [selectedSymbol, setSelectedSymbol] = useState(indices[0]?.tradingViewSymbol || '')

  return (
    <div className="space-y-6">
      {/* TradingView Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              {language === 'id-ID' ? 'Grafik Candlestick Syariah' : 'Shariah Candlestick Chart'}
            </div>
            <select 
              value={selectedSymbol}
              onChange={(e) => setSelectedSymbol(e.target.value)}
              className="px-3 py-1 text-sm border rounded-md bg-background"
            >
              <optgroup label={language === 'id-ID' ? 'Indeks Syariah' : 'Shariah Indices'}>
                {indices.map(index => (
                  <option key={index.symbol} value={index.tradingViewSymbol}>
                    {language === 'id-ID' ? index.nameId : index.name}
                  </option>
                ))}
              </optgroup>
              <optgroup label={language === 'id-ID' ? 'Saham Syariah' : 'Shariah Stocks'}>
                {stocks.map(stock => (
                  <option key={stock.symbol} value={stock.tradingViewSymbol}>
                    {stock.symbol} - {language === 'id-ID' ? stock.nameId : stock.name}
                  </option>
                ))}
              </optgroup>
            </select>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <TradingViewCandlestickWidget 
            symbol={selectedSymbol}
            market={market}
            height={500}
          />
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Shariah Indices */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-teal-600" />
              {language === 'id-ID' ? 'Indeks Syariah' : 'Shariah Indices'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {indices.map((index) => (
                <div key={index.symbol} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-lg">{index.symbol}</span>
                        <Badge variant="outline" className="text-xs bg-teal-50 text-teal-700 border-teal-200">
                          {language === 'id-ID' ? 'Syariah' : 'Shariah'}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {language === 'id-ID' ? index.nameId : index.name}
                      </div>
                      {index.marketCap && (
                        <div className="text-xs text-gray-500 mt-1">
                          {language === 'id-ID' ? 'Kapitalisasi:' : 'Market Cap:'} {index.marketCap}
                        </div>
                      )}
                    </div>
                    
                    <div className="text-right">
                      <div className="font-semibold text-lg">
                        {formatPrice(index.price, currency)}
                      </div>
                      {formatChange(index.change, index.changePercent)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Shariah Stocks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              {language === 'id-ID' ? 'Saham Syariah Teratas' : 'Top Shariah Stocks'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {stocks.map((stock) => (
                <div key={stock.symbol} className="p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">{stock.symbol}</span>
                        <Badge variant="secondary" className="text-xs">
                          {language === 'id-ID' ? stock.sectorId : stock.sector}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {language === 'id-ID' ? stock.nameId : stock.name}
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="font-semibold">
                        {formatPrice(stock.price, currency)}
                      </div>
                      {formatChange(stock.change, stock.changePercent)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Enhanced TradingView Widget with Candlestick focus
function TradingViewCandlestickWidget({ 
  symbol, 
  market, 
  height = 500 
}: { 
  symbol: string
  market: 'IDX' | 'US'
  height?: number 
}) {
  useEffect(() => {
    const container = document.getElementById('tradingview_candlestick')
    if (!container) return

    container.innerHTML = ''

    const script = document.createElement('script')
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js'
    script.type = 'text/javascript'
    script.async = true
    script.innerHTML = JSON.stringify({
      autosize: false,
      width: "100%",
      height: height,
      symbol: symbol,
      interval: "D",
      timezone: market === 'IDX' ? "Asia/Jakarta" : "America/New_York",
      theme: "light",
      style: "1", // Candlestick style
      locale: "id",
      toolbar_bg: "#f1f3f6",
      enable_publishing: false,
      allow_symbol_change: false,
      details: true,
      hotlist: false,
      calendar: true,
      studies: [
        "STD;SMA",
        "STD;EMA", 
        "STD;Volume",
        "STD;RSI"
      ],
      container_id: "tradingview_candlestick"
    })

    container.appendChild(script)

    return () => {
      if (container) {
        container.innerHTML = ''
      }
    }
  }, [symbol, market, height])

  return (
    <div className="tradingview-widget-container">
      <div id="tradingview_candlestick" />
      <div className="tradingview-widget-copyright mt-2">
        <a 
          href={`https://www.tradingview.com/symbols/${symbol}/`}
          rel="noopener nofollow" 
          target="_blank"
          className="text-xs text-gray-500 hover:text-gray-700"
        >
          <span className="text-blue-600">Grafik candlestick</span> oleh TradingView
        </a>
      </div>
    </div>
  )
}
