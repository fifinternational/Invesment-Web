"use client"

import ShariahMarketDashboard from './shariah-market-dashboard'

export default function RealTimeMarketData() {
  return <ShariahMarketDashboard />
}
