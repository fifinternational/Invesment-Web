"use client"

import { useEffect, useRef, memo } from 'react'

interface TradingViewWidgetProps {
  market: 'IDX' | 'US'
  symbols?: string[]
  height?: number
}

const TradingViewWidget = memo(({ market, symbols, height = 400 }: TradingViewWidgetProps) => {
  const container = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!container.current) return

    // Clear previous widget
    container.current.innerHTML = ''

    // Sharia-compliant symbols for each market
    const shariahSymbols = {
      IDX: [
        'IDX:BRIS',  // Bank BRI Syariah
        'IDX:UNVR',  // Unilever Indonesia
        'IDX:TLKM',  // Telkom Indonesia
        'IDX:PTBA',  // Bukit Asam
        'IDX:INDF',  // Indofood Sukses Makmur
        'IDX:ICBP',  // Indofood CBP
        'IDX:KLBF',  // Kalbe Farma
        'IDX:ASII',  // Astra International
        'IDX:BBCA',  // Bank Central Asia
        'IDX:BMRI'   // Bank Mandiri
      ],
      US: [
        'NASDAQ:AAPL',  // Apple
        'NASDAQ:MSFT',  // Microsoft
        'NASDAQ:GOOGL', // Alphabet
        'NYSE:JNJ',     // Johnson & Johnson
        'NASDAQ:INTC',  // Intel
        'NYSE:PG',      // Procter & Gamble
        'NYSE:KO',      // Coca-Cola
        'NYSE:PFE',     // Pfizer
        'NASDAQ:CSCO',  // Cisco
        'NYSE:MRK'      // Merck
      ]
    }

    const widgetSymbols = symbols || shariahSymbols[market]

    const script = document.createElement('script')
    script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js'
    script.type = 'text/javascript'
    script.async = true
    script.innerHTML = JSON.stringify({
      autosize: false,
      width: "100%",
      height: height,
      symbol: widgetSymbols[0], // Default symbol
      interval: "D",
      timezone: market === 'IDX' ? "Asia/Jakarta" : "America/New_York",
      theme: "light",
      style: "1",
      locale: "id",
      toolbar_bg: "#f1f3f6",
      enable_publishing: false,
      allow_symbol_change: true,
      watchlist: widgetSymbols,
      details: true,
      hotlist: true,
      calendar: false,
      studies: [
        "STD;SMA",
        "STD;EMA",
        "STD;RSI",
        "STD;MACD"
      ],
      show_popup_button: true,
      popup_width: "1000",
      popup_height: "650",
      container_id: "tradingview_widget"
    })

    container.current.appendChild(script)

    return () => {
      if (container.current) {
        container.current.innerHTML = ''
      }
    }
  }, [market, symbols, height])

  return (
    <div className="tradingview-widget-container">
      <div ref={container} id="tradingview_widget" />
      <div className="tradingview-widget-copyright">
        <a 
          href={`https://www.tradingview.com/symbols/${market === 'IDX' ? 'IDX-BRIS' : 'NASDAQ-AAPL'}/`}
          rel="noopener nofollow" 
          target="_blank"
          className="text-xs text-gray-500 hover:text-gray-700"
        >
          <span className="blue-text">Grafik saham</span> oleh TradingView
        </a>
      </div>
    </div>
  )
})

TradingViewWidget.displayName = 'TradingViewWidget'

export default TradingViewWidget
