"use client"

import { useState, useRef, useEffect } from "react"
import { Moon, Sun, Globe } from "lucide-react"
import { useTheme } from "@/contexts/theme-context"
import { useLanguage } from "@/contexts/language-context"
import { motion } from "framer-motion"

export default function QuickSettings() {
  const { theme, setTheme, resolvedTheme } = useTheme()
  const { language, setLanguage } = useLanguage()
  
  const toggleTheme = () => {
    setTheme(resolvedTheme === "dark" ? "light" : "dark")
  }
  
  const toggleLanguage = () => {
    setLanguage(language === "id-ID" ? "en-US" : "id-ID")
  }

  return (
    <div className="flex items-center space-x-2">
      {/* Language Toggle */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleLanguage}
        className="relative p-1.5 rounded-full hover:bg-white/80 focus:outline-none transition-colors"
        aria-label="Toggle Language"
      >
        <Globe className="h-5 w-5 text-foreground" />
        <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-[10px] rounded-full h-4 w-4 flex items-center justify-center font-bold">
          {language === "id-ID" ? "ID" : "EN"}
        </span>
      </motion.button>
      
      {/* Theme Toggle */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={toggleTheme}
        className="p-1.5 rounded-full hover:bg-white/80 focus:outline-none transition-colors"
        aria-label="Toggle Theme"
      >
        {resolvedTheme === "dark" ? (
          <Moon className="h-5 w-5 text-foreground" />
        ) : (
          <Sun className="h-5 w-5 text-foreground" />
        )}
      </motion.button>
    </div>
  )
}