'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

interface TermsPrivacyPopupProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'terms' | 'privacy';
}

const TermsPrivacyPopup: React.FC<TermsPrivacyPopupProps> = ({ isOpen, onClose, type }) => {
  const popupRef = useRef<HTMLDivElement>(null);
  
  // Close popup when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
        onClose();
      }
    };
    
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  // Prevent scrolling of background when popup is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={onClose}
          />
          
          <motion.div
            ref={popupRef}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="relative bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[85vh] overflow-hidden"
          >
            <div className="sticky top-0 z-10 flex items-center justify-between p-4 border-b bg-white/90 backdrop-blur-sm">
              <h2 className="text-xl font-semibold text-gray-900">
                {type === 'terms' ? 'Terms and Conditions' : 'Privacy Policy'}
              </h2>
              <button
                onClick={onClose}
                className="p-2 rounded-full hover:bg-gray-100 transition-colors"
              >
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>
            
            <div className="overflow-y-auto max-h-[calc(85vh-140px)] p-6 pt-8">
              <div className="prose prose-sm max-w-none">
                {type === 'terms' ? (
                  <>
                    <h3 className="text-lg font-semibold text-[#2dd4bf] mb-6 mt-2">Blublub Investment AI Platform - Terms of Service</h3>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">1. Introduction</h4>
                    <p className="text-gray-600 mb-4">
                      Welcome to Blublub Investment AI Platform. These Terms and Conditions govern your use of the services provided by our platform, including the website, applications, and related services (collectively referred to as the "Services").
                    </p>
                    <p className="text-gray-600 mb-4">
                      By accessing or using our Services, you agree to be bound by these Terms and Conditions. If you do not agree with any part of this document, you must not access the Services.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">2. Definitions</h4>
                    <p className="text-gray-600 mb-4">
                      <strong>"User"</strong> refers to individuals who access or use our Services.<br />
                      <strong>"Content"</strong> refers to all information, data, text, images, graphics, or other materials displayed or made available through the Services.<br />
                      <strong>"Account"</strong> refers to the user registration required to access certain features of the Services.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">3. Account Registration</h4>
                    <p className="text-gray-600 mb-4">
                      To access certain features of our Services, you may be required to register an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.
                    </p>
                    <p className="text-gray-600 mb-4">
                      You are responsible for maintaining the confidentiality of your password and for all activities that occur under your account. You agree to immediately notify us of any unauthorized use of your account or password.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">4. Investment Disclaimer</h4>
                    <p className="text-gray-600 mb-4">
                      All investment recommendations and analysis provided by our AI are for informational purposes only. Past performance does not guarantee future results. You should consult with a financial advisor before making investment decisions.
                    </p>
                    <p className="text-gray-600 mb-4">
                      Investing in financial markets involves risk, including the possible loss of principal. The value of investments may fluctuate and can go down as well as up.
                    </p>
                    <p className="text-gray-600 mb-4 font-semibold text-red-600">
                      WE ARE NOT RESPONSIBLE FOR ANY FINANCIAL LOSSES OR DAMAGES INCURRED AS A RESULT OF USING OUR SERVICES OR RELYING ON THE INFORMATION PROVIDED. USERS SHOULD CONDUCT THEIR OWN RESEARCH BEFORE MAKING ANY INVESTMENT DECISIONS.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">5. Sharia Compliance</h4>
                    <p className="text-gray-600 mb-4">
                      While we strive to provide Sharia-compliant investment options, users should verify compliance with their own religious advisors as interpretations may vary.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">6. Data Privacy</h4>
                    <p className="text-gray-600 mb-4">
                      We are committed to protecting your privacy. Your personal information will be handled in accordance with our Privacy Policy and applicable data protection laws.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">7. No Refund Policy</h4>
                    <p className="text-gray-600 mb-4">
                      All payments made for our Services are non-refundable. By subscribing to or purchasing our Services, you acknowledge and agree that we do not provide refunds for any portion of the subscription or purchase fees.
                    </p>
                    <p className="text-gray-600 mb-4 font-semibold text-red-600">
                      WE DO NOT GUARANTEE FINANCIAL RETURNS OR PROFITS FROM USING OUR RESEARCH SERVICES. ANY DECISION TO INVEST BASED ON OUR CONTENT IS MADE AT YOUR OWN RISK.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">8. Limitation of Liability</h4>
                    <p className="text-gray-600 mb-4">
                      Blublub shall not be liable for any direct, indirect, incidental, consequential, or punitive damages arising from your use of the platform.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">9. Modifications</h4>
                    <p className="text-gray-600 mb-4">
                      Blublub may revise these terms at any time without notice. By using this platform, you are agreeing to be bound by the current version of these terms.
                    </p>
                    
                    <h4 className="text-base font-medium text-gray-800 mt-6 mb-2">10. Contact Information</h4>
                    <p className="text-gray-600 mb-4">
                      If you have any questions about these Terms and Conditions, please contact us at:<br />
                      Email: fifinternational77@gmail.com<br />
                      Phone: +1 (555) 123-4567
                    </p>
                  </>
                ) : (
                <>
                  <h3 className="text-lg font-medium text-gray-800">1. Introduction</h3>
                  <p className="text-gray-600 mb-4">
                    At Invesment, we value your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, disclose, and protect your personal information when you use our services, including our website, applications, and related services (collectively referred to as the "Services").
                  </p>
                  <p className="text-gray-600 mb-4">
                    By accessing or using our Services, you agree to the practices described in this Privacy Policy. If you do not agree with this Privacy Policy, please do not use our Services.
                  </p>
                  
                  <h3 className="text-lg font-medium text-gray-800">2. Information We Collect</h3>
                  <p className="text-gray-600 mb-4">
                    We collect several types of information from and about users of our Services, including:
                  </p>
                  <ul className="list-disc pl-6 mb-4 text-gray-600">
                    <li><strong>Personal Identity Information:</strong> Such as name, email address, postal address, phone number, and other identifying information when you register for an account or communicate with us.</li>
                    <li><strong>Financial Information:</strong> Such as bank account details, credit card information, and transaction history when you use our financial research services.</li>
                    <li><strong>Profile Information:</strong> Such as username, password, investment preferences, feedback, and survey responses.</li>
                    <li><strong>Usage Information:</strong> Such as how and when you use our Services, the hardware and software you use to access our Services, and other information about your interactions with our Services.</li>
                  </ul>
                  
                  <h3 className="text-lg font-medium text-gray-800">3. Financial Data Disclaimer</h3>
                  <p className="text-gray-600 mb-4">
                    THE FINANCIAL INFORMATION WE COLLECT IS USED SOLELY FOR PROVIDING OUR SERVICES AND IS HANDLED WITH THE UTMOST SECURITY AND CONFIDENTIALITY. HOWEVER, WE ARE NOT RESPONSIBLE FOR ANY FINANCIAL LOSSES OR DAMAGES RESULTING FROM DATA BREACHES OR UNAUTHORIZED ACCESS DESPITE OUR SECURITY MEASURES.
                  </p>
                </>
              )}
              </div>
            </div>
            
            {/* Footer with Back Button */}
            <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4">
              <button
                onClick={onClose}
                className="w-full px-4 py-3 bg-[#2dd4bf] hover:bg-[#14b8a6] text-white font-medium rounded-xl transition-colors duration-200 flex items-center justify-center gap-2 shadow-sm"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                Back
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default TermsPrivacyPopup;