import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

interface BubbleProps {
  size: number;
  position: { x: number; y: number };
  delay: number;
  type?: 'primary' | 'secondary' | 'accent';
}

const Bubble: React.FC<BubbleProps> = ({ size, position, delay, type = 'primary' }) => {
  // Variasi warna dan efek berdasarkan tipe gelembung
  const bubbleStyles = {
    primary: {
      background: 'radial-gradient(circle, #f8f9fa 0%, rgba(45,212,191,0.5) 70%)',
      boxShadow: '0 8px 32px rgba(45, 212, 191, 0.4)',
      border: '1.5px solid #e9ecef',
      filter: 'blur(0px)',
    },
    secondary: {
      background: 'radial-gradient(circle, #f1f3f4 0%, rgba(45,212,191,0.3) 70%)',
      boxShadow: '0 4px 16px rgba(45, 212, 191, 0.2)',
      border: '1px solid #dee2e6',
      filter: 'blur(1px)',
    },
    accent: {
      background: 'radial-gradient(circle, rgba(45,212,191,0.8) 0%, rgba(255,255,255,0.3) 70%)',
      boxShadow: '0 12px 36px rgba(45, 212, 191, 0.4)',
      border: '2px solid rgba(45, 212, 191, 0.5)',
      filter: 'blur(0px)',
    }
  };
  
  return (
    <motion.div
      className="absolute rounded-full"
      style={{
        width: size,
        height: size,
        left: `${position.x}%`,
        top: `${position.y}%`,
        backdropFilter: 'blur(5px)',
        ...bubbleStyles[type],
      }}
      initial={{ opacity: 0, scale: 0 }}
      animate={{ 
        opacity: [0, 0.9, 0.7], 
        scale: [0, 1, 0.9], 
        y: [0, -15, 0],
        rotate: [0, type === 'accent' ? 10 : 0, 0]
      }}
      transition={{
        duration: type === 'primary' ? 5 : type === 'accent' ? 6 : 4,
        repeat: Infinity,
        repeatType: 'reverse',
        delay: delay,
      }}
    />
  );
};

const CandlestickIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect x="6" y="8" width="4" height="8" rx="1" fill="#2dd4bf" />
      <rect x="14" y="4" width="4" height="12" rx="1" fill="white" />
      <line x1="8" y1="4" x2="8" y2="8" stroke="#2dd4bf" strokeWidth="1.5" />
      <line x1="8" y1="16" x2="8" y2="20" stroke="#2dd4bf" strokeWidth="1.5" />
      <line x1="16" y1="2" x2="16" y2="4" stroke="white" strokeWidth="1.5" />
      <line x1="16" y1="16" x2="16" y2="22" stroke="white" strokeWidth="1.5" />
    </svg>
  );
};

const StockChartIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Grid lines */}
      <line x1="2" y1="2" x2="2" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="8" y1="2" x2="8" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="14" y1="2" x2="14" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="20" y1="2" x2="20" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="2" y1="4" x2="22" y2="4" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="2" y1="10" x2="22" y2="10" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="2" y1="16" x2="22" y2="16" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="2" y1="22" x2="22" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      
      {/* Stock chart line */}
      <path
        d="M2 16L4 14L6 18L8 12L10 10L12 8L14 12L16 6L18 8L20 4L22 6"
        stroke="#2dd4bf"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      
      {/* Volume bars */}
      <rect x="3" y="19" width="1" height="3" fill="#2dd4bf" opacity="0.5" />
      <rect x="5" y="20" width="1" height="2" fill="#2dd4bf" opacity="0.5" />
      <rect x="7" y="18" width="1" height="4" fill="#2dd4bf" opacity="0.5" />
      <rect x="9" y="19" width="1" height="3" fill="#2dd4bf" opacity="0.5" />
      <rect x="11" y="20" width="1" height="2" fill="#2dd4bf" opacity="0.5" />
      <rect x="13" y="19" width="1" height="3" fill="#2dd4bf" opacity="0.5" />
      <rect x="15" y="18" width="1" height="4" fill="#2dd4bf" opacity="0.5" />
      <rect x="17" y="20" width="1" height="2" fill="#2dd4bf" opacity="0.5" />
      <rect x="19" y="19" width="1" height="3" fill="#2dd4bf" opacity="0.5" />
    </svg>
  );
};

const ChartLineIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M3 16L7 12L11 16L21 6"
        stroke="#2dd4bf"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16 6H21V11"
        stroke="#2dd4bf"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

const TradingViewIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Frame */}
      <rect x="2" y="2" width="20" height="20" rx="2" stroke="#e0e0e0" strokeWidth="0.5" fill="none" />
      
      {/* Chart area */}
      <rect x="3" y="3" width="18" height="14" fill="none" />
      
      {/* Price bars */}
      <rect x="4" y="6" width="1" height="8" fill="#2dd4bf" />
      <rect x="6" y="8" width="1" height="6" fill="#2dd4bf" />
      <rect x="8" y="5" width="1" height="9" fill="#2dd4bf" />
      <rect x="10" y="7" width="1" height="7" fill="#2dd4bf" />
      <rect x="12" y="4" width="1" height="10" fill="#2dd4bf" />
      <rect x="14" y="9" width="1" height="5" fill="#2dd4bf" />
      <rect x="16" y="6" width="1" height="8" fill="#2dd4bf" />
      <rect x="18" y="7" width="1" height="7" fill="#2dd4bf" />
      
      {/* Bottom panel */}
      <rect x="3" y="18" width="18" height="3" fill="none" stroke="#e0e0e0" strokeWidth="0.5" />
      
      {/* Volume indicators */}
      <rect x="4" y="19" width="1" height="1" fill="#2dd4bf" opacity="0.5" />
      <rect x="6" y="19.5" width="1" height="0.5" fill="#2dd4bf" opacity="0.5" />
      <rect x="8" y="19" width="1" height="1" fill="#2dd4bf" opacity="0.5" />
      <rect x="10" y="19.5" width="1" height="0.5" fill="#2dd4bf" opacity="0.5" />
      <rect x="12" y="19" width="1" height="1" fill="#2dd4bf" opacity="0.5" />
      <rect x="14" y="19.5" width="1" height="0.5" fill="#2dd4bf" opacity="0.5" />
      <rect x="16" y="19" width="1" height="1" fill="#2dd4bf" opacity="0.5" />
      <rect x="18" y="19.5" width="1" height="0.5" fill="#2dd4bf" opacity="0.5" />
    </svg>
  );
};

// Pre-generated static bubble data to prevent hydration mismatch
const staticBubbles = {
  primary: Array.from({ length: 8 }, (_, i) => ({
    id: `primary-${i}`,
    size: 80 + (i * 15), // Deterministic sizes
    position: {
      x: (i * 12.5) % 100,
      y: (i * 17) % 100,
    },
    delay: i * 0.25,
    type: 'primary' as const,
  })),
  secondary: Array.from({ length: 12 }, (_, i) => ({
    id: `secondary-${i}`,
    size: 40 + (i * 5), // Deterministic sizes
    position: {
      x: (i * 8.33) % 100,
      y: (i * 13) % 100,
    },
    delay: 0.5 + (i * 0.25),
    type: 'secondary' as const,
  })),
  accent: Array.from({ length: 5 }, (_, i) => ({
    id: `accent-${i}`,
    size: 60 + (i * 18), // Deterministic sizes
    position: {
      x: (i * 20) % 100,
      y: (i * 23) % 100,
    },
    delay: 1 + (i * 0.4),
    type: 'accent' as const,
  }))
};

function BubbleBackground() {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  if (!isClient) {
    return (
      <div className="fixed inset-0 overflow-hidden bg-gradient-to-br from-white via-[#e6fffc] to-white" style={{ zIndex: -10 }}>
        {/* Trading icons only - no bubbles during SSR */}
        <div className="absolute inset-0" style={{ zIndex: -5 }}>
          <div className="absolute top-20 left-10">
            <CandlestickIcon className="w-32 h-32 opacity-35" />
          </div>
          <div className="absolute top-32 right-16">
            <StockChartIcon className="w-36 h-36 opacity-35" />
          </div>
          <div className="absolute bottom-24 left-20">
            <ChartLineIcon className="w-28 h-28 opacity-35" />
          </div>
          <div className="absolute bottom-40 right-12">
            <TradingViewIcon className="w-40 h-40 opacity-35" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 overflow-hidden bg-gradient-to-br from-white via-[#e6fffc] to-white" style={{ zIndex: -10 }}>
      {/* Trading icons behind bubbles - lowest layer */}
      <div className="absolute inset-0" style={{ zIndex: -5 }}>
        {/* Static trading icons - No movement, larger size */}
        <div className="absolute top-20 left-10">
          <CandlestickIcon className="w-32 h-32 opacity-35" />
        </div>
        
        <div className="absolute top-32 right-16">
          <StockChartIcon className="w-36 h-36 opacity-35" />
        </div>
        
        <div className="absolute bottom-24 left-20">
          <ChartLineIcon className="w-28 h-28 opacity-35" />
        </div>
        
        <div className="absolute bottom-40 right-12">
          <TradingViewIcon className="w-40 h-40 opacity-35" />
        </div>

        <div className="absolute top-60 left-32">
          <CandlestickIcon className="w-30 h-30 opacity-35" />
        </div>
        
        <div className="absolute top-80 right-32">
          <ChartLineIcon className="w-26 h-26 opacity-35" />
        </div>
        
        <div className="absolute bottom-60 left-8">
          <StockChartIcon className="w-32 h-32 opacity-35" />
        </div>
        
        <div className="absolute bottom-80 right-24">
          <TradingViewIcon className="w-34 h-34 opacity-35" />
        </div>

        <div className="absolute top-40 left-60">
          <CandlestickIcon className="w-28 h-28 opacity-35" />
        </div>
        
        <div className="absolute bottom-32 right-60">
          <ChartLineIcon className="w-24 h-24 opacity-35" />
        </div>

        {/* Additional trading icons */}
        <div className="absolute top-16 right-40">
          <StockChartIcon className="w-30 h-30 opacity-35" />
        </div>
        
        <div className="absolute top-72 left-16">
          <TradingViewIcon className="w-28 h-28 opacity-35" />
        </div>
        
        <div className="absolute bottom-16 left-40">
          <CandlestickIcon className="w-26 h-26 opacity-35" />
        </div>
        
        <div className="absolute bottom-72 right-8">
          <ChartLineIcon className="w-22 h-22 opacity-35" />
        </div>
      </div>

      {/* Animated bubbles in front - highest layer */}
      <div className="absolute inset-0" style={{ zIndex: -2 }}>
        {staticBubbles.primary.map((bubble) => (
          <Bubble key={bubble.id} {...bubble} />
        ))}
        {staticBubbles.secondary.map((bubble) => (
          <Bubble key={bubble.id} {...bubble} />
        ))}
        {staticBubbles.accent.map((bubble) => (
          <Bubble key={bubble.id} {...bubble} />
        ))}
      </div>
    </div>
  );
}

export default BubbleBackground;