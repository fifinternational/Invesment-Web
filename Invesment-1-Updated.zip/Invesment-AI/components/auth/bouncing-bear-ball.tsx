"use client"

import { memo } from 'react'
import { motion } from 'framer-motion'
import PolarBearLogo from '@/components/ui/polar-bear-logo'

interface BouncingBearBallProps {
  size?: number
  className?: string
}

const BouncingBearBall = memo(({ size = 120, className = "" }: BouncingBearBallProps) => {
  return (
    <motion.div
      className={`absolute ${className}`}
      initial={{ x: 0, y: 0 }}
      animate={{
        x: [0, 100, -50, 80, -30, 0],
        y: [0, -80, -120, -60, -100, 0],
      }}
      transition={{
        duration: 8,
        repeat: Infinity,
        ease: "easeInOut",
        times: [0, 0.2, 0.4, 0.6, 0.8, 1]
      }}
      style={{
        width: size,
        height: size,
      }}
    >
      {/* Bola Transparan dengan Beruang di Dalam */}
      <motion.div
        className="relative w-full h-full"
        animate={{
          rotate: [0, 360],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "linear"
        }}
      >
        {/* Bola Luar - Efek Kaca Normal */}
        <div 
          className="absolute inset-0 rounded-full"
          style={{
            background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.8), rgba(173,216,230,0.4), rgba(135,206,235,0.6))',
            border: '2px solid rgba(255,255,255,0.6)',
            boxShadow: `
              0 0 20px rgba(135,206,235,0.4),
              inset 0 0 20px rgba(255,255,255,0.3),
              0 8px 32px rgba(0,0,0,0.1)
            `,
            backdropFilter: 'blur(1px)',
            filter: 'brightness(1) contrast(1)'
          }}
        />
        
        
        {/* Highlight Kaca */}
        <div 
          className="absolute top-3 left-3 w-6 h-6 rounded-full opacity-60"
          style={{
            background: 'radial-gradient(circle, rgba(255,255,255,0.9), transparent 70%)'
          }}
        />
        
        {/* Beruang di Dalam Bola */}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            animate={{
              rotate: [0, -360], // Berlawanan dengan rotasi bola
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            <PolarBearLogo size={size * 0.5} animate={false} />
          </motion.div>
        </div>
        
        {/* Efek Cahaya Bergerak */}
        <motion.div
          className="absolute inset-0 rounded-full opacity-30"
          animate={{
            background: [
              'radial-gradient(circle at 20% 20%, rgba(255,255,255,0.6), transparent 50%)',
              'radial-gradient(circle at 80% 20%, rgba(255,255,255,0.6), transparent 50%)',
              'radial-gradient(circle at 80% 80%, rgba(255,255,255,0.6), transparent 50%)',
              'radial-gradient(circle at 20% 80%, rgba(255,255,255,0.6), transparent 50%)',
              'radial-gradient(circle at 20% 20%, rgba(255,255,255,0.6), transparent 50%)'
            ]
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </motion.div>
      
      {/* Cahaya Putih Bercahaya di Bawah - Normal */}
      <motion.div
        className="absolute -bottom-3 left-1/2 transform -translate-x-1/2"
        animate={{
          scaleX: [1, 1.3, 0.7, 1.2, 0.8, 1],
          opacity: [0.8, 1, 0.6, 0.9, 0.7, 0.8],
          filter: [
            'blur(3px) brightness(1.2)',
            'blur(4px) brightness(1.5)', 
            'blur(2px) brightness(1)',
            'blur(5px) brightness(1.3)',
            'blur(3px) brightness(1.1)',
            'blur(3px) brightness(1.2)'
          ]
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
          times: [0, 0.2, 0.4, 0.6, 0.8, 1]
        }}
        style={{
          width: size * 1,
          height: size * 0.3,
          background: 'radial-gradient(ellipse, rgba(255,255,255,0.9), rgba(255,255,255,0.7) 30%, rgba(255,255,255,0.4) 60%, transparent 80%)',
          borderRadius: '50%',
          boxShadow: `
            0 0 20px rgba(255,255,255,0.8),
            0 0 40px rgba(255,255,255,0.6),
            0 0 60px rgba(255,255,255,0.4),
            0 0 80px rgba(255,255,255,0.2)
          `
        }}
      />
      
      
      {/* Bayangan Gelap di Bawah */}
      <motion.div
        className="absolute -bottom-1 left-1/2 transform -translate-x-1/2"
        animate={{
          scaleX: [1, 1.2, 0.8, 1.1, 0.9, 1],
          opacity: [0.3, 0.4, 0.2, 0.35, 0.25, 0.3]
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
          times: [0, 0.2, 0.4, 0.6, 0.8, 1]
        }}
        style={{
          width: size * 0.5,
          height: size * 0.1,
          background: 'radial-gradient(ellipse, rgba(0,0,0,0.4), transparent 70%)',
          borderRadius: '50%'
        }}
      />
    </motion.div>
  )
})

BouncingBearBall.displayName = 'BouncingBearBall'

export default BouncingBearBall
