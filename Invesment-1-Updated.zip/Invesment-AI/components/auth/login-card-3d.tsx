import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, EyeOff, ArrowRight, UserPlus, User } from 'lucide-react';
import Link from 'next/link';
// Logo import removed
import GoogleAuthButton from '@/components/auth/google-auth-button';
import TermsPrivacyPopup from '@/components/auth/terms-privacy-popup';

interface LoginCard3DProps {
  username: string;
  setUsername: (value: string) => void;
  password: string;
  setPassword: (value: string) => void;
  showPassword: boolean;
  setShowPassword: (value: boolean) => void;
  rememberMe: boolean;
  setRememberMe: (value: boolean) => void;
  isLoading: boolean;
  handleLogin: (e: React.FormEvent) => void;
  handleGoogleLogin: () => void;
  handleDemoLogin?: () => void; // Optional demo login handler
  error: string;
  successMessage: string;
}

const LoginCard3D: React.FC<LoginCard3DProps> = ({
  username,
  setUsername,
  password,
  setPassword,
  showPassword,
  setShowPassword,
  rememberMe,
  setRememberMe,
  isLoading,
  handleLogin,
  handleGoogleLogin,
  handleDemoLogin,
  error,
  successMessage,
}) => {
  const [showTermsModal, setShowTermsModal] = useState(false);
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8, ease: 'easeOut' }}
      className="relative max-w-md w-full p-8 rounded-3xl shadow-2xl overflow-hidden"
      style={{
        background: 'rgba(255, 255, 255, 0.85)',
        backdropFilter: 'blur(12px)',
        border: '2px solid rgba(255, 255, 255, 0.7)',
        boxShadow: '0 25px 50px -12px rgba(45, 212, 191, 0.35), 0 0 20px rgba(45, 212, 191, 0.2) inset',
      }}
    >
      {/* Card background accents - reduced opacity */}
      <div className="absolute -top-10 -right-10 w-32 h-32 rounded-full bg-[#2dd4bf]/3 blur-xl"></div>
      <div className="absolute -bottom-10 -left-10 w-24 h-24 rounded-full bg-[#2dd4bf]/3 blur-lg"></div>
      
      {/* 3D floating effect for the card */}
      <motion.div
        animate={{
          rotateX: [0, 2, 0],
          rotateY: [0, 2, 0],
          boxShadow: [
            '0 25px 50px -12px rgba(45, 212, 191, 0.3)',
            '0 30px 60px -12px rgba(45, 212, 191, 0.4)',
            '0 25px 50px -12px rgba(45, 212, 191, 0.3)'
          ]
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          repeatType: 'reverse',
        }}
        className="absolute inset-0 z-0 rounded-3xl"
        style={{
          background: 'linear-gradient(135deg, rgba(255,255,255,0.6) 0%, rgba(45,212,191,0.2) 100%)',
          transform: 'perspective(1000px)',
        }}
      />

      {/* Content */}
      <div className="relative z-10">
        <div className="text-center">
          <motion.div 
            className="flex justify-center items-center relative gap-3"
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {/* Polar Bear Bubble Image - smaller size */}
            <motion.img 
              src="/polar-bear-bubble.png?v=2"
              alt="Polar Bear Bubble"
              className="w-10 h-10 object-contain dark:brightness-150 dark:contrast-125"
              animate={{ 
                rotate: [0, 5, -5, 0],
                scale: [1, 1.05, 1]
              }}
              transition={{ 
                duration: 3, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
            
            {/* Blublub Text next to bear ball - larger size */}
            <div className="flex items-center">
              <span 
                className="text-3xl font-extrabold drop-shadow-sm" 
                style={{ color: '#2dd4bf' }}
              >
                B
              </span>
              <span className="text-3xl font-extrabold text-gray-500 dark:text-gray-400 drop-shadow-sm">
                lublub
              </span>
            </div>
          </motion.div>
          <p className="mt-3 text-sm text-gray-600 font-medium">
            Sign in to access your AI Sharia Investment Research platform
          </p>
        </div>

        {successMessage && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-4 bg-green-50 border-l-4 border-green-500 p-4 text-sm text-green-700 rounded-r-md"
          >
            <span className="text-2xl font-bold bg-gradient-to-r from-gray-700 to-gray-900 bg-clip-text text-transparent">{successMessage}</span>
          </motion.div>
        )}

        {error && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mt-4 bg-red-50 border-l-4 border-red-500 p-4 text-sm text-red-700 rounded-r-md"
          >
            {error}
          </motion.div>
        )}

        <div className="mt-6 space-y-4">
          {/* Google Login Button */}
          <motion.button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isLoading}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center justify-center px-4 py-3 rounded-xl shadow-sm text-sm font-medium text-white bg-gradient-to-r from-[#a7f3d0] to-[#2dd4bf] hover:from-[#86efac] hover:to-[#14b8a6] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2dd4bf] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <svg className="h-5 w-5 mr-3" viewBox="0 0 24 24">
              <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Sign in with Google
          </motion.button>

          {/* Apple Login Button */}
          <motion.button
            type="button"
            onClick={() => {/* TODO: Implement Apple login */}}
            disabled={isLoading}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center justify-center px-4 py-3 rounded-xl shadow-sm text-sm font-medium text-white bg-gradient-to-r from-[#6ee7b7] to-[#059669] hover:from-[#34d399] hover:to-[#047857] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#059669] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <svg className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="currentColor">
              <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
            </svg>
            Sign in with Apple
          </motion.button>
          
          {/* Demo Account Button */}
          <motion.button
            type="button"
            onClick={handleDemoLogin}
            disabled={isLoading}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center justify-center px-4 py-3 rounded-xl shadow-sm text-sm font-medium text-white bg-gradient-to-r from-[#2dd4bf] to-[#0f766e] hover:from-[#14b8a6] hover:to-[#134e4a] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#2dd4bf] transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <User className="h-5 w-5 mr-3" />
            Demo Account
          </motion.button>
        </div>

        {/* Terms and Conditions */}
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-600 dark:text-gray-400">
            By signing in you agree with{' '}
            <button
              onClick={() => setShowTermsModal(true)}
              className="text-[#2dd4bf] hover:text-[#14b8a6] underline font-medium transition-colors duration-200"
            >
              Terms and Conditions
            </button>
          </p>
        </div>
      </div>

      {/* Terms and Conditions Popup */}
      <TermsPrivacyPopup 
        isOpen={showTermsModal} 
        onClose={() => setShowTermsModal(false)} 
        type="terms" 
      />
    </motion.div>
  );
};

export default LoginCard3D;