import React from 'react';
import { motion } from 'framer-motion';

const CandlestickIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect x="6" y="8" width="4" height="8" rx="1" fill="#2dd4bf" />
      <rect x="14" y="4" width="4" height="12" rx="1" fill="white" />
      <line x1="8" y1="4" x2="8" y2="8" stroke="#2dd4bf" strokeWidth="1.5" />
      <line x1="8" y1="16" x2="8" y2="20" stroke="#2dd4bf" strokeWidth="1.5" />
      <line x1="16" y1="2" x2="16" y2="4" stroke="white" strokeWidth="1.5" />
      <line x1="16" y1="16" x2="16" y2="22" stroke="white" strokeWidth="1.5" />
    </svg>
  );
};

const StockChartIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Grid lines */}
      <line x1="2" y1="2" x2="2" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="8" y1="2" x2="8" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="14" y1="2" x2="14" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="20" y1="2" x2="20" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="2" y1="4" x2="22" y2="4" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="2" y1="10" x2="22" y2="10" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="2" y1="16" x2="22" y2="16" stroke="#e0e0e0" strokeWidth="0.5" />
      <line x1="2" y1="22" x2="22" y2="22" stroke="#e0e0e0" strokeWidth="0.5" />
      
      {/* Stock chart line */}
      <path
        d="M2 16L4 14L6 18L8 12L10 10L12 8L14 12L16 6L18 8L20 4L22 6"
        stroke="#2dd4bf"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      
      {/* Volume bars */}
      <rect x="3" y="19" width="1" height="3" fill="#2dd4bf" opacity="0.5" />
      <rect x="5" y="20" width="1" height="2" fill="#2dd4bf" opacity="0.5" />
      <rect x="7" y="18" width="1" height="4" fill="#2dd4bf" opacity="0.5" />
      <rect x="9" y="19" width="1" height="3" fill="#2dd4bf" opacity="0.5" />
      <rect x="11" y="20" width="1" height="2" fill="#2dd4bf" opacity="0.5" />
      <rect x="13" y="19" width="1" height="3" fill="#2dd4bf" opacity="0.5" />
      <rect x="15" y="18" width="1" height="4" fill="#2dd4bf" opacity="0.5" />
      <rect x="17" y="20" width="1" height="2" fill="#2dd4bf" opacity="0.5" />
      <rect x="19" y="19" width="1" height="3" fill="#2dd4bf" opacity="0.5" />
    </svg>
  );
};

const ChartLineIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M3 16L7 12L11 16L21 6"
        stroke="#2dd4bf"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16 6H21V11"
        stroke="#2dd4bf"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};

const FinanceElements: React.FC = () => {
  return (
    <div className="fixed inset-0 overflow-hidden z-0 pointer-events-none">
      {/* Animated candlestick elements */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 0.15, scale: 1, y: 0 }}
        transition={{ duration: 1.5, delay: 0.2 }}
        className="absolute top-[15%] left-[8%]"
      >
        <CandlestickIcon className="w-28 h-28 transform rotate-3" />
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 0.15, scale: 1, y: 0 }}
        transition={{ duration: 1.5, delay: 0.4 }}
        className="absolute bottom-[20%] left-[12%]"
      >
        <CandlestickIcon className="w-24 h-24 transform -rotate-6" />
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 0.15, scale: 1, y: 0 }}
        transition={{ duration: 1.5, delay: 0.3 }}
        className="absolute top-[20%] right-[10%]"
      >
        <CandlestickIcon className="w-28 h-28 transform -rotate-3" />
      </motion.div>
      
      {/* Animated stock chart elements */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 0.15, scale: 1, y: 0 }}
        transition={{ duration: 1.5, delay: 0.5 }}
        className="absolute top-[35%] left-[20%]"
      >
        <StockChartIcon className="w-36 h-36 transform rotate-6" />
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 0.15, scale: 1, y: 0 }}
        transition={{ duration: 1.5, delay: 0.6 }}
        className="absolute bottom-[30%] right-[15%]"
      >
        <StockChartIcon className="w-32 h-32 transform -rotate-3" />
      </motion.div>
      
      {/* Animated chart line elements */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 0.15, scale: 1, y: 0 }}
        transition={{ duration: 1.5, delay: 0.7 }}
        className="absolute top-[60%] left-[15%]"
      >
        <ChartLineIcon className="w-32 h-32 transform rotate-12" />
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 0.15, scale: 1, y: 0 }}
        transition={{ duration: 1.5, delay: 0.8 }}
        className="absolute top-[45%] right-[25%]"
      >
        <ChartLineIcon className="w-28 h-28 transform -rotate-6" />
      </motion.div>
    </div>
  );
};

export default FinanceElements;