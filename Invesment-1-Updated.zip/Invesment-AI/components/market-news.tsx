"use client"

import { Clock, ExternalLink, TrendingUp, Building2, Globe, DollarSign } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

type Region = "ID" | "US"

interface NewsItem {
  title: string
  summary: string
  date: string
  source: string
  region: Region
  category: string
}

export default function MarketNews({ region = "ID" }: { region?: Region }) {
  const { t } = useLanguage()

  const newsData: NewsItem[] = [
    // Indonesia Market News
    {
      title: "Bank Indonesia Maintains Interest Rate at 6%",
      summary: "Central bank keeps policy rate steady to support economic growth while monitoring inflation",
      date: "2024-01-20",
      source: "Reuters",
      region: "ID",
      category: "Monetary Policy"
    },
    {
      title: "Indonesian Shariah Banking Assets Grow 15% YoY",
      summary: "Islamic banking sector shows strong growth with increased adoption of Shariah-compliant products",
      date: "2024-01-18",
      source: "Jakarta Post",
      region: "ID", 
      category: "Islamic Finance"
    },
    {
      title: "ASII Reports Strong Q4 Earnings",
      summary: "Astra International beats estimates with 12% revenue growth driven by automotive recovery",
      date: "2024-01-15",
      source: "Kontan",
      region: "ID",
      category: "Earnings"
    },
    // US Market News
    {
      title: "US Halal Food Market Reaches $25 Billion",
      summary: "Growing Muslim population drives demand for Shariah-compliant food and beverage companies",
      date: "2024-01-19",
      source: "Bloomberg",
      region: "US",
      category: "Market Trends"
    },
    {
      title: "Tech Giants Embrace ESG and Shariah Principles",
      summary: "Major technology companies align business practices with Islamic finance principles",
      date: "2024-01-17",
      source: "Wall Street Journal",
      region: "US",
      category: "ESG"
    },
    {
      title: "Islamic ETFs See Record Inflows",
      summary: "Shariah-compliant ETFs attract $2.1B in new investments as demand for ethical investing grows",
      date: "2024-01-14",
      source: "Financial Times",
      region: "US",
      category: "Investment Flows"
    }
  ]

  const filteredNews = newsData.filter(news => news.region === region)

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold">
          Market News - {region === "ID" ? "Indonesia" : "US"} 
        </h2>
        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">
          {region === "ID" ? "🇮🇩 IDX" : "🇺🇸 NYSE/NASDAQ"}
        </span>
      </div>

      <div className="space-y-4">
        {filteredNews.map((news, index) => (
          <div key={index} className="border-b border-border pb-4 last:border-0 last:pb-0">
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-semibold text-sm hover:text-primary cursor-pointer line-clamp-2">
                {news.title}
              </h3>
              <ExternalLink className="h-3 w-3 text-muted-foreground ml-2 flex-shrink-0" />
            </div>
            <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
              {news.summary}
            </p>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">{news.date}</span>
                <span className="text-muted-foreground">•</span>
                <span className="text-muted-foreground">{news.source}</span>
              </div>
              <span className="bg-muted text-muted-foreground px-2 py-1 rounded text-xs">
                {news.category}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 text-center">
        <button className="text-sm text-primary hover:underline">
          View All News →
        </button>
      </div>
    </div>
  )
}
