"use client"

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { 
  LayoutDashboard,
  FileText,
  TrendingUp,
  Shield,
  BarChart3,
  Settings,
  MessageSquare,
  CreditCard
} from 'lucide-react'
import { cn } from "@/lib/utils"
import { useLanguage } from '@/contexts/language-context'

const navigationItems = [
  {
    title: "Dashboard",
    titleId: "Dashboard", 
    url: "/dashboard",
    icon: LayoutDashboard,
    badge: "AI"
  },
  {
    title: "Professional Report",
    titleId: "Laporan Profesional",
    url: "/professional-report",
    icon: FileText,
    badge: "Pro"
  },
  {
    title: "Subscribe",
    titleId: "Berlangganan",
    url: "/subscribe",
    icon: CreditCard,
    badge: null
  },
  {
    title: "Market Analysis",
    titleId: "Analisis Pasar",
    url: "/market-analysis",
    icon: BarChart3,
    badge: null
  },
  {
    title: "Shariah Compliance",
    titleId: "Kepatuhan Syariah",
    url: "/shariah-compliance",
    icon: Shield,
    badge: "Verified"
  },
  {
    title: "Settings",
    titleId: "Pengaturan",
    url: "/settings",
    icon: Settings,
    badge: null
  }
]

export function HorizontalNav() {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  const { language } = useLanguage()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <nav className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
      <div className="px-4">
        <div className="flex space-x-1 overflow-x-auto scrollbar-hide">
          {navigationItems.map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.url
            const displayTitle = language === 'id-ID' ? item.titleId : item.title
            
            return (
              <Link
                key={item.url}
                href={item.url}
                className={cn(
                  "flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap border-b-2 hover:text-[#2dd4bf]",
                  isActive 
                    ? "text-[#2dd4bf] border-[#2dd4bf]" 
                    : "text-gray-600 dark:text-gray-400 border-transparent hover:border-gray-300 dark:hover:border-gray-600"
                )}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{displayTitle}</span>
                {item.badge && (
                  <span className={cn(
                    "ml-1 rounded-full px-2 py-0.5 text-xs font-medium",
                    item.badge === "Pro" && "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
                    item.badge === "Verified" && "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
                    item.badge === "AI" && "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300"
                  )}>
                    {item.badge}
                  </span>
                )}
              </Link>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
