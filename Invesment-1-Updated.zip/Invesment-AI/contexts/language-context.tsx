"use client"

import type React from "react"
import { createContext, useContext, useEffect, useMemo, useState } from "react"

type Language = "id-ID" | "en-US"

type Dictionary = Record<string, { "id-ID": string; "en-US": string }>

const DICTIONARY: Dictionary = {
  // Navigation
  nav_dashboard: { "id-ID": "Dasbor", "en-US": "Dashboard" },
  nav_reports: { "id-ID": "Laporan", "en-US": "Reports" },
  nav_subscribe: { "id-ID": "Berlangganan", "en-US": "Subscribe" },
  nav_research: { "id-ID": "Riset Pasar", "en-US": "Market Research" },
  nav_shariah: { "id-ID": "Kepatuhan Syariah", "en-US": "Shariah Compliance" },
  nav_analysis: { "id-ID": "Analisis Pasar", "en-US": "Market Analysis" },
  nav_assistant: { "id-ID": "Asisten AI", "en-US": "AI Assistant" },
  nav_settings: { "id-ID": "Pengaturan", "en-US": "Settings" },
  nav_notifications: { "id-ID": "Notifikasi", "en-US": "Notifications" },
  nav_profile: { "id-ID": "Profil", "en-US": "Profile" },
  nav_logout: { "id-ID": "Keluar", "en-US": "Logout" },
  // Language Settings
  language_selector: { "id-ID": "Pilih Bahasa", "en-US": "Select Language" },
  language_indonesian: { "id-ID": "Bahasa Indonesia", "en-US": "Indonesian" },
  language_english: { "id-ID": "Bahasa Inggris", "en-US": "English" },
  // Common UI
  welcome: { "id-ID": "Selamat Datang", "en-US": "Welcome" },
  loading: { "id-ID": "Memuat...", "en-US": "Loading..." },
  save: { "id-ID": "Simpan", "en-US": "Save" },
  cancel: { "id-ID": "Batal", "en-US": "Cancel" },
  close: { "id-ID": "Tutup", "en-US": "Close" },
  search: { "id-ID": "Cari", "en-US": "Search" },
  filter: { "id-ID": "Filter", "en-US": "Filter" },
  sort: { "id-ID": "Urutkan", "en-US": "Sort" },
  view_all: { "id-ID": "Lihat Semua", "en-US": "View All" },
  // App Branding
  app_name: { "id-ID": "Blublub", "en-US": "Blublub" },
  app_tagline: { "id-ID": "AI Platform Syariah", "en-US": "Shariah AI Platform" },
  heading_dashboard: { "id-ID": "Riset Investasi Syariah AI", "en-US": "AI Shariah Investment Research" },
  subheading_dashboard: { "id-ID": "", "en-US": "" },
  label_market: { "id-ID": "Pasar:", "en-US": "Market:" },
  region_id: { "id-ID": "Indonesia (Syariah)", "en-US": "Indonesia (Shariah)" },
  region_us: { "id-ID": "AS (Syariah)", "en-US": "US (Shariah)" },
  explore_title: { "id-ID": "Jelajahi Pasar Syariah", "en-US": "Explore Shariah Market" },
  watchlist_title: { "id-ID": "Pantauan", "en-US": "Watchlist" },
  search_placeholder: { "id-ID": "Cari produk investasi syariah...", "en-US": "Search Shariah investment products..." },
  no_results: { "id-ID": "Tidak ada hasil", "en-US": "No results" },
  // Explore table columns
  col_product_name: { "id-ID": "NAMA PRODUK", "en-US": "PRODUCT NAME" },
  col_buy_price: { "id-ID": "HARGA BELI", "en-US": "BUY PRICE" },
  col_sell_price: { "id-ID": "HARGA JUAL", "en-US": "SELL PRICE" },
  col_last_price: { "id-ID": "HARGA TERAKHIR", "en-US": "LAST PRICE" },
  col_lowest_price: { "id-ID": "HARGA TERENDAH", "en-US": "LOWEST PRICE" },
  col_highest_price: { "id-ID": "HARGA TERTINGGI", "en-US": "HIGHEST PRICE" },
  // Watchlist columns
  col_ticker: { "id-ID": "Kode", "en-US": "Ticker" },
  col_last: { "id-ID": "Terakhir", "en-US": "Last" },
  col_change_pct: { "id-ID": "Perubahan(%)", "en-US": "Chg(%)" },
  col_volume: { "id-ID": "Volume", "en-US": "Volume" },
  // Research page labels
  label_shariah: { "id-ID": "Syariah", "en-US": "Shariah Compliant" },
  // Toasts
  toast_saved_title: { "id-ID": "Tersimpan", "en-US": "Saved" },
  toast_saved_desc: { "id-ID": "Perubahan berhasil disimpan.", "en-US": "Changes have been saved successfully." },
  // AI Features
  ai_search_title: { "id-ID": "Pencarian Bertenaga AI", "en-US": "AI-Powered Search" },
  ai_search_placeholder: { "id-ID": "Tanya AI tentang saham, sektor, atau tren pasar (cth: 'Analisis ASII', 'Saham teknologi halal terbaik')", "en-US": "Ask AI about stocks, sectors, or market trends (e.g., 'Analyze ASII', 'Best halal tech stocks')" },
  ai_recommendations: { "id-ID": "Rekomendasi AI", "en-US": "AI Recommendations" },
  ai_powered: { "id-ID": "Bertenaga AI", "en-US": "AI Powered" },
  timeframe_daily: { "id-ID": "Harian", "en-US": "Daily" },
  timeframe_weekly: { "id-ID": "Mingguan", "en-US": "Weekly" },
  timeframe_monthly: { "id-ID": "Bulanan", "en-US": "Monthly" },
  // AI Assistant
  ai_assistant_title: { "id-ID": "AI Assistant", "en-US": "AI Assistant" },
  ai_assistant_desc: { "id-ID": "Chat langsung dengan AI untuk konsultasi investasi syariah", "en-US": "Chat directly with AI for Shariah investment consultation" },
  chat_button: { "id-ID": "Chat", "en-US": "Chat" },
  // Market Mode
  market_mode_title: { "id-ID": "Market Mode", "en-US": "Market Mode" },
  market_indonesia: { "id-ID": "🇮🇩 Pasar Indonesia", "en-US": "🇮🇩 Indonesia Market" },
  market_us: { "id-ID": "🇺🇸 Pasar AS", "en-US": "🇺🇸 US Market" },
  smart_search: { "id-ID": "Pencarian Cerdas", "en-US": "Smart Search" },
  search_placeholder_detailed: { "id-ID": "Cari saham, sektor, atau analisis pasar (cth: 'ASII', 'saham teknologi halal')", "en-US": "Search stocks, sectors, or market analysis (e.g., 'AAPL', 'halal tech stocks')" },
  // AI Chatbot
  ai_analyst_title: { "id-ID": "Analis Investasi AI", "en-US": "AI Investment Analyst" },
  ai_analyst_subtitle: { "id-ID": "Analisis pasar profesional & wawasan", "en-US": "Professional market analysis & insights" },
  chatbot_placeholder: { "id-ID": "Tanya tentang analisis saham, kondisi pasar, atau kepatuhan Syariah...", "en-US": "Ask about any stock analysis, market conditions, or Shariah compliance..." },
  technical_analysis: { "id-ID": "Analisis Teknikal", "en-US": "Technical Analysis" },
  fundamental_data: { "id-ID": "Data Fundamental", "en-US": "Fundamental Data" },
  macro_factors: { "id-ID": "Faktor Makro", "en-US": "Macro Factors" },
  risk_assessment: { "id-ID": "Penilaian Risiko", "en-US": "Risk Assessment" },
  // Market News
  market_news: { "id-ID": "Berita Pasar", "en-US": "Market News" },
  news_source: { "id-ID": "Sumber", "en-US": "Source" },
  // Subscription
  upgrade_prompt: { "id-ID": "Tingkatkan ke Premium untuk fitur lengkap", "en-US": "Upgrade to Premium for full features" },
  upgrade_button: { "id-ID": "Tingkatkan", "en-US": "Upgrade" },
  // Theme
  theme_light: { "id-ID": "Mode Terang", "en-US": "Light Mode" },
  theme_dark: { "id-ID": "Mode Gelap", "en-US": "Dark Mode" },
  theme_system: { "id-ID": "Sistem", "en-US": "System" },
  // Status Messages
  success: { "id-ID": "Berhasil", "en-US": "Success" },
  error: { "id-ID": "Kesalahan", "en-US": "Error" },
  warning: { "id-ID": "Peringatan", "en-US": "Warning" },
  info: { "id-ID": "Informasi", "en-US": "Information" },
}

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: keyof typeof DICTIONARY) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("id-ID")
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    const stored = (localStorage.getItem("language") as Language) || "id-ID"
    setLanguage(stored)
    document.documentElement.setAttribute("lang", stored)
  }, [])

  useEffect(() => {
    if (isClient) {
      localStorage.setItem("language", language)
      document.documentElement.setAttribute("lang", language)
    }
  }, [language, isClient])

  const t = (key: keyof typeof DICTIONARY) => {
    if (!DICTIONARY[key]) return key
    return DICTIONARY[key][language] || key
  }

  const value = useMemo(() => ({ language, setLanguage, t }), [language])

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const ctx = useContext(LanguageContext)
  if (!ctx) throw new Error("useLanguage must be used within LanguageProvider")
  return ctx
}


