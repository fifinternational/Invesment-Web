"use client"

import type React from "react"
import { createContext, useContext, useEffect, useMemo, useState } from "react"

type Currency = "IDR" | "USD"

interface CurrencyContextType {
  currency: Currency
  setCurrency: (cur: Currency) => void
  format: (value: number) => string
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined)

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currency, setCurrency] = useState<Currency>("IDR")
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    const stored = (localStorage.getItem("currency") as Currency) || "IDR"
    setCurrency(stored)
  }, [])

  useEffect(() => {
    if (isClient) {
      localStorage.setItem("currency", currency)
    }
  }, [currency, isClient])

  const format = (value: number) => {
    try {
      return new Intl.NumberFormat(currency === "IDR" ? "id-ID" : "en-US", {
        style: "currency",
        currency,
        maximumFractionDigits: currency === "IDR" ? 0 : 2,
      }).format(value)
    } catch (error) {
      // Fallback formatting if locale is not available
      const symbol = currency === "IDR" ? "Rp " : "$"
      return `${symbol}${value.toLocaleString()}`
    }
  }

  const value = useMemo(() => ({ currency, setCurrency, format }), [currency, isClient])
  return <CurrencyContext.Provider value={value}>{children}</CurrencyContext.Provider>
}

export function useCurrency() {
  const ctx = useContext(CurrencyContext)
  if (!ctx) throw new Error("useCurrency must be used within CurrencyProvider")
  return ctx
}


