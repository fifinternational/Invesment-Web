"use client"

import type React from "react"
import { createContext, useContext, useEffect, useMemo, useState } from "react"
import { useCurrency } from "./currency-context"

type SubscriptionTier = "trial" | "basic" | "premium"

interface SubscriptionContextType {
  subscriptionTier: SubscriptionTier
  setSubscriptionTier: (tier: SubscriptionTier) => void
  isFeatureAvailable: (feature: string) => boolean
  getPricing: () => { basic: string; premium: string }
  trialDaysLeft: number
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined)

export function SubscriptionProvider({ children }: { children: React.ReactNode }) {
  const [subscriptionTier, setSubscriptionTier] = useState<SubscriptionTier>("trial")
  const [trialDaysLeft, setTrialDaysLeft] = useState(7)
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    // Developer access - set to basic tier for development
    const stored = (localStorage.getItem("subscriptionTier") as SubscriptionTier) || "basic"
    const storedTrialDays = parseInt(localStorage.getItem("trialDaysLeft") || "7")
    setSubscriptionTier(stored)
    setTrialDaysLeft(storedTrialDays)
  }, [])

  useEffect(() => {
    if (isClient) {
      localStorage.setItem("subscriptionTier", subscriptionTier)
      localStorage.setItem("trialDaysLeft", trialDaysLeft.toString())
    }
  }, [subscriptionTier, trialDaysLeft, isClient])

  const isFeatureAvailable = (feature: string) => {
    const featureMap = {
      trial: ["basic_dashboard", "basic_search", "limited_watchlist"],
      basic: ["basic_dashboard", "basic_search", "ai_recommendations", "ai_chat", "full_watchlist", "market_analysis"],
      premium: ["basic_dashboard", "basic_search", "ai_recommendations", "ai_chat", "full_watchlist", "market_analysis", "professional_reports", "advanced_analytics", "priority_support"],
    }
    return featureMap[subscriptionTier].includes(feature)
  }

  const getPricing = () => {
    // Get currency context to determine pricing
    return {
      basic: "$3/month", // Will be converted to Rp 45,000 for Indonesia
      premium: "$9/month" // Will be converted to Rp 135,000 for Indonesia
    }
  }

  const value = useMemo(() => ({ 
    subscriptionTier, 
    setSubscriptionTier, 
    isFeatureAvailable, 
    getPricing,
    trialDaysLeft 
  }), [subscriptionTier, trialDaysLeft])

  return <SubscriptionContext.Provider value={value}>{children}</SubscriptionContext.Provider>
}

export function useSubscription() {
  const ctx = useContext(SubscriptionContext)
  if (!ctx) throw new Error("useSubscription must be used within SubscriptionProvider")
  return ctx
}



