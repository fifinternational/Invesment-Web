import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  
  // Skip middleware for static files, API routes, and auth-related routes
  if (pathname.startsWith('/_next') || 
      pathname.startsWith('/api') || 
      pathname.startsWith('/auth') ||
      pathname === '/terms' ||
      pathname === '/privacy' ||
      pathname.includes('.')) {
    return NextResponse.next()
  }

  // COMPLETELY DISABLE AUTHENTICATION - Allow all routes
  return NextResponse.next()
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
}
