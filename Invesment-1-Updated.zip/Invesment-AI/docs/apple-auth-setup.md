# Setup Apple Authentication di Supabase

## Langkah-langkah Setup Apple Sign In

### 1. Apple Developer Account Setup
1. Masuk ke [Apple Developer Console](https://developer.apple.com/account/)
2. Buat **App ID** baru atau gunakan yang sudah ada
3. Enable **Sign In with Apple** capability

### 2. Konfigurasi Service ID
1. Buat **Services ID** baru di Apple Developer
2. Configure **Sign In with Apple** untuk Service ID
3. Tambahkan domain dan return URLs:
   - **Domains**: `wjytrukntveejoebolfn.supabase.co`
   - **Return URLs**: `https://wjytrukntveejoebolfn.supabase.co/auth/v1/callback`

### 3. Generate Private Key
1. Buat **Key** baru di Apple Developer
2. Enable **Sign In with Apple**
3. Download file `.p8` private key
4. Catat **Key ID** dan **Team ID**

### 4. Supabase Configuration
1. Masuk ke Supabase Dashboard
2. Go to **Authentication > Providers**
3. Enable **Apple** provider
4. Masukkan konfigurasi:
   - **Client ID**: Service ID yang dibuat
   - **Secret**: Generate dari private key
   - **Team ID**: dari Apple Developer
   - **Key ID**: dari private key

### 5. Generate Apple Secret
Gunakan script berikut untuk generate secret dari private key:

```javascript
const jwt = require('jsonwebtoken');
const fs = require('fs');

const privateKey = fs.readFileSync('path/to/AuthKey_XXXXXXXXXX.p8');
const teamId = 'YOUR_TEAM_ID';
const clientId = 'YOUR_SERVICE_ID';
const keyId = 'YOUR_KEY_ID';

const secret = jwt.sign({
  iss: teamId,
  iat: Math.floor(Date.now() / 1000),
  exp: Math.floor(Date.now() / 1000) + (86400 * 180), // 6 months
  aud: 'https://appleid.apple.com',
  sub: clientId,
}, privateKey, {
  algorithm: 'ES256',
  header: {
    kid: keyId,
  }
});

console.log(secret);
```

### 6. Frontend Implementation
Gunakan Supabase client untuk Apple login:

```typescript
const { data, error } = await supabase.auth.signInWithOAuth({
  provider: 'apple',
  options: {
    redirectTo: `${window.location.origin}/auth/callback`
  }
})
```

### 7. Testing
1. Test di development dengan localhost
2. Deploy ke production untuk test penuh
3. Pastikan redirect URLs sesuai

## Catatan Penting
- Apple Sign In hanya bekerja di HTTPS (production)
- Untuk development, gunakan ngrok atau deploy ke staging
- Private key harus disimpan aman dan tidak di-commit ke git
