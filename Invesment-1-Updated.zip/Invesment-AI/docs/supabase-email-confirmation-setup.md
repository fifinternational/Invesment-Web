# Supabase Email Confirmation Setup

## 1. Konfigurasi di Supabase Dashboard

### A. Authentication Settings
1. Buka Supabase Dashboard: https://supabase.com/dashboard
2. Pilih project Anda
3. Masuk ke **Authentication** > **Settings**

### B. Email Confirmation Settings
1. Di bagian **Email**, pastikan:
   - ✅ **Enable email confirmations** = ON
   - ✅ **Confirm email on signup** = ON
   - ✅ **Secure email change** = ON (opsional)

### C. Email Templates
1. Masuk ke **Authentication** > **Email Templates**
2. Edit template **Confirm signup**:
```html
<h2>Konfirmasi Email Anda</h2>
<p>Terima kasih telah mendaftar di Platform Investasi Syariah AI!</p>
<p>Klik tombol di bawah untuk mengkonfirmasi email Anda:</p>
<p><a href="{{ .ConfirmationURL }}">Konfirmasi Email</a></p>
<p>Atau copy link ini ke browser: {{ .ConfirmationURL }}</p>
```

### D. Redirect URLs
1. Di **Authentication** > **URL Configuration**
2. Tambahkan redirect URLs:
```
http://localhost:3000/auth/callback
http://localhost:3000/auth/confirm
https://yourdomain.com/auth/callback
https://yourdomain.com/auth/confirm
```

## 2. Google OAuth Configuration

### A. Google Cloud Console
1. Buka Google Cloud Console
2. Pilih project atau buat baru
3. Enable Google+ API
4. Di **Credentials** > **OAuth 2.0 Client IDs**
5. Tambahkan Authorized redirect URIs:
```
https://wjytrukntveejoebolfn.supabase.co/auth/v1/callback
http://localhost:3000/auth/callback
```

### B. Supabase Google Provider
1. Di Supabase Dashboard > **Authentication** > **Providers**
2. Enable **Google**
3. Masukkan:
   - Client ID: dari Google Cloud Console
   - Client Secret: dari Google Cloud Console

## 3. Environment Variables

Update file `.env.local`:
```env
# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=https://wjytrukntveejoebolfn.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndqeXRydWtudHZlZWpvZWJvbGZuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY3MDY0NjEsImV4cCI6MjA3MjI4MjQ2MX0._ITCA63E8oJLm3MzOyl2MXq4zi4IkEy5MHS3KMoTJ54

# Google OAuth Configuration  
NEXT_PUBLIC_GOOGLE_CLIENT_ID=987128194245-hk3kiu94o407laro6acrqhf56s2gtc35.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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

# Site URL for redirects
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

## 4. Flow Autentikasi

### A. Signup Flow
1. User klik "Sign up with Google"
2. Google OAuth redirect
3. Supabase creates user account
4. Email konfirmasi dikirim
5. User klik link konfirmasi di email
6. Redirect ke dashboard

### B. Login Flow  
1. User klik "Login with Google"
2. Google OAuth redirect
3. Jika email sudah dikonfirmasi → redirect ke dashboard
4. Jika belum dikonfirmasi → tampilkan pesan "Check your email"

## 5. Testing

### A. Test Signup
1. Gunakan email yang belum pernah digunakan
2. Signup dengan Google
3. Check email untuk link konfirmasi
4. Klik link konfirmasi
5. Verify redirect ke dashboard

### B. Test Login
1. Gunakan email yang sudah dikonfirmasi
2. Login dengan Google
3. Verify langsung masuk dashboard

## 6. Troubleshooting

### A. Email tidak terkirim
- Check spam folder
- Verify SMTP settings di Supabase
- Check email template configuration

### B. Redirect error
- Verify redirect URLs di Google Console
- Check Supabase URL configuration
- Ensure callback routes exist

### C. Authentication error
- Check environment variables
- Verify Google Client ID/Secret
- Check Supabase project credentials
