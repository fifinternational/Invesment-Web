# Environment Variables Setup

## 1. Buat File .env.local

Buat file `.env.local` di root project dengan content berikut:

```env
# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=https://fpaclekcbrydyyywpj.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZwYWNsZWtjYnJ5ZHl5eXdwaiIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzA0MzY3NTk5LCJleHAiOjIwMTk5NDM1OTl9.Nh0Vy3GRrFhbXbGYSxXaXwi-KwHXJQRNGMgkH-JdPQM

# Google OAuth Configuration
NEXT_PUBLIC_GOOGLE_CLIENT_ID=987128194245-hk3kiu94o407laro6acrqhf56s2gtc35.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
```

## 2. Restart Development Server

Setelah membuat file `.env.local`, restart server:

```bash
# Stop server (Ctrl+C)
# Then restart
npm run dev
```

## 3. Keamanan

⚠️ **PENTING:** 
- File `.env.local` sudah di-gitignore untuk keamanan
- Jangan commit credentials ke Git
- Gunakan environment variables yang berbeda untuk production

## 4. Production Environment

Untuk production di Netlify/Vercel:
- Set environment variables di dashboard hosting
- Gunakan production URLs untuk redirect URIs
- Generate production-specific secrets
