# Setup Supabase Project Baru

## Masalah DNS
URL lama `fpaclekcbrydyyywpj.supabase.co` tidak dapat diakses (DNS_PROBE_FINISHED_NXDOMAIN).

## Solusi: Buat Project Baru

### 1. Buat Project Supabase Baru
1. Buka https://supabase.com/dashboard
2. Klik "New Project"
3. Organization: "fifinternational's Org"
4. Nama: "Islamic Investment Platform"
5. Database Password: [buat password kuat]
6. Region: Asia Southeast (Singapore)
7. Klik "Create new project"

### 2. Dapatkan Credentials Baru
Setelah project selesai dibuat:
1. Pergi ke Settings > API
2. Copy:
   - Project URL
   - anon/public key

### 3. Update .env.local
```env
NEXT_PUBLIC_SUPABASE_URL=[URL_BARU_DARI_STEP_2]
NEXT_PUBLIC_SUPABASE_ANON_KEY=[ANON_KEY_BARU_DARI_STEP_2]
NEXT_PUBLIC_GOOGLE_CLIENT_ID=987128194245-hk3kiu94o407laro6acrqhf56s2gtc35.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
PORT=3001
```

### 4. Konfigurasi Google Provider
1. Authentication > Providers
2. Enable Google
3. Client ID: 987128194245-hk3kiu94o407laro6acrqhf56s2gtc35.apps.googleusercontent.com
4. Client Secret: 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

### 5. Site URL Configuration
1. Authentication > Settings
2. Site URL: http://localhost:3001
3. Redirect URLs: http://localhost:3001/auth/callback

### 6. Update Google Cloud Console
Update redirect URIs dengan URL Supabase yang baru:
```
http://localhost:3001/auth/callback
https://[NEW_SUPABASE_URL]/auth/v1/callback
```
