# Payment Integration Guide

## Overview
Integrasi pembayaran untuk platform investasi syariah dengan dua metode:
- **Midtrans**: Untuk pembayaran lokal Indonesia (Rupiah)
- **PayPal**: Untuk pembayaran internasional (USD)

## 1. Midtrans Integration (Indonesia)

### Prerequisites
1. Daftar akun Midtrans di [https://midtrans.com](https://midtrans.com)
2. Dapatkan Server Key dan Client Key dari dashboard Midtrans
3. Install package yang diperlukan

### Installation
```bash
npm install midtrans-client
```

### Environment Variables
Tambahkan ke `.env.local`:
```env
MIDTRANS_SERVER_KEY=your_server_key_here
MIDTRANS_CLIENT_KEY=your_client_key_here
MIDTRANS_IS_PRODUCTION=false
```

### Backend API Route
Buat file `/app/api/midtrans/token/route.ts`:

```typescript
import { NextRequest, NextResponse } from 'next/server'
import midtransClient from 'midtrans-client'

const snap = new midtransClient.Snap({
  isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
  serverKey: process.env.MIDTRANS_SERVER_KEY!,
  clientKey: process.env.MIDTRANS_CLIENT_KEY!
})

export async function POST(request: NextRequest) {
  try {
    const { orderId, amount, customerDetails } = await request.json()

    const parameter = {
      transaction_details: {
        order_id: orderId,
        gross_amount: amount
      },
      customer_details: customerDetails,
      credit_card: {
        secure: true
      }
    }

    const transaction = await snap.createTransaction(parameter)
    
    return NextResponse.json({
      token: transaction.token,
      redirect_url: transaction.redirect_url
    })
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to create transaction' },
      { status: 500 }
    )
  }
}
```

### Frontend Component
Buat file `/components/payments/MidtransButton.tsx`:

```typescript
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'

interface MidtransButtonProps {
  amount: number
  orderId: string
  customerDetails: {
    first_name: string
    last_name: string
    email: string
    phone: string
  }
  onSuccess: () => void
}

export default function MidtransButton({
  amount,
  orderId,
  customerDetails,
  onSuccess
}: MidtransButtonProps) {
  const [loading, setLoading] = useState(false)

  const handlePayment = async () => {
    setLoading(true)
    
    try {
      const response = await fetch('/api/midtrans/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          orderId,
          amount,
          customerDetails
        })
      })

      const data = await response.json()
      
      if (data.token) {
        // Load Midtrans Snap
        const script = document.createElement('script')
        script.src = 'https://app.sandbox.midtrans.com/snap/snap.js'
        script.setAttribute('data-client-key', process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY!)
        document.head.appendChild(script)

        script.onload = () => {
          // @ts-ignore
          window.snap.pay(data.token, {
            onSuccess: (result: any) => {
              toast.success('Pembayaran berhasil!')
              onSuccess()
            },
            onPending: (result: any) => {
              toast.info('Pembayaran pending, silakan selesaikan pembayaran')
            },
            onError: (result: any) => {
              toast.error('Pembayaran gagal')
            },
            onClose: () => {
              toast.info('Pembayaran dibatalkan')
            }
          })
        }
      }
    } catch (error) {
      toast.error('Gagal memproses pembayaran')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Button 
      onClick={handlePayment} 
      disabled={loading}
      className="w-full bg-blue-600 hover:bg-blue-700"
    >
      {loading ? 'Memproses...' : 'Bayar dengan Midtrans'}
    </Button>
  )
}
```

## 2. PayPal Integration (International)

### Prerequisites
1. Daftar PayPal Developer Account di [https://developer.paypal.com](https://developer.paypal.com)
2. Buat aplikasi dan dapatkan Client ID dan Client Secret
3. Install package yang diperlukan

### Installation
```bash
npm install @paypal/react-paypal-js
```

### Environment Variables
Tambahkan ke `.env.local`:
```env
NEXT_PUBLIC_PAYPAL_CLIENT_ID=your_paypal_client_id_here
PAYPAL_CLIENT_SECRET=your_paypal_client_secret_here
```

### PayPal Provider Setup
Update `/app/layout.tsx`:

```typescript
import { PayPalScriptProvider } from '@paypal/react-paypal-js'

const paypalOptions = {
  "client-id": process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID!,
  currency: "USD",
  intent: "capture"
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <PayPalScriptProvider options={paypalOptions}>
          {children}
        </PayPalScriptProvider>
      </body>
    </html>
  )
}
```

### Enhanced PayPal Component
Update `/components/payments/PayPalButton.tsx`:

```typescript
'use client'

import { PayPalButtons } from '@paypal/react-paypal-js'
import { toast } from 'sonner'

interface PayPalButtonProps {
  amount: string
  onApproved: () => void
}

export default function PayPalButton({ amount, onApproved }: PayPalButtonProps) {
  return (
    <PayPalButtons
      style={{
        layout: 'vertical',
        color: 'blue',
        shape: 'rect',
        label: 'paypal'
      }}
      createOrder={(data, actions) => {
        return actions.order.create({
          purchase_units: [{
            amount: {
              value: amount,
              currency_code: 'USD'
            }
          }]
        })
      }}
      onApprove={async (data, actions) => {
        try {
          const details = await actions.order!.capture()
          toast.success('Payment successful!')
          onApproved()
        } catch (error) {
          toast.error('Payment failed')
        }
      }}
      onError={(err) => {
        toast.error('PayPal error occurred')
        console.error('PayPal error:', err)
      }}
      onCancel={() => {
        toast.info('Payment cancelled')
      }}
    />
  )
}
```

## 3. Integration in Subscription Page

Update subscription page untuk menggunakan kedua metode pembayaran:

```typescript
// Di dalam komponen SubscribePage
{selectedPlan && selectedPlan !== "free" && (
  <Card className="max-w-md mx-auto">
    <CardHeader className="text-center">
      <CardTitle>
        {language === 'id-ID' ? "Pembayaran Aman" : "Secure Payment"}
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className="text-center mb-4">
        <div className="text-2xl font-bold">
          {language === 'en-US' 
            ? `$${selectedPlan === "basic" ? 6 : 12}`
            : `Rp ${(selectedPlan === "basic" ? 6 * 15000 : 12 * 15000).toLocaleString('id-ID')}`
          }
          <span className="text-sm text-muted-foreground font-normal">
            {language === 'id-ID' ? "/bulan" : "/month"}
          </span>
        </div>
      </div>
      
      {language === 'id-ID' ? (
        // Indonesian users - Midtrans
        <MidtransButton
          amount={selectedPlan === "basic" ? 90000 : 180000}
          orderId={`order-${Date.now()}`}
          customerDetails={{
            first_name: "User",
            last_name: "Name",
            email: "user@example.com",
            phone: "08123456789"
          }}
          onSuccess={() => {
            activatePro()
            toast.success("Pembayaran berhasil! Paket telah diaktifkan!")
            setSelectedPlan(null)
          }}
        />
      ) : (
        // International users - PayPal
        <PayPalButton
          amount={selectedPlan === "basic" ? "6.00" : "12.00"}
          onApproved={() => {
            activatePro()
            toast.success("Payment successful! Plan activated!")
            setSelectedPlan(null)
          }}
        />
      )}
    </CardContent>
  </Card>
)}
```

## 4. Webhook Handling (Optional)

### Midtrans Webhook
Buat `/app/api/midtrans/webhook/route.ts`:

```typescript
import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Verify signature
    const serverKey = process.env.MIDTRANS_SERVER_KEY!
    const orderId = body.order_id
    const statusCode = body.status_code
    const grossAmount = body.gross_amount
    
    const signatureKey = crypto
      .createHash('sha512')
      .update(orderId + statusCode + grossAmount + serverKey)
      .digest('hex')
    
    if (signatureKey !== body.signature_key) {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
    }
    
    // Handle payment status
    if (body.transaction_status === 'capture' || body.transaction_status === 'settlement') {
      // Payment successful - activate subscription
      console.log('Payment successful for order:', orderId)
    }
    
    return NextResponse.json({ status: 'ok' })
  } catch (error) {
    return NextResponse.json({ error: 'Webhook error' }, { status: 500 })
  }
}
```

## 5. Testing

### Midtrans Test Cards
- **Visa**: 4811 1111 1111 1114
- **Mastercard**: 5264 2210 3887 4659
- **CVV**: 123
- **Expiry**: 01/25

### PayPal Test Account
Gunakan PayPal Sandbox untuk testing dengan akun test yang disediakan PayPal.

## 6. Production Deployment

1. **Midtrans**: Ubah `MIDTRANS_IS_PRODUCTION=true` dan gunakan production keys
2. **PayPal**: Ganti client ID dengan production client ID
3. **Webhook URLs**: Set webhook URLs di dashboard masing-masing payment provider

## Security Notes

1. Jangan expose Server Key di frontend
2. Selalu validasi signature untuk webhook
3. Gunakan HTTPS untuk production
4. Implement proper error handling dan logging
