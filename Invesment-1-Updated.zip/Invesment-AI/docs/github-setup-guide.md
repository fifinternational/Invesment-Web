# GitHub Setup Guide

## 🔐 Authentication Setup

### Option 1: GitHub CLI (Recommended)
```bash
# Install GitHub CLI
brew install gh

# Login to GitHub
gh auth login

# Select GitHub.com
# Select HTTPS
# Authenticate in browser

# Push to repository
git push -u origin main
```

### Option 2: Personal Access Token
1. **Generate Token:**
   - Go to GitHub.com → Settings → Developer settings
   - Personal access tokens → Tokens (classic)
   - Generate new token
   - Select scopes: `repo`, `workflow`
   - Copy the token

2. **Use Token:**
```bash
# Set remote with token
git remote set-url origin https://YOUR_TOKEN@github.com/fifinternational/Invesment-AI.git

# Push to repository
git push -u origin main
```

### Option 3: SSH Key
```bash
# Generate SSH key
ssh-keygen -t ed25519 -C "your_email@example.com"

# Add to SSH agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519

# Copy public key
cat ~/.ssh/id_ed25519.pub

# Add to GitHub: Settings → SSH and GPG keys → New SSH key

# Change remote to SSH
git remote set-url origin git@github.com:fifinternational/Invesment-AI.git

# Push to repository
git push -u origin main
```

## 📋 Current Status
- ✅ Git repository initialized
- ✅ Files committed locally
- ✅ Remote origin set
- ❌ Authentication needed for push

## 🚀 Next Steps
1. Choose authentication method above
2. Complete authentication setup
3. Push code to GitHub
4. Set up deployment from GitHub

## 📁 Repository Structure
```
Invesment-AI/
├── app/                    # Next.js app directory
├── components/             # React components
├── contexts/              # React contexts
├── docs/                  # Documentation
├── hooks/                 # Custom hooks
├── lib/                   # Utilities
├── public/                # Static assets
├── styles/                # CSS styles
├── types/                 # TypeScript types
├── utils/                 # Helper functions
├── package.json           # Dependencies
├── next.config.mjs        # Next.js config
└── README.md              # Project documentation
```
