# Setup Google Authentication

## 1. Google Cloud Console Setup

### Langkah 1: Buat OAuth 2.0 Credentials
1. Buka Google Cloud Console (console.cloud.google.com)
2. Pilih project Anda: `noted-extension-391006`
3. Pergi ke **APIs & Services** > **Credentials**
4. Klik **+ CREATE CREDENTIALS** > **OAuth client ID**
5. Pilih **Web application**
6. Isi nama: "Islamic Investment Platform"

### Langkah 2: Konfigurasi Authorized URLs
**Authorized JavaScript origins:**
```
http://localhost:3001
https://your-app.netlify.app (untuk production gratis)
```

**Authorized redirect URIs:**
```
http://localhost:3001/auth/callback
https://your-app.netlify.app/auth/callback (untuk production gratis)
https://fpaclekcbrydyyywpj.supabase.co/auth/v1/callback
```

**CATATAN:** Anda TIDAK perlu membeli domain! Gunakan localhost untuk development dan subdomain gratis (Netlify/Vercel) untuk production.

### Langkah 3: Dapatkan Client ID dan Client Secret
- Simpan **Client ID** dan **Client Secret** yang dihasilkan

## 2. Supabase Dashboard Setup

### Langkah 1: Buka Supabase Dashboard
1. Login ke https://supabase.com/dashboard
2. Pilih project Anda
3. Pergi ke **Authentication** > **Providers**

### Langkah 2: Enable Google Provider
1. Cari **Google** dalam daftar providers
2. Toggle **Enable sign in with Google**
3. Masukkan:
   - **Client ID** dari Google Cloud Console
   - **Client Secret** dari Google Cloud Console
4. Klik **Save**

### Langkah 3: Konfigurasi Site URL
1. Pergi ke **Authentication** > **Settings**
2. Set **Site URL**: `http://localhost:3001` (untuk development)
3. Tambahkan **Redirect URLs**:
   ```
   http://localhost:3001/auth/callback
   https://your-app.netlify.app/auth/callback (untuk production gratis)
   ```

## 3. Environment Variables

Tambahkan ke file `.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://fpaclekcbrydyyywpj.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
NEXT_PUBLIC_GOOGLE_CLIENT_ID=your_google_client_id_here
```

## 4. Testing

1. Jalankan aplikasi: `npm run dev`
2. Buka http://localhost:3000/login
3. Klik tombol "Login with Google"
4. Harus redirect ke Google OAuth
5. Setelah authorize, redirect kembali ke aplikasi

## Troubleshooting

### Error: "redirect_uri_mismatch"
- Pastikan redirect URI di Google Console sama persis dengan yang digunakan
- Periksa http vs https
- Periksa trailing slash

### Error: "Invalid client"
- Periksa Client ID dan Client Secret
- Pastikan Google OAuth API enabled

### Error: "Access blocked"
- Tambahkan domain ke authorized origins
- Periksa OAuth consent screen configuration
