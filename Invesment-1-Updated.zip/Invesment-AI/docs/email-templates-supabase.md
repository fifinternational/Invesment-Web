# Email Templates untuk Supabase - AI Shariah Investment Research

## 1. Email Konfirmasi Signup

### Template HTML untuk Supabase Dashboard

```html
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Email - AI Shariah Investment Research</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f8fafc;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        .logo {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .subtitle {
            font-size: 16px;
            opacity: 0.9;
            margin: 0;
        }
        .content {
            padding: 40px 30px;
        }
        .welcome-text {
            font-size: 24px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
            text-align: center;
        }
        .description {
            font-size: 16px;
            color: #64748b;
            margin-bottom: 30px;
            text-align: center;
            line-height: 1.7;
        }
        .confirm-button {
            display: block;
            width: 280px;
            margin: 30px auto;
            padding: 16px 24px;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 16px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
            transition: all 0.3s ease;
        }
        .confirm-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(16, 185, 129, 0.4);
        }
        .features {
            background-color: #f8fafc;
            padding: 30px;
            margin: 30px 0;
            border-radius: 8px;
            border-left: 4px solid #3b82f6;
        }
        .features h3 {
            color: #1e293b;
            margin-bottom: 15px;
            font-size: 18px;
        }
        .feature-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .feature-list li {
            padding: 8px 0;
            color: #64748b;
            position: relative;
            padding-left: 25px;
        }
        .feature-list li:before {
            content: "✓";
            position: absolute;
            left: 0;
            color: #10b981;
            font-weight: bold;
        }
        .footer {
            background-color: #1e293b;
            color: #94a3b8;
            padding: 30px;
            text-align: center;
            font-size: 14px;
        }
        .footer-links {
            margin-top: 20px;
        }
        .footer-links a {
            color: #60a5fa;
            text-decoration: none;
            margin: 0 15px;
        }
        .alternative-link {
            margin-top: 30px;
            padding: 20px;
            background-color: #fef3c7;
            border-radius: 8px;
            border-left: 4px solid #f59e0b;
        }
        .alternative-link p {
            margin: 0;
            font-size: 14px;
            color: #92400e;
        }
        .alternative-link code {
            background-color: #fbbf24;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
            word-break: break-all;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">
                <div style="display: flex; align-items: center; justify-content: center; gap: 12px;">
                    <div style="width: 48px; height: 48px; background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; color: #3b82f6; font-weight: bold; box-shadow: 0 4px 14px 0 rgba(255, 255, 255, 0.3);">BB</div>
                    <span style="font-size: 28px; font-weight: bold;">BlubBlub</span>
                </div>
            </div>
            <p class="subtitle">AI Shariah Investment Research Platform</p>
        </div>
        
        <div class="content">
            <h1 class="welcome-text">Selamat Bergabung dengan BlubBlub! 🎉</h1>
            
            <p class="description">
                Terima kasih telah mempercayai <strong>BlubBlub Financial Technology</strong> sebagai mitra investasi syariah Anda. 
                Untuk mengaktifkan akun dan mengakses platform riset investasi berbasis AI kami, 
                silakan konfirmasi alamat email Anda dengan mengklik tombol di bawah ini.
            </p>
            
            <a href="{{ .ConfirmationURL }}" class="confirm-button">
                ✅ Konfirmasi Email Saya
            </a>
            
            <div class="features">
                <h3>🚀 Akses Eksklusif Platform BlubBlub:</h3>
                <ul class="feature-list">
                    <li>AI Investment Assistant - Konsultasi investasi syariah 24/7</li>
                    <li>Smart Analytics - Analisis mendalam saham halal</li>
                    <li>Portfolio Optimizer - Rekomendasi portofolio syariah</li>
                    <li>Real-time Market Data - Pasar Indonesia dan AS</li>
                    <li>Shariah Compliance - 100% sesuai prinsip syariah</li>
                </ul>
            </div>
            
            <div class="alternative-link">
                <p><strong>Tidak bisa mengklik tombol?</strong></p>
                <p>Copy dan paste link berikut ke browser Anda:</p>
                <code>{{ .ConfirmationURL }}</code>
            </div>
        </div>
        
        <div class="footer">
            <p><strong>BlubBlub Financial Technology</strong></p>
            <p>&copy; 2025 BlubBlub Financial Technology. Semua hak dilindungi undang-undang.</p>
            <p>Platform Riset Investasi Syariah Berbasis AI Terdepan di Indonesia</p>
            <div class="footer-links">
                <a href="#">Kebijakan Privasi</a>
                <a href="#">Syarat & Ketentuan</a>
                <a href="#">Bantuan</a>
            </div>
        </div>
    </div>
</body>
</html>
```

## 2. Email Reset Password

### Template HTML untuk Reset Password

```html
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - AI Shariah Investment Research</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f8fafc;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        .logo {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .subtitle {
            font-size: 16px;
            opacity: 0.9;
            margin: 0;
        }
        .content {
            padding: 40px 30px;
        }
        .title {
            font-size: 24px;
            font-weight: 600;
            color: #1e293b;
            margin-bottom: 20px;
            text-align: center;
        }
        .description {
            font-size: 16px;
            color: #64748b;
            margin-bottom: 30px;
            text-align: center;
            line-height: 1.7;
        }
        .reset-button {
            display: block;
            width: 280px;
            margin: 30px auto;
            padding: 16px 24px;
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 16px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }
        .security-notice {
            background-color: #fef3c7;
            padding: 20px;
            margin: 30px 0;
            border-radius: 8px;
            border-left: 4px solid #f59e0b;
        }
        .security-notice h3 {
            color: #92400e;
            margin-bottom: 10px;
            font-size: 16px;
        }
        .security-notice p {
            color: #92400e;
            margin: 5px 0;
            font-size: 14px;
        }
        .footer {
            background-color: #1e293b;
            color: #94a3b8;
            padding: 30px;
            text-align: center;
            font-size: 14px;
        }
        .alternative-link {
            margin-top: 30px;
            padding: 20px;
            background-color: #f1f5f9;
            border-radius: 8px;
            border-left: 4px solid #64748b;
        }
        .alternative-link p {
            margin: 0;
            font-size: 14px;
            color: #475569;
        }
        .alternative-link code {
            background-color: #e2e8f0;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
            word-break: break-all;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">
                <div style="display: flex; align-items: center; justify-content: center; gap: 12px;">
                    <div style="width: 48px; height: 48px; background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 24px; color: #ef4444; font-weight: bold; box-shadow: 0 4px 14px 0 rgba(255, 255, 255, 0.3);">BB</div>
                    <span style="font-size: 28px; font-weight: bold;">BlubBlub</span>
                </div>
            </div>
            <p class="subtitle">AI Shariah Investment Research Platform</p>
        </div>
        
        <div class="content">
            <h1 class="title">🔐 Reset Password</h1>
            
            <p class="description">
                Kami menerima permintaan untuk mereset password akun <strong>BlubBlub</strong> Anda. 
                Jika Anda yang melakukan permintaan ini, klik tombol di bawah untuk membuat password baru yang aman.
            </p>
            
            <a href="{{ .ConfirmationURL }}" class="reset-button">
                🔑 Reset Password Saya
            </a>
            
            <div class="security-notice">
                <h3>🛡️ Penting untuk Keamanan:</h3>
                <p>• Link ini akan kedaluwarsa dalam 1 jam</p>
                <p>• Jika Anda tidak meminta reset password, abaikan email ini</p>
                <p>• Jangan bagikan link ini kepada siapa pun</p>
                <p>• Gunakan password yang kuat dengan kombinasi huruf, angka, dan simbol</p>
            </div>
            
            <div class="alternative-link">
                <p><strong>Tidak bisa mengklik tombol?</strong></p>
                <p>Copy dan paste link berikut ke browser Anda:</p>
                <code>{{ .ConfirmationURL }}</code>
            </div>
        </div>
        
        <div class="footer">
            <p><strong>BlubBlub Financial Technology</strong></p>
            <p>&copy; 2025 BlubBlub Financial Technology. Semua hak dilindungi undang-undang.</p>
            <p>Jika Anda membutuhkan bantuan, hubungi tim support kami</p>
        </div>
    </div>
</body>
</html>
```

## 3. Cara Menggunakan Template di Supabase

### Langkah-langkah Setup:

1. **Masuk ke Supabase Dashboard**
   - Buka https://supabase.com/dashboard
   - Pilih project Anda

2. **Konfigurasi Email Confirmation**
   - Masuk ke **Authentication** > **Email Templates**
   - Pilih **Confirm signup**
   - Copy paste template HTML di atas
   - Klik **Save**

3. **Konfigurasi Password Recovery**
   - Masih di **Email Templates**
   - Pilih **Reset password**
   - Copy paste template reset password HTML
   - Klik **Save**

4. **Test Email Templates**
   - Buat akun test baru untuk cek email konfirmasi
   - Gunakan fitur forgot password untuk cek email reset

### Variables yang Tersedia:
- `{{ .ConfirmationURL }}` - Link konfirmasi/reset
- `{{ .Email }}` - Email user
- `{{ .SiteURL }}` - URL website Anda

## 4. Customization Tips

- Ganti warna sesuai brand Anda
- Tambahkan logo perusahaan
- Sesuaikan teks dengan tone brand
- Test di berbagai email client
- Pastikan responsive di mobile
