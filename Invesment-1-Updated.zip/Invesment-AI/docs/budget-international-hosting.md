# Budget International Hosting Guide

## 🌍 Hosting Internasional Murah untuk Next.js

### 1. **Railway.app** ⭐ RECOMMENDED
**Harga:** $5/bulan (Hobby Plan)
- **Free tier:** $5 kredit gratis per bulan
- **Deployment:** Instant dari GitHub
- **Database:** PostgreSQL included
- **Global CDN:** Ya
- **SSL:** Gratis
- **Custom Domain:** Ya

```bash
# Deploy ke Railway
npm install -g @railway/cli
railway login
railway deploy
```

### 2. **Render.com** 
**Harga:** $7/bulan (Starter Plan)
- **Free tier:** 750 jam gratis per bulan
- **Auto-deploy:** Dari Git
- **Database:** PostgreSQL $7/bulan
- **SSL:** Gratis
- **Global locations:** Ya

### 3. **DigitalOcean App Platform**
**Harga:** $5/bulan (Basic Plan)
- **Specs:** 1 vCPU, 512MB RAM
- **Database:** $15/bulan (Managed)
- **CDN:** Gratis
- **Auto-scaling:** Ya
- **Multiple regions:** Ya

### 4. **Netlify**
**Harga:** FREE untuk starter
- **Build minutes:** 300/bulan gratis
- **Bandwidth:** 100GB/bulan
- **Serverless functions:** 125K invocations
- **Custom domain:** Ya
- **SSL:** Gratis

### 5. **Vercel Hobby**
**Harga:** FREE
- **Bandwidth:** 100GB/bulan
- **Serverless functions:** 100GB-hours
- **Custom domain:** Ya
- **Global CDN:** Ya
- **Upgrade:** $20/bulan untuk Pro

### 6. **Firebase Hosting**
**Harga:** FREE (Spark Plan)
- **Storage:** 1GB
- **Transfer:** 10GB/bulan
- **Custom domain:** Ya
- **SSL:** Gratis
- **Global CDN:** Ya

### 7. **Cloudflare Pages**
**Harga:** FREE
- **Build:** 500 builds/bulan
- **Bandwidth:** Unlimited
- **Custom domain:** Ya
- **Global CDN:** Ya
- **Functions:** 100K requests/hari

## 💰 Perbandingan Biaya Total (Per Bulan)

| Platform | Hosting | Database | Domain | Total |
|----------|---------|----------|---------|-------|
| **Railway** | $5 | Included | $1 | **$6** |
| **Netlify** | FREE | $25 | $1 | **$26** |
| **Render** | $7 | $7 | $1 | **$15** |
| **DigitalOcean** | $5 | $15 | $1 | **$21** |
| **Vercel Free** | FREE | $25 | $1 | **$26** |
| **Firebase** | FREE | $25 | $1 | **$26** |
| **Cloudflare** | FREE | $25 | $1 | **$26** |

## 🏆 Rekomendasi Berdasarkan Budget

### **Ultra Budget ($0-6/bulan)**
1. **Railway.app** - $5/bulan all-in-one
2. **Netlify Free** + External DB
3. **Vercel Free** + External DB

### **Budget Menengah ($15-25/bulan)**
1. **Render** - $15/bulan total
2. **DigitalOcean** - $21/bulan total

### **Professional ($50+/bulan)**
1. **Vercel Pro** - $45/bulan total
2. **AWS Amplify** - Variable pricing

## 🚀 Setup Railway (Paling Murah & Lengkap)

### 1. Install CLI
```bash
npm install -g @railway/cli
```

### 2. Login & Deploy
```bash
railway login
railway init
railway up
```

### 3. Environment Variables
```bash
railway variables set MIDTRANS_SERVER_KEY=xxx
railway variables set NEXT_PUBLIC_MIDTRANS_CLIENT_KEY=xxx
railway variables set NEXTAUTH_SECRET=xxx
```

### 4. Database Setup
```bash
# Railway otomatis provide PostgreSQL
railway add postgresql
```

### 5. Custom Domain
1. Railway dashboard → Settings → Domains
2. Add custom domain
3. Update DNS di registrar:
```
CNAME: www → your-app.up.railway.app
A: @ → Railway IP
```

## 🌐 Setup Database Murah

### **Supabase Free Tier**
- **Database:** PostgreSQL gratis
- **Storage:** 500MB
- **API requests:** 50K/bulan
- **Auth:** Unlimited users

### **PlanetScale Free**
- **Database:** MySQL gratis
- **Storage:** 5GB
- **Reads:** 1 billion/bulan
- **Writes:** 10 million/bulan

### **Railway PostgreSQL**
- **Included** dengan hosting plan
- **Storage:** 1GB
- **Connections:** 20

## 📊 Traffic Limits Comparison

| Platform | Bandwidth | Requests | Build Minutes |
|----------|-----------|----------|---------------|
| Railway | Unlimited | Unlimited | 500/bulan |
| Netlify | 100GB | Unlimited | 300/bulan |
| Vercel | 100GB | Unlimited | Unlimited |
| Render | Unlimited | Unlimited | Unlimited |

## 🔧 Optimasi Biaya

### 1. **Gunakan Free Tiers**
```bash
# Kombinasi optimal
- Hosting: Netlify/Vercel Free
- Database: Supabase Free
- Domain: Namecheap $1/tahun (.xyz)
- CDN: Cloudflare Free
```

### 2. **Image Optimization**
```javascript
// next.config.mjs
const nextConfig = {
  images: {
    unoptimized: true, // Hemat bandwidth
    formats: ['image/webp', 'image/avif']
  }
}
```

### 3. **Bundle Size Optimization**
```bash
# Analyze bundle
npm run build
npm install -g @next/bundle-analyzer
ANALYZE=true npm run build
```

## 🌍 Global Performance

### **Railway Regions:**
- US West, US East
- Europe (London)
- Asia (Singapore)

### **Render Regions:**
- US East, US West
- Europe (Frankfurt)
- Asia (Singapore)

### **DigitalOcean Regions:**
- 8+ global regions
- Asia: Singapore, India

## 📈 Scaling Strategy

### **Phase 1: MVP (Free)**
- Netlify/Vercel Free
- Supabase Free
- Total: $10/tahun (domain only)

### **Phase 2: Growth ($5-15/bulan)**
- Railway Hobby
- Included database
- Custom domain

### **Phase 3: Scale ($50+/bulan)**
- Vercel Pro
- Dedicated database
- CDN optimization

## 🛠️ Quick Deploy Commands

### Railway
```bash
railway login
railway init
railway up
railway domain
```

### Render
```bash
# Connect GitHub repo
# Auto-deploy on push
# Set environment variables in dashboard
```

### DigitalOcean
```bash
doctl apps create --spec app.yaml
doctl apps list
```

## 💡 Pro Tips

1. **Start Free:** Gunakan free tiers untuk testing
2. **Monitor Usage:** Track bandwidth dan requests
3. **Optimize Images:** Gunakan WebP/AVIF format
4. **Cache Strategy:** Implement proper caching
5. **Database Indexing:** Optimize query performance

## 🎯 Final Recommendation

**Untuk Budget Minimal:** Railway.app ($5/bulan all-inclusive)
**Untuk Free Tier:** Netlify + Supabase (gratis + domain $10/tahun)
**Untuk Performance:** Vercel Pro ($20/bulan + database)
