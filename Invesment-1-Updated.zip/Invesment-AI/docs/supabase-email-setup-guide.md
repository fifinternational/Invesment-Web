# Panduan Setup Email Confirmation di Supabase

## 1. Konfigurasi di Supabase Dashboard

### Langkah 1: Aktifkan Email Confirmation
1. Buka **Supabase Dashboard** → Pilih project Anda
2. Masuk ke **Authentication** → **Settings**
3. Scroll ke bagian **Email Auth**
4. **AKTIFKAN** opsi **"Enable email confirmations"**
5. Klik **Save**

### Langkah 2: Setup Email Templates
1. Masuk ke **Authentication** → **Email Templates**
2. Pilih **"Confirm signup"**
3. Copy paste template dari `/templates/email-confirmation.html`
4. Klik **Save**

### Langkah 3: Konfigurasi Site URL
1. Masuk ke **Authentication** → **URL Configuration**
2. Set **Site URL** ke: `http://localhost:3000` (untuk development)
3. Tambahkan **Redirect URLs**:
   - `http://localhost:3000/auth/confirm`
   - `http://localhost:3000/auth/callback`
4. Klik **Save**

## 2. Environment Variables

Pastikan file `.env.local` memiliki:

```env
NEXT_PUBLIC_SUPABASE_URL=https://wjytrukntveejoebolfn.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

## 3. Testing Email Confirmation

### Test Flow:
1. Daftar dengan email baru di `/register`
2. Cek email inbox (dan folder spam)
3. Klik tombol "Konfirmasi Email Saya"
4. Akan redirect ke `/auth/confirm`
5. Setelah sukses, redirect ke dashboard

### Troubleshooting:
- **Email tidak masuk**: Cek folder spam, pastikan email confirmation diaktifkan
- **Link tidak bekerja**: Pastikan redirect URL sudah benar di Supabase
- **Error saat confirm**: Cek console browser untuk error details

## 4. Production Setup

Untuk production, ganti URL di:
1. Supabase Dashboard → Authentication → URL Configuration
2. Environment variables
3. Redirect URLs di auth functions

## 5. Email Provider (Optional)

Untuk production, setup email provider di:
**Supabase Dashboard** → **Settings** → **Auth** → **SMTP Settings**

Providers yang disarankan:
- SendGrid
- Mailgun  
- AWS SES
- Resend
