# Panduan Setup Supabase untuk Data Real-Time

## 🔧 Langkah 1: Setup Database Schema

### A. Masuk ke Supabase Dashboard
1. Buka https://supabase.com/dashboard
2. Login ke project: **wjytrukntveejoebolfn**
3. Pilih **SQL Editor** di sidebar kiri

### B. Jalankan Script Database
Copy dan paste script berikut ke SQL Editor, lalu klik **Run**:

```sql
-- 1. Shariah Stock Lists
CREATE TABLE shariah_stocks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    symbol VARCHAR(20) NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    market VARCHAR(10) NOT NULL CHECK (market IN ('IDX', 'US')),
    sector VARCHAR(100),
    industry VARCHAR(100),
    shariah_compliant BOOLEAN DEFAULT true,
    shariah_board VARCHAR(50),
    last_reviewed DATE,
    market_cap DECIMAL(20,2),
    currency VARCHAR(3) DEFAULT 'IDR',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(symbol, market)
);

-- 2. Real-time Stock Prices
CREATE TABLE stock_prices (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    stock_id UUID REFERENCES shariah_stocks(id) ON DELETE CASCADE,
    symbol VARCHAR(20) NOT NULL,
    market VARCHAR(10) NOT NULL,
    price DECIMAL(15,4) NOT NULL,
    open_price DECIMAL(15,4),
    high_price DECIMAL(15,4),
    low_price DECIMAL(15,4),
    close_price DECIMAL(15,4),
    volume BIGINT,
    change_amount DECIMAL(15,4),
    change_percent DECIMAL(8,4),
    currency VARCHAR(3),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_source VARCHAR(50),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Market News
CREATE TABLE market_news (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    summary TEXT,
    content TEXT,
    url VARCHAR(1000),
    source VARCHAR(100),
    author VARCHAR(200),
    published_at TIMESTAMP WITH TIME ZONE,
    category VARCHAR(50),
    market VARCHAR(10),
    sentiment VARCHAR(20),
    related_symbols TEXT[],
    image_url VARCHAR(1000),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE shariah_stocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE stock_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_news ENABLE ROW LEVEL SECURITY;

-- Public read policies
CREATE POLICY "Public read shariah stocks" ON shariah_stocks FOR SELECT USING (true);
CREATE POLICY "Public read stock prices" ON stock_prices FOR SELECT USING (true);
CREATE POLICY "Public read market news" ON market_news FOR SELECT USING (true);
```

### C. Verifikasi Tabel
Setelah script berhasil, cek di **Table Editor** bahwa tabel berikut sudah terbuat:
- ✅ `shariah_stocks`
- ✅ `stock_prices` 
- ✅ `market_news`

---

## 📊 Langkah 2: Sumber Data Real-Time Terpercaya

### A. Alpha Vantage (GRATIS - Paling Populer)
**Website**: https://www.alphavantage.co/

**Cara Daftar**:
1. Klik "Get Free API Key"
2. Isi nama dan email
3. Verifikasi email
4. Copy API key dari dashboard

**Fitur**:
- ✅ Real-time quotes US & Indonesia
- ✅ Historical data
- ✅ Company fundamentals
- ✅ Market news
- ✅ 5 requests/menit (gratis)

**Contoh URL**:
```
https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=AAPL&apikey=YOUR_KEY
```

### B. Finnhub (GRATIS - Terbaik untuk News)
**Website**: https://finnhub.io/

**Cara Daftar**:
1. Klik "Register"
2. Isi form pendaftaran
3. Verifikasi email
4. Dashboard → Copy API key

**Fitur**:
- ✅ Real-time quotes
- ✅ Company news
- ✅ Market sentiment
- ✅ Earnings data
- ✅ 60 requests/menit (gratis)

**Contoh URL**:
```
https://finnhub.io/api/v1/quote?symbol=AAPL&token=YOUR_KEY
```

### C. NewsAPI (GRATIS - Khusus Berita)
**Website**: https://newsapi.org/

**Cara Daftar**:
1. Klik "Get API Key"
2. Pilih plan "Developer" (gratis)
3. Isi informasi
4. Copy API key

**Fitur**:
- ✅ Financial news
- ✅ Market analysis
- ✅ Company news
- ✅ 1000 requests/hari (gratis)

**Contoh URL**:
```
https://newsapi.org/v2/everything?q=stock market&apiKey=YOUR_KEY
```

---

## 🔑 Langkah 3: Setup Environment Variables

Buat file `.env.local` di root project:

```env
# Supabase (sudah ada)
NEXT_PUBLIC_SUPABASE_URL=https://wjytrukntveejoebolfn.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Market Data APIs (tambahkan ini)
ALPHA_VANTAGE_API_KEY=your_alpha_vantage_key_here
FINNHUB_API_KEY=your_finnhub_key_here
NEWS_API_KEY=your_newsapi_key_here
```

---

## 🧪 Langkah 4: Test Koneksi

### A. Test Alpha Vantage
```bash
curl "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=AAPL&apikey=YOUR_KEY"
```

### B. Test Finnhub
```bash
curl "https://finnhub.io/api/v1/quote?symbol=AAPL&token=YOUR_KEY"
```

### C. Test NewsAPI
```bash
curl "https://newsapi.org/v2/everything?q=stock&apiKey=YOUR_KEY"
```

---

## 📈 Saham Syariah yang Didukung

### Indonesia (IDX)
```
BRIS - Bank BRISyariah
UNVR - Unilever Indonesia  
TLKM - Telkom Indonesia
GOTO - GoTo Gojek Tokopedia
PTBA - Bukit Asam
ICBP - Indofood CBP
KLBF - Kalbe Farma
ADRO - Adaro Energy
```

### Amerika Serikat
```
AAPL - Apple Inc
MSFT - Microsoft Corp
GOOGL - Alphabet Inc
TSLA - Tesla Inc
JNJ - Johnson & Johnson
PG - Procter & Gamble
KO - Coca-Cola
NEE - NextEra Energy
```

---

## 🚀 Langkah 5: Implementasi

Setelah setup selesai, jalankan:

```bash
# Install dependencies
npm install

# Start development server
npm run dev -- --port 3001
```

Kemudian akses dashboard dan lihat data real-time di section "Market Mode".

---

## ⚠️ Tips Penting

1. **Rate Limiting**: Jangan exceed quota API
2. **Fallback**: Gunakan multiple sources untuk reliability
3. **Caching**: Store data di Supabase untuk mengurangi API calls
4. **Monitoring**: Track API usage di dashboard masing-masing provider

## 🔧 Troubleshooting

**Error: API key invalid**
- Pastikan key benar dan aktif
- Check apakah sudah verifikasi email

**Error: Rate limit exceeded**
- Tunggu sesuai window time
- Gunakan API source lain sebagai backup

**Error: Symbol not found**
- Untuk IDX gunakan format: TLKM.JK
- Untuk US gunakan: AAPL
