# API Keys Setup untuk Data Pasar Real-Time

## Sumber Data yang Diperlukan

### 1. Alpha Vantage (Gratis - 5 requests/menit)
- **Website**: https://www.alphavantage.co/
- **Fitur**: Real-time quotes, historical data, news, fundamentals
- **Pasar**: US, Indonesia (terbatas)
- **Setup**:
  1. Daftar akun gratis
  2. Dapatkan API key
  3. Tambahkan ke `.env.local`: `ALPHA_VANTAGE_API_KEY=your_key_here`

### 2. Finnhub (Gratis - 60 requests/menit)
- **Website**: https://finnhub.io/
- **Fitur**: Real-time quotes, company news, market news
- **Pasar**: US, Indonesia
- **Setup**:
  1. Daftar akun gratis
  2. Dapatkan API key
  3. Tambahkan ke `.env.local`: `FINNHUB_API_KEY=your_key_here`

### 3. NewsAPI (Gratis - 1000 requests/hari)
- **Website**: https://newsapi.org/
- **Fitur**: Financial news, market sentiment
- **Setup**:
  1. Daftar akun gratis
  2. Dapatkan API key
  3. Tambahkan ke `.env.local`: `NEWS_API_KEY=your_key_here`

### 4. Yahoo Finance (via RapidAPI) - Opsional
- **Website**: https://rapidapi.com/apidojo/api/yahoo-finance1/
- **Fitur**: Backup data source
- **Setup**:
  1. Daftar RapidAPI
  2. Subscribe ke Yahoo Finance API
  3. Tambahkan ke `.env.local`: `RAPIDAPI_KEY=your_key_here`

## File .env.local

Buat file `.env.local` di root project dengan isi:

```env
# Supabase (sudah ada)
NEXT_PUBLIC_SUPABASE_URL=https://wjytrukntveejoebolfn.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Market Data APIs
ALPHA_VANTAGE_API_KEY=your_alpha_vantage_key
FINNHUB_API_KEY=your_finnhub_key
NEWS_API_KEY=your_newsapi_key
RAPIDAPI_KEY=your_rapidapi_key

# Optional: Rate limiting (Redis URL for production)
REDIS_URL=redis://localhost:6379
```

## Cara Mendapatkan API Keys

### Alpha Vantage
1. Kunjungi https://www.alphavantage.co/support/#api-key
2. Isi form dengan email dan nama
3. Verifikasi email
4. Copy API key yang diberikan

### Finnhub
1. Kunjungi https://finnhub.io/register
2. Daftar dengan email
3. Verifikasi akun
4. Dashboard → API Key → Copy

### NewsAPI
1. Kunjungi https://newsapi.org/register
2. Daftar dengan email dan informasi
3. Verifikasi email
4. Dashboard → API Key → Copy

## Penggunaan API

### Contoh Request ke Alpha Vantage
```javascript
const response = await fetch(
  `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=AAPL&apikey=${process.env.ALPHA_VANTAGE_API_KEY}`
);
```

### Contoh Request ke Finnhub
```javascript
const response = await fetch(
  `https://finnhub.io/api/v1/quote?symbol=AAPL&token=${process.env.FINNHUB_API_KEY}`
);
```

### Contoh Request ke NewsAPI
```javascript
const response = await fetch(
  `https://newsapi.org/v2/everything?q=stock market&apiKey=${process.env.NEWS_API_KEY}`
);
```

## Rate Limiting

Sistem sudah dilengkapi dengan rate limiting untuk menghindari exceed quota:

- **Alpha Vantage**: 5 requests/menit
- **Finnhub**: 60 requests/menit  
- **NewsAPI**: 1000 requests/hari

## Saham Syariah yang Didukung

### Indonesia (IDX)
- BRIS, BTPS, BSIM (Perbankan Syariah)
- UNVR, INDF, ICBP (Consumer Goods)
- TLKM, ISAT, EXCL (Telekomunikasi)
- GOTO, BUKA, EMTK (Teknologi)
- PTBA, ADRO, ITMG (Mining)

### Amerika Serikat
- AAPL, MSFT, GOOGL (Teknologi)
- JNJ, PFE, UNH (Healthcare)
- PG, KO, PEP (Consumer Goods)
- NEE, DUK, SO (Renewable Energy)

## Testing

Setelah setup API keys, test dengan:

```bash
# Test Alpha Vantage
curl "https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=AAPL&apikey=YOUR_KEY"

# Test Finnhub
curl "https://finnhub.io/api/v1/quote?symbol=AAPL&token=YOUR_KEY"

# Test NewsAPI
curl "https://newsapi.org/v2/everything?q=stock&apiKey=YOUR_KEY"
```

## Troubleshooting

### Error: API key invalid
- Pastikan API key benar dan aktif
- Check quota limit belum terlampaui

### Error: Rate limit exceeded
- Tunggu sesuai window time
- Gunakan multiple API sources sebagai fallback

### Error: Symbol not found
- Pastikan symbol benar (AAPL untuk US, TLKM.JK untuk IDX)
- Check apakah saham masih aktif diperdagangkan

## Upgrade ke Paid Plans

Untuk production dengan traffic tinggi:

- **Alpha Vantage Premium**: $49.99/bulan (1200 requests/menit)
- **Finnhub Premium**: $59/bulan (300 requests/detik)
- **NewsAPI Business**: $449/bulan (unlimited requests)
