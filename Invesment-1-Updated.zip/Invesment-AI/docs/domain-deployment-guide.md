# Domain Deployment Guide

## Overview
Panduan lengkap untuk menyambungkan aplikasi investasi syariah ke domain custom dan deploy ke production.

## 1. Pilihan Platform Hosting

### A. Vercel (Recommended)
**Kelebihan:**
- Optimized untuk Next.js
- Auto-deployment dari GitHub
- SSL certificate otomatis
- Global CDN
- Serverless functions

**Langkah Deploy:**
```bash
# Install Vercel CLI
npm install -g vercel

# Login ke Vercel
vercel login

# Deploy dari project directory
vercel

# Set production domain
vercel --prod
```

### B. Netlify
**Kelebihan:**
- Mudah setup
- Form handling
- Edge functions
- Continuous deployment

### C. Railway
**Kelebihan:**
- Database hosting
- Environment variables management
- Auto-scaling

### D. DigitalOcean App Platform
**Kelebihan:**
- Full control
- Database integration
- Affordable pricing

## 2. Setup Domain Custom

### A. Beli Domain
Pilihan registrar domain:
- **Namecheap** (Recommended)
- **GoDaddy**
- **Cloudflare Registrar**
- **Pandi.id** (untuk domain .id)

### B. Konfigurasi DNS

#### Untuk Vercel:
1. Login ke Vercel dashboard
2. Pilih project → Settings → Domains
3. Tambahkan domain custom (contoh: `blublub-investment.com`)
4. Copy DNS records yang diberikan Vercel
5. Login ke domain registrar
6. Update DNS settings:

```
Type: CNAME
Name: www
Value: cname.vercel-dns.com

Type: A
Name: @
Value: 76.76.19.61
```

#### Untuk Netlify:
```
Type: CNAME
Name: www
Value: your-site-name.netlify.app

Type: A
Name: @
Value: 75.2.60.5
```

### C. SSL Certificate
Semua platform modern (Vercel, Netlify) otomatis provide SSL certificate gratis via Let's Encrypt.

## 3. Environment Variables Production

### A. Buat file `.env.production`
```env
# Database
DATABASE_URL=your_production_database_url

# NextAuth
NEXTAUTH_SECRET=your_strong_production_secret
NEXTAUTH_URL=https://yourdomain.com

# Midtrans Production
MIDTRANS_SERVER_KEY=your_production_server_key
NEXT_PUBLIC_MIDTRANS_CLIENT_KEY=your_production_client_key
MIDTRANS_IS_PRODUCTION=true

# PayPal Production
NEXT_PUBLIC_PAYPAL_CLIENT_ID=your_production_paypal_client_id
PAYPAL_CLIENT_SECRET=your_production_paypal_secret

# Supabase Production
NEXT_PUBLIC_SUPABASE_URL=your_production_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_production_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_production_service_role_key

# Email (Optional)
SMTP_HOST=your_smtp_host
SMTP_PORT=587
SMTP_USER=your_smtp_user
SMTP_PASS=your_smtp_password
```

### B. Set Environment Variables di Platform

#### Vercel:
```bash
# Via CLI
vercel env add MIDTRANS_SERVER_KEY
vercel env add NEXT_PUBLIC_MIDTRANS_CLIENT_KEY
vercel env add DATABASE_URL

# Atau via dashboard: Settings → Environment Variables
```

#### Netlify:
1. Site settings → Environment variables
2. Tambahkan semua environment variables

## 4. Database Setup Production

### A. Supabase (Recommended)
1. Login ke [supabase.com](https://supabase.com)
2. Create new project
3. Copy connection string
4. Run migrations:

```sql
-- Create profiles table
CREATE TABLE profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE,
  email TEXT,
  full_name TEXT,
  subscription_type TEXT DEFAULT 'free',
  subscription_expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  PRIMARY KEY (id)
);

-- Create market_data table
CREATE TABLE market_data (
  id SERIAL PRIMARY KEY,
  symbol TEXT NOT NULL,
  price DECIMAL(10,2),
  change_percent DECIMAL(5,2),
  volume BIGINT,
  market_cap BIGINT,
  updated_at TIMESTAMP DEFAULT NOW()
);
```

### B. PlanetScale (MySQL)
```bash
# Install PlanetScale CLI
npm install -g @planetscale/cli

# Login
pscale auth login

# Create database
pscale database create blublub-investment

# Create branch
pscale branch create blublub-investment main

# Connect
pscale connect blublub-investment main --port 3309
```

## 5. Build Optimization

### A. Update `next.config.mjs`
```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  images: {
    domains: ['images.unsplash.com', 'via.placeholder.com'],
    unoptimized: false
  },
  experimental: {
    serverComponentsExternalPackages: ['midtrans-client']
  },
  env: {
    CUSTOM_KEY: process.env.CUSTOM_KEY,
  },
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ]
  },
}

export default nextConfig
```

### B. Package.json Scripts
```json
{
  "scripts": {
    "build": "next build",
    "start": "next start",
    "deploy": "vercel --prod",
    "build:analyze": "ANALYZE=true npm run build"
  }
}
```

## 6. CI/CD Setup

### A. GitHub Actions (untuk Vercel)
Buat `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Vercel

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '18'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build project
        run: npm run build
        
      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
          vercel-args: '--prod'
```

### B. Auto-deployment Setup
1. Connect GitHub repository ke Vercel
2. Set auto-deployment untuk branch `main`
3. Configure environment variables
4. Enable preview deployments untuk PR

## 7. Domain Configuration Examples

### A. Contoh untuk domain .com
```
Domain: blublub-investment.com
Subdomain: www.blublub-investment.com
API: api.blublub-investment.com (optional)
```

### B. Contoh untuk domain .id
```
Domain: blublub-investment.id
Subdomain: www.blublub-investment.id
```

## 8. Security Checklist

### A. Environment Variables
- [ ] Semua secrets tidak di-commit ke Git
- [ ] Production keys berbeda dari development
- [ ] Database credentials secure

### B. Headers Security
- [ ] HTTPS enforced
- [ ] Security headers configured
- [ ] CORS properly set

### C. Authentication
- [ ] NextAuth configured untuk production domain
- [ ] OAuth providers updated dengan production URLs
- [ ] Session secrets secure

## 9. Testing Production

### A. Pre-deployment Checklist
```bash
# Test build locally
npm run build
npm start

# Test environment variables
echo $MIDTRANS_SERVER_KEY

# Test database connection
npm run db:test
```

### B. Post-deployment Testing
1. **Functionality Testing:**
   - [ ] Login/Register works
   - [ ] Payment integration works
   - [ ] Dashboard loads properly
   - [ ] API endpoints respond

2. **Performance Testing:**
   - [ ] Page load speed < 3 seconds
   - [ ] Images optimized
   - [ ] Lighthouse score > 90

3. **Mobile Testing:**
   - [ ] Responsive design works
   - [ ] Touch interactions work
   - [ ] Payment flows work on mobile

## 10. Monitoring & Analytics

### A. Setup Analytics
```bash
# Install analytics
npm install @vercel/analytics
```

```typescript
// app/layout.tsx
import { Analytics } from '@vercel/analytics/react'

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
```

### B. Error Monitoring
```bash
# Install Sentry
npm install @sentry/nextjs
```

## 11. Maintenance

### A. Regular Updates
- Update dependencies monthly
- Monitor security vulnerabilities
- Backup database regularly
- Monitor performance metrics

### B. Scaling Considerations
- Monitor traffic patterns
- Optimize database queries
- Consider CDN for static assets
- Plan for increased server capacity

## 12. Cost Estimation

### A. Vercel Pro Plan
- **Hosting**: $20/month
- **Domain**: $10-15/year
- **Database**: $25/month (Supabase Pro)
- **Total**: ~$50-60/month

### B. Alternative Budget Setup
- **Netlify**: Free tier
- **Domain**: $10/year
- **Supabase**: Free tier
- **Total**: ~$10/year (untuk traffic rendah)

## Quick Start Commands

```bash
# 1. Build for production
npm run build

# 2. Deploy to Vercel
npx vercel --prod

# 3. Set custom domain
npx vercel domains add yourdomain.com

# 4. Check deployment
npx vercel ls
```

Ikuti panduan ini step-by-step untuk successfully deploy aplikasi ke domain custom!
