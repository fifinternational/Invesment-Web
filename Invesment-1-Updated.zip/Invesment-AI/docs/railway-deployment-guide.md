# Railway Deployment Guide - Hosting Termurah

## 🚂 Railway.app - $5/bulan All-Inclusive

Railway adalah pilihan terbaik untuk hosting internasional yang murah dengan fitur lengkap.

### ✅ Keunggulan Railway:
- **Harga:** $5/bulan (Hobby Plan)
- **Database:** PostgreSQL included gratis
- **Global CDN:** Otomatis
- **SSL Certificate:** Gratis
- **Custom Domain:** Support penuh
- **Auto-deploy:** Dari GitHub
- **Zero config:** Deploy langsung

## 🚀 Step-by-Step Deployment

### 1. Persiapan
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login ke Railway
railway login
```

### 2. Initialize Project
```bash
# Di folder project
cd /Users/airmac/Downloads/Invesment

# Initialize Railway project
railway init

# Pilih "Deploy from existing code"
# Connect ke GitHub repository
```

### 3. Environment Variables
```bash
# Set production environment variables
railway variables set MIDTRANS_SERVER_KEY=SB-Mid-server-xxx
railway variables set NEXT_PUBLIC_MIDTRANS_CLIENT_KEY=SB-Mid-client-xxx
railway variables set MIDTRANS_IS_PRODUCTION=true
railway variables set NEXT_PUBLIC_PAYPAL_CLIENT_ID=your_paypal_id
railway variables set NEXTAUTH_SECRET=your_strong_secret
railway variables set NEXTAUTH_URL=https://yourdomain.com
```

### 4. Database Setup
```bash
# Add PostgreSQL database (gratis dengan plan)
railway add postgresql

# Get database URL
railway variables
```

### 5. Deploy
```bash
# Deploy aplikasi
railway up

# Check deployment status
railway status

# View logs
railway logs
```

### 6. Custom Domain
1. **Railway Dashboard:**
   - Settings → Domains
   - Add custom domain: `yourdomain.com`
   - Copy CNAME record

2. **Domain Registrar:**
   ```
   Type: CNAME
   Name: www
   Value: your-app.up.railway.app
   
   Type: A
   Name: @
   Value: Railway IP (provided in dashboard)
   ```

## 💾 Database Migration

### Setup Prisma (Recommended)
```bash
# Install Prisma
npm install prisma @prisma/client

# Initialize Prisma
npx prisma init

# Update schema.prisma
```

```prisma
// prisma/schema.prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  subscription String @default("free")
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Subscription {
  id        String   @id @default(cuid())
  userId    String
  plan      String
  status    String
  expiresAt DateTime
  createdAt DateTime @default(now())
}
```

```bash
# Generate Prisma client
npx prisma generate

# Push schema to database
npx prisma db push

# (Optional) Seed database
npx prisma db seed
```

## 🔧 Railway Configuration

### railway.json
```json
{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "npm start",
    "healthcheckPath": "/api/health"
  }
}
```

### Health Check Endpoint
```typescript
// app/api/health/route.ts
import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({ 
    status: 'healthy',
    timestamp: new Date().toISOString()
  })
}
```

## 📊 Monitoring & Logs

### View Logs
```bash
# Real-time logs
railway logs --follow

# Service logs
railway logs --service web

# Database logs
railway logs --service postgresql
```

### Metrics Dashboard
- Railway dashboard → Metrics
- CPU usage, Memory, Network
- Request count dan response times

## 💰 Pricing Breakdown

### Hobby Plan ($5/bulan):
- **Compute:** 512MB RAM, 1 vCPU
- **Database:** PostgreSQL included
- **Bandwidth:** Unlimited
- **Build time:** 500 minutes/bulan
- **Custom domains:** Unlimited
- **SSL certificates:** Gratis

### Usage Limits:
- **Execution time:** 500 hours/bulan
- **Database storage:** 1GB
- **Concurrent connections:** 20

## 🌍 Global Performance

### Railway Regions:
- **US West** (Oregon)
- **US East** (Virginia) 
- **Europe** (London)
- **Asia** (Singapore)

### Auto-scaling:
- Horizontal scaling otomatis
- Load balancing built-in
- Zero downtime deployments

## 🔒 Security Features

### Built-in Security:
- **SSL/TLS:** Otomatis untuk semua domains
- **DDoS Protection:** Layer 7 protection
- **Private networking:** Antar services
- **Environment isolation:** Per deployment

### Best Practices:
```bash
# Rotate secrets regularly
railway variables set NEXTAUTH_SECRET=new_secret

# Use Railway's secret management
railway variables set --secret DATABASE_PASSWORD
```

## 🚀 Advanced Features

### Multiple Environments:
```bash
# Create staging environment
railway environment create staging

# Deploy to staging
railway up --environment staging

# Promote to production
railway promote --environment production
```

### Database Backups:
- Otomatis daily backups
- Point-in-time recovery
- Manual backup triggers

### Custom Build Commands:
```json
// package.json
{
  "scripts": {
    "build": "next build",
    "railway:build": "npm run build",
    "railway:start": "npm start"
  }
}
```

## 🔄 CI/CD Integration

### GitHub Actions + Railway:
```yaml
# .github/workflows/railway.yml
name: Deploy to Railway

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Use Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          
      - name: Install Railway CLI
        run: npm install -g @railway/cli
        
      - name: Deploy to Railway
        run: railway up --detach
        env:
          RAILWAY_TOKEN: ${{ secrets.RAILWAY_TOKEN }}
```

## 📈 Scaling Strategy

### Phase 1: Development
- **Plan:** Hobby ($5/bulan)
- **Resources:** 512MB RAM
- **Database:** 1GB storage

### Phase 2: Production
- **Plan:** Pro ($20/bulan)
- **Resources:** 2GB RAM, 2 vCPU
- **Database:** 10GB storage

### Phase 3: Enterprise
- **Plan:** Custom pricing
- **Resources:** Unlimited scaling
- **Support:** Priority support

## 🛠️ Troubleshooting

### Common Issues:

1. **Build Failures:**
```bash
# Check build logs
railway logs --deployment latest

# Rebuild
railway up --force
```

2. **Database Connection:**
```bash
# Test database connection
railway connect postgresql
```

3. **Environment Variables:**
```bash
# List all variables
railway variables

# Update variable
railway variables set KEY=value
```

## 💡 Cost Optimization Tips

1. **Monitor Usage:**
   - Check monthly usage di dashboard
   - Set up alerts untuk usage limits

2. **Optimize Build Time:**
   - Use Docker layer caching
   - Minimize dependencies

3. **Database Optimization:**
   - Regular cleanup old data
   - Optimize queries dengan indexing

## 🎯 Final Setup Checklist

- [ ] Railway CLI installed
- [ ] Project initialized
- [ ] Environment variables set
- [ ] Database connected
- [ ] Custom domain configured
- [ ] SSL certificate active
- [ ] Monitoring setup
- [ ] Backup strategy in place

**Total Cost: $5/bulan untuk hosting lengkap dengan database!**
