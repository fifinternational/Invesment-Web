# Quick Deployment Steps

## 🚀 Langkah Cepat Deploy ke Domain

### 1. Persiapan
```bash
# Install Vercel CLI
npm install -g vercel

# Login ke Vercel
vercel login
```

### 2. Deploy Aplikasi
```bash
# Dari folder project
cd /Users/airmac/Downloads/Invesment

# Deploy pertama kali
vercel

# Deploy ke production
vercel --prod
```

### 3. Setup Domain Custom
1. **Beli domain** di Namecheap/GoDaddy
2. **Di Vercel Dashboard:**
   - Pilih project → Settings → Domains
   - Add domain: `yourdomain.com`
   - Copy DNS records

3. **Di Domain Registrar:**
   - DNS Management
   - Add CNAME: `www` → `cname.vercel-dns.com`
   - Add A Record: `@` → `76.76.19.61`

### 4. Environment Variables Production
Di Vercel Dashboard → Settings → Environment Variables:

```
MIDTRANS_SERVER_KEY=SB-Mid-server-xxx (production key)
NEXT_PUBLIC_MIDTRANS_CLIENT_KEY=SB-Mid-client-xxx
MIDTRANS_IS_PRODUCTION=true
NEXT_PUBLIC_PAYPAL_CLIENT_ID=your_paypal_production_id
NEXTAUTH_URL=https://yourdomain.com
NEXTAUTH_SECRET=your_strong_secret
```

### 5. Test Production
- Buka `https://yourdomain.com`
- Test login/register
- Test payment flows
- Check mobile responsiveness

### 6. Monitoring
```bash
# Install analytics
npm install @vercel/analytics

# Add to app/layout.tsx
import { Analytics } from '@vercel/analytics/react'
```

## ⚡ One-Command Deploy
```bash
# Build dan deploy sekaligus
npm run build && vercel --prod
```

## 🔧 Troubleshooting
- **Build Error**: Check environment variables
- **Domain tidak connect**: Wait 24-48 hours for DNS propagation
- **Payment Error**: Verify production API keys
- **SSL Error**: Vercel handles SSL automatically

## 💰 Estimasi Biaya
- **Domain**: $10-15/tahun
- **Vercel Pro**: $20/bulan
- **Database**: $25/bulan (Supabase)
- **Total**: ~$50/bulan
