// Export semua fungsi dari supabase dan auth
import supabase from './supabase'
import { loginUser, registerUser } from './auth.js'

// Google OAuth functions
export const loginWithGoogle = async () => {
  try {
    // Use a simpler redirect URL without extra parameters
    const redirectUrl = `${window.location.origin}/auth/callback`
    console.log('Google login redirect URL:', redirectUrl)
    
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: redirectUrl,
        skipBrowserRedirect: false,
        scopes: 'openid email profile'
      }
    })

    if (error) {
      console.error('Google login error:', error)
      return { success: false, error: error.message }
    }

    console.log('Google login initiated successfully')
    return { success: true, data }
  } catch (error) {
    console.error('Unexpected Google login error:', error)
    return { success: false, error: 'An unexpected error occurred' }
  }
}

export const signUpWithGoogle = async () => {
  try {
    const redirectUrl = `${window.location.origin}/auth/callback`
    console.log('Google signup redirect URL:', redirectUrl)
    
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: redirectUrl,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        }
      }
    })

    if (error) {
      console.error('Google signup error:', error)
      return { success: false, error: error.message }
    }

    console.log('Google signup initiated successfully')
    return { success: true, data }
  } catch (error) {
    console.error('Unexpected Google signup error:', error)
    return { success: false, error: 'An unexpected error occurred' }
  }
}

// Export all functions
export {
  supabase,
  loginUser,
  registerUser
}

// Export default supabase client
export default supabase