# Supabase Integration

## Overview
Supabase integration for BlubBlub Investment application. These files provide connection to Supabase and basic authentication functions.

## Files

### supabase.js
This file initializes the connection to Supabase using the provided API key.

```javascript
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://fpaclekcbrydyyywpj.supabase.co'
const supabaseKey = 'sb_publishable_dOKDmVeavbVPxCl4zZGIEQ_bFLHckgk'
const supabase = createClient(supabaseUrl, supabaseKey)

export default supabase
```

### auth.js
This file contains functions for user authentication:

- `loginUser(email, password)`: Function for user login with email and password
- `demoLogin()`: Function for demo login with predefined credentials

### index.js
This file exports all functions from supabase.js and auth.js for ease of use.

## Usage

### Login
```javascript
import { loginUser } from '@/utils/supabase'

// Di dalam fungsi login
const result = await loginUser(email, password)
if (result.success) {
  // Login successful, do something with result.user
} else {
  // Login failed, display error message
  console.error(result.error)
}
```

### Demo Login
```javascript
import { demoLogin } from '@/utils/supabase'

// Di dalam fungsi demo login
const result = await demoLogin()
if (result.success) {
  // Demo login successful
} else {
  // Demo login failed
}
```

### Direct Supabase Client Access
```javascript
import { supabase } from '@/utils/supabase'

// Example query to table
const { data, error } = await supabase
  .from('table_name')
  .select('*')
```