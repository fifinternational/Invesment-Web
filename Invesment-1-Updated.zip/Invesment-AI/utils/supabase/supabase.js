// Inisialisasi Supabase client dengan API key Anda
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://wjytrukntveejoebolfn.supabase.co'
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndqeXRydWtudHZlZWpvZWJvbGZuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY3MDY0NjEsImV4cCI6MjA3MjI4MjQ2MX0._ITCA63E8oJLm3MzOyl2MXq4zi4IkEy5MHS3KMoTJ54'

// Log untuk debugging
console.log('Initializing Supabase with URL:', supabaseUrl);
console.log('Supabase key length:', supabaseKey.length);

// Tambahkan opsi untuk mengatasi masalah browser
const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'implicit', // Gunakan implicit flow untuk menghindari PKCE issues
    debug: true // Enable debug untuk troubleshooting
  }
})

export default supabase