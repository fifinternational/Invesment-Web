// Test script untuk memeriksa koneksi Supabase
import supabase from './supabase.js'

export async function testSupabaseConnection() {
  console.log('🔍 Testing Supabase connection...')
  
  try {
    // Test 1: Basic connection
    console.log('📡 Testing basic connection...')
    const { data, error } = await supabase.from('_test').select('*').limit(1)
    
    if (error && error.code !== 'PGRST116') { // PGRST116 = table not found (expected)
      console.error('❌ Connection failed:', error.message)
      return { success: false, error: error.message }
    }
    
    console.log('✅ Basic connection successful')
    
    // Test 2: Auth service
    console.log('🔐 Testing auth service...')
    const { data: authData, error: authError } = await supabase.auth.getSession()
    
    if (authError) {
      console.error('❌ Auth service error:', authError.message)
      return { success: false, error: authError.message }
    }
    
    console.log('✅ Auth service accessible')
    
    // Test 3: Google OAuth configuration
    console.log('🔍 Checking Google OAuth configuration...')
    
    // This will show if Google provider is configured
    try {
      const { data: oauthData, error: oauthError } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: 'http://localhost:3000/auth/callback',
          skipBrowserRedirect: true // Don't actually redirect, just test config
        }
      })
      
      if (oauthError) {
        console.warn('⚠️ Google OAuth may not be configured:', oauthError.message)
      } else {
        console.log('✅ Google OAuth configuration appears valid')
      }
    } catch (oauthTestError) {
      console.warn('⚠️ Google OAuth test failed:', oauthTestError.message)
    }
    
    return { 
      success: true, 
      message: 'Supabase connection successful',
      details: {
        url: supabase.supabaseUrl,
        authService: 'accessible',
        timestamp: new Date().toISOString()
      }
    }
    
  } catch (error) {
    console.error('❌ Unexpected error:', error)
    return { success: false, error: error.message }
  }
}

// Run test if called directly
if (typeof window !== 'undefined') {
  // Browser environment
  window.testSupabaseConnection = testSupabaseConnection
  console.log('🔧 Supabase test function available as window.testSupabaseConnection()')
}
