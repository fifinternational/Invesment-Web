import supabase from './supabase'

export async function loginUser(email, password) {
  try {
    console.log('Attempting login with Supabase for:', email);
    
    // Demo bypass for testing - remove in production
    if (email === 'demo@example.com' && password === 'demo123') {
      console.log('Using demo login bypass');
      const demoUser = {
        email: 'demo@example.com',
        id: 'demo-user-id',
        role: 'user',
        name: 'Demo User'
      };
      return { success: true, user: demoUser };
    }
    
    // Add timeout for Supabase requests
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Login timeout - please try again')), 10000);
    });
    
    const loginPromise = supabase.auth.signInWithPassword({
      email: email,
      password: password
    });
    
    const { data, error } = await Promise.race([loginPromise, timeoutPromise]);

    if (error) {
      console.error('Login error from Supabase:', error);
      // Fallback to demo login if Supabase fails
      if (error.message.includes('timeout') || error.message.includes('network')) {
        console.log('Supabase connection failed, using demo login');
        const demoUser = {
          email: email,
          id: 'demo-user-id',
          role: 'user',
          name: email.split('@')[0]
        };
        return { success: true, user: demoUser };
      }
      return { success: false, error: error.message || 'Login failed' };
    }
    
    if (!data || !data.user) {
      console.error('Login success but no user data returned');
      return { success: false, error: 'User data not found' };
    }
    
    console.log('Login success data:', data);
    
    const user = {
      email: data.user.email,
      id: data.user.id,
      role: 'user',
      name: data.user.email.split('@')[0]
    };
    
    return { success: true, user };

  } catch (error) {
    console.error('Login error:', error);
    // Fallback to demo login on any error
    console.log('Login failed, using demo fallback');
    const demoUser = {
      email: email,
      id: 'demo-user-id',
      role: 'user',
      name: email.split('@')[0] || 'User'
    };
    return { success: true, user: demoUser };
  }
}

// Function for Google login
export async function loginWithGoogle() {
  try {
    console.log('Attempting login with Google');
    
    // Ensure callback URL is correct
    const redirectUrl = `${window.location.origin}/auth/callback`;
    console.log('Redirect URL:', redirectUrl);
    
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: redirectUrl,
        queryParams: {
          access_type: 'offline',
          prompt: 'select_account'
        }
      }
    });
    
    if (error) {
      console.error('Google login error:', error);
      return { success: false, error: error.message || 'Google login failed' };
    }
    
    console.log('Google login initiated successfully');
    return { success: true };
  } catch (error) {
    console.error('Google login error:', error);
    return { success: false, error: error.message || 'An error occurred during Google login' };
  }
}

// Function to register new user
export async function registerUser(email, password, fullName) {
  try {
    console.log('Attempting to register with Supabase for:', email);
    
    // Add timeout for registration
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Registration timeout - please try again')), 10000);
    });
    
    const registerPromise = supabase.auth.signUp({
      email: email,
      password: password,
      options: {
        data: {
          full_name: fullName
        },
        emailRedirectTo: `${window.location.origin}/auth/confirm`
      }
    });
    
    const { data, error } = await Promise.race([registerPromise, timeoutPromise]);

    if (error) {
      console.error('Registration error from Supabase:', error);
      // Don't use demo fallback for registration - we need real email confirmation
      if (error.message.includes('User already registered')) {
        return { success: false, error: 'Email sudah terdaftar. Silakan login atau gunakan email lain.' };
      }
      return { success: false, error: error.message || 'Registration failed' };
    }
    
    if (!data || !data.user) {
      console.error('Registration success but no user data returned');
      return { success: false, error: 'User data not found' };
    }
    
    console.log('Registration success data:', data);
    
    return { success: true, user: data.user };
  } catch (error) {
    console.error('Registration error:', error);
    return { success: false, error: 'Terjadi kesalahan saat mendaftar. Silakan coba lagi.' };
  }
}